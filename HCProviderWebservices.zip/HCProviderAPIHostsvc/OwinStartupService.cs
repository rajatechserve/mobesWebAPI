﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using HCWebApi;
using Owin;
using System.Configuration;

namespace HCProviderApiHostService
{
    partial class OwinStartupService : ServiceBase
    {
        private IDisposable _webapp;
        System.Diagnostics.EventLog e = null;
        public OwinStartupService()
        {
            e = new System.Diagnostics.EventLog();

            this.ServiceName = ConfigurationManager.AppSettings["servicename"];

            e.Source = this.ServiceName;

        }

        protected override void OnStart(string[] args)
        {
           
         
            try
            {
            

                OwinStartupHelper ohelper = new OwinStartupHelper();
                _webapp = ohelper.StartOwinServer();

            }
            catch (Exception exp)
            {
              
                e.WriteEntry(string.Format("Start: Error:{0}\n Stack: {1}\n", exp.Message, exp.StackTrace));

            }
            }


        protected override void OnStop()
        {
           
            try
            {
             
                e.WriteEntry(string.Format("Owin Stop: {0}\n{1}\n", "Exiting", "1"));
                _webapp?.Dispose();
            }
            catch (Exception exp)
            {
            
                e.WriteEntry(string.Format("Stop: Error:{0}\n Stack: {1}\n", exp.Message, exp.StackTrace));

            }
        }

        }
}
