﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderApiHostService
{
    public static class Program
    {


        static System.Diagnostics.EventLog elog = null;

        /// <summary>
        /// The main entry point for the application.
        /// Adding a commented line demo 
        /// </summary>
        public static void Main()
        {

            elog = new System.Diagnostics.EventLog();
            elog.Source = "ProviderOwinService";

            try
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] { new ProviderOwinService() };
                ServiceBase.Run(ServicesToRun);
            }
            catch (Exception exp)
            {

                elog.WriteEntry(string.Format("Error:{0}\n Stack: {1}\n", exp.Message, exp.StackTrace));
            }
        }
    }
}
