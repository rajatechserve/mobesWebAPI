﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Configuration.Install;
using System.Linq;
using System.Threading.Tasks;

namespace HCProviderApiHostService
{
    [RunInstaller(true)]
    public partial class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();


            var config = ConfigurationManager.OpenExeConfiguration(this.GetType().Assembly.Location);

            if (config.AppSettings.Settings["ServiceName"] != null)
            {
                this.serviceInstaller1.ServiceName = config.AppSettings.Settings["servicename"].Value;
                this.serviceInstaller1.DisplayName = config.AppSettings.Settings["displayname"].Value;
                this.serviceInstaller1.Description = config.AppSettings.Settings["description"].Value;
                this.serviceProcessInstaller1.Account = System.ServiceProcess.ServiceAccount.LocalService;
            }


        }

        
    }
}
