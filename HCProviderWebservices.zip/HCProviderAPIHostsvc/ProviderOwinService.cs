﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using HCWebApi;
using System.Configuration;
using HCShared;
using log4net;

namespace HCProviderApiHostService
{
    partial class ProviderOwinService : ServiceBase
    {
        public ProviderOwinService()
        {
            InitializeComponent();
          
        }

        protected override void OnStart(string[] args)
        {
            // TODO: Add code here to start your service.
          

             OwinStartupHelper owhelper = new OwinStartupHelper();

             owhelper.StartOwinServer();

            HCOptumLogger optumLogger = new HCOptumLogger(LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType));
            if (optumLogger != null)
            {
                optumLogger.MethodEntry("Provider Owin Service started");
            }


        }

        protected override void OnStop()
        {

            // TODO: Add code here to perform any tear-down necessary to stop your service.
            HCOptumLogger optumLogger = new HCOptumLogger(LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType));         
            if (optumLogger != null)
            {
                optumLogger.MethodEntry("Provider Owin Service stoped");
            }

        }
    }
}
