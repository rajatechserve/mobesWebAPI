﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HCProviderDataModel;
using HCProviderDataModel.DataModels;

namespace HCProviderDataModel.DataContracts
{
    public interface IAlertContract
    {
        
        Task<int> Notify(int userid, Notify message);

        Task<AlertView> GetAlerts(int userid, int? alertid = 0, DateTime? fromDate = null, DateTime? toDate = null, int? pagesize = 10, int? pagenumber = 1, string status = "active", string type = "all", int? isDefault = 1);
        Task<AlertScheduleView> GetScheduleAlerts(int providerid,int? pagesize = 5, int? pagenumber = 1);

        Task<int> NotifyPending(int userid);


        Task<int> Acknowledge(int userid, int alertid,string action);

        Task<int> AlertSubscription(NotificationsSubscription notificationsSubscription);
        Task<IEnumerable<Addendum>> GetAddendumsCount(int providerId);
        Task<IEnumerable<WeatherAlertView>> GetWeatherAlerts(string state, string city);
        Task<int> AddAlert(string type, string description, string date, long dateEpoch, string expires, long expiresEepoch, string message,
            string phenomena, char significance, string city, string state, DateTime alertServerExpiresDate);

        System.Threading.Tasks.Task AddAlerts(List<WeatherAlertView> alerts);
        Task<IEnumerable<QualityAssurance>> GetQACount(int providerId);
        Task<IEnumerable<PTOAlertView>> GetPTOAlerts(int providerId);

        Task<IEnumerable<NoAvailability>> GetNoAvailability(int providerId);
    }
}
