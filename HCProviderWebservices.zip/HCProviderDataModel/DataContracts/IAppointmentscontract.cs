﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HCProviderDataModel;


namespace HCProviderDataModel.DataContracts
{
    public interface IAppointmentscontract
    {

        Task<IEnumerable<Appointment>> GetAppointments(int providerid, DateTime? aptStartDate = null, DateTime? aptEndDate = null, int appointmentid = 0);

        /// <summary>
        /// GetAppointmentCountView
        /// </summary>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <param name="providerid"></param>
        /// <returns></returns>
        Task<IEnumerable<AppointmentCount>> GetAppointmentCountView(int year, int month, int providerid);


        /// <summary>
        /// GetDailySupply
        /// </summary>
        /// <param name="Aptdate"></param>
        /// <param name="providerid"></param>
        /// <returns></returns>
        Task<IEnumerable<SupplyCount>>  GetDailySupply(DateTime Aptdate, int providerid);
      

        /// <summary>
        /// GetAutoCallFileStatus
        /// </summary>
        /// <param name="providerID"></param>
        /// <returns></returns>
        Task<bool> GetAutoCallFileStatus(int providerID);

        /// <summary>
        /// InsertAutoCall
        /// </summary>
        /// <param name="providerID"></param>
        /// <param name="appointmentid"></param>
        void InsertAutoCall(int providerID, int appointmentid,bool insertfile);
    }
}
