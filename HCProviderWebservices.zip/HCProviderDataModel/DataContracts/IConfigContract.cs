﻿using HCProviderDataModel.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataContracts
{
    public interface IConfigContract//IConfigContract interface class
    {
        Task<IdleTimeView> GetIdleTimeValues();//Methods declaraction

        int GetServerTimeZoneDiff();
    }
}
