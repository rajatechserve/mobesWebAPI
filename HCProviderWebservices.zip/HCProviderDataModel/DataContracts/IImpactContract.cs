﻿using HCProviderDataModel.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataContracts
{
    public interface IImpactContract
    {

        /// <summary>
        /// Add Goal
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="targetedAnnualGoal"></param>
        /// <param name="userId"></param>
        ///  <param name="year"></param>
        /// <returns></returns>
        Task<int>  AddGoal( int providerId, int targetedAnnualGoal, int userId, int year);

        /// <summary>
        /// Get Impact List
        /// </summary>
        /// <param name="Type"></param>
        /// <param name="Frequency"></param>
        /// <param name="ProviderId"></param>
        /// <returns></returns>
        Task<ImpactMetrix> GetImpactList(int providerId, int month, int year);
    }
}
