﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataContracts
{
    public interface IProviderDataContract
    {
        Task<IEnumerable<Provider>> GetProviders(int userid);
    }
}
