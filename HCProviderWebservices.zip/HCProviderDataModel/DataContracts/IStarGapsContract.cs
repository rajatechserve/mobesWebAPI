﻿using HCProviderDataModel.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataContracts
{
    public interface IStarGapsContract
    {
        /// <summary>
        /// Get Star Gaps
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="month"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        Task<StarGapsView> GetStarGaps(int providerId, int month, int year);
    }
}
