﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HCProviderDataModel;

namespace HCProviderDataModel.DataContracts
{
   public interface ISupportContract
    {
        /// <summary>
        /// Add contact of type clinical
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="contact"></param>
        /// <returns></returns>
        //Task<int> AddClinicalContact(  SupportContact contact , int userid);


        /// <summary>
        /// add contact of type technical
        /// </summary>
        /// <param name="providerid">query by provider id</param>
        /// <param name="userid"> query by userid</param>
        /// <param name="contact">contact to add , generated id is returned back </param>
        /// <returns></returns>
        //Task<int> AddTechnicalContact(  SupportContact contact , int userid);


        /// <summary>
        /// Add Or Update contact of type clinical/technical
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="contact"></param>
        /// <returns></returns>
        Task<int> AddSupportContact(SupportContact contact, int userid);

        /// <summary>
        /// Get learnings , return all learnings resources available provider
        /// </summary>
        /// <param name="providerid">query by provider id</param>
        /// <param name="userid"></param>
        /// <param name="learningtype">all/technical/clinical</param>
        /// <param name="learningId">query by Id</param>
        /// <returns></returns>
        IEnumerable<Supportlearning> GetLearnings( int userid , int learningId =0, string learningtype = "all");


        /// <summary>
        /// Get Contacts , return all contact numbers , clinical/technical/memberservice
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="contacttype">default filter all, support multiple comma seperated, filter?contacttype= clinical/technical/memberservice</param>
        /// <returns></returns>
        Task<IEnumerable<SupportContact>> GetSupportContacts(string contacttype, int userid ,int contactid =0);

        /// <summary>
        /// update the contact
        /// update status  =Removed to inactive  the contact record
        /// </summary>
        /// <param name="contact">object to update</param>
        /// <param name="userid"></param>
        /// <param name="providerid"></param>
        /// <returns></returns>
        Task<int> UpdateSupportContact(SupportContact contact, int userid);

        Task<int> DeleteSupportContact(int userid, int contactid);
       
    }
}
