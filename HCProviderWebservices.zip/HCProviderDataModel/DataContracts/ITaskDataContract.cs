﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataContracts
{
    public interface ITaskDataContract
    {   
        /// <summary>
          /// Add Task
          /// </summary>
          /// <param name="TaskName"></param>
          /// <param name="TaskDescription"></param>
          /// <param name="TaskDueDate"></param>
          /// <param name="TaskCreatedBy"></param>
          /// <returns>TaskID</returns>
        Task<int> AddTask(string TaskName, string TaskDescription, DateTime TaskDueDate, int TaskCreatedBy);

        /// <summary>
        /// Add Task
        /// </summary>
        /// <param name="TaskName"></param>
        /// <param name="TaskDescription"></param>
        /// <param name="TaskDueDate"></param>
        /// <param name="TaskCreatedBy"></param>
        /// <returns>TaskID</returns>
        Task<int> UpdateTask(int taskId, string taskName, string taskDescription, string taskStatus, int taskCreatedBy, DateTime? taskDueDate);

        /// <summary>
        /// Get Tasks
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="status"></param>
        /// <param name="pagesize"></param>
        /// <param name="pagenumber"></param>
        /// <returns>TaskList</returns>
        Task<TaskView> GetTaskList(int userid, int? taskid=0, DateTime? fromDate= null, DateTime? toDate = null,  int? pagesize=10, int? pagenumber=1, string status= "active");
        Task<TaskView> GetNewTaskList(int userid, int? taskid = 0, DateTime? fromDate = null, DateTime? toDate = null, int? pagesize = 10, int? pagenumber = 1, string status = "active");


        /// <summary>
        /// Get Task Count View
        /// </summary>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <param name="userid"></param>
        /// <returns>TaskCount</returns>
        Task<IEnumerable<TaskCount>> GetTaskCountView(int year, int month, int userid);




    }
}
