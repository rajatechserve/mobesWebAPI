﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HCProviderDataModel;


namespace HCProviderDataModel.DataContracts
{
    public interface IUsercontract
    {

        User GetUserById(int userid);
        User GetUserBylogin(string login);

        User GetUserByToken(string token);

        User GetUser(string username, string password);
        User GetUserByOptumId(string optumId);
    }
}
