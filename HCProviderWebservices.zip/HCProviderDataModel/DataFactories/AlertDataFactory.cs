﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using Dapper;
using HCProviderDataModel.DataContracts;
using System.Threading.Tasks;
using log4net;
using HCProviderDataModel.DataModels;
using System.Data.SqlClient;

/// <summary>
/// https://github.com/StackExchange/dapper-dot-net
/// </summary>
namespace HCProviderDataModel.DataFactory
{
    /// <summary>
    /// version 1 appointment services
    ///  
    /// </summary>

    public class Alertdatafactory : basedatafactory, IAlertContract
    {
        ILog _logger;
        public Alertdatafactory(string connectionstring, ILog logger) : base(connectionstring)
        {
            _logger = logger;

        }




        /// <summary>
        /// GetAlerts
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="aptStartDate"></param>
        /// <param name="aptEndDate"></param>
        /// <param name="appointmentid"></param>
        /// <returns></returns>
        async Task<AlertView> IAlertContract.GetAlerts(int userid, int? alertid, DateTime? fromDate, DateTime? toDate, int? pagesize, int? pagenumber, string status, string type, int? isDefault)
        {
            // IEnumerable<Alert> appointments = null;
            List<Alert> alerts = null;
            AlertView alertViews = null;
            try
            {

                var pars = new DynamicParameters();
                pars.Add("@userid", userid);
                pars.Add("@alertId", alertid);
                pars.Add("@fromDate", fromDate);
                pars.Add("@toDate", toDate);
                pars.Add("@pageSize", pagesize);
                pars.Add("@pageNumber", pagenumber);
                pars.Add("@status", status);
                pars.Add("@alerttype", type);
                pars.Add("@isDefault", isDefault);
                var alert = await _dbcon.QueryMultipleAsync("dbo.wapi_getAlerts", pars, commandType: CommandType.StoredProcedure);

                alertViews = alert.Read<AlertView>().FirstOrDefault();

                alerts = alert.Read<Alert>().ToList();
                if (alerts.Count != 0)
                {
                    alertViews.Alert = alerts;
                }
                else
                {
                    return alertViews = null;
                }


            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);
                //Log and Throw
            }
            return alertViews;
        }

        async System.Threading.Tasks.Task IAlertContract.AddAlerts(List<WeatherAlertView> alerts)
        {
            // create datatable
            DataTable dt = new DataTable();

            // adding column in empty datatable dt
            dt.Columns.AddRange(new DataColumn[12] { new DataColumn("type", typeof(string)),
                    new DataColumn("description", typeof(string)),
                    new DataColumn("date", typeof(string)),
                    new DataColumn("dateEpoch", typeof(long)),
                    new DataColumn("expires", typeof(string)),
                    new DataColumn("expiresEpoch", typeof(long)),
                    new DataColumn("message", typeof(string)),
                    new DataColumn("phenomena", typeof(string)),
                    new DataColumn("significance", typeof(char)),
                    new DataColumn("city", typeof(string)),
                    new DataColumn("state", typeof(string)),
                    new DataColumn("alertServerExpiresDate",typeof(DateTime)) });

            // adding rows in datatable from collection alerts
            foreach (var alert in alerts)
            {
                string type = alert.Type;
                string description = alert.Description;
                string date = alert.Date;
                long dateEpoch = alert.DateEpoch;
                string expires = alert.Expires;
                long expiresEpoch = alert.ExpiresEpoch;
                string message = alert.Message;
                string phenomena = alert.Phenomena;
                char significance = alert.Significance;
                string city = alert.City;
                string state = alert.State;
                DateTime alertServerExpiresDate = alert.AlertServerExpiresDate;

                dt.Rows.Add(type, description, date, dateEpoch, expires, expiresEpoch, message, phenomena, significance, city, state, alertServerExpiresDate);

            }

            try
            {
                // creating connection with db
                SqlConnection conn = new SqlConnection(_dbcon.ConnectionString);

                // defining sp name in sql variable
                string sql = "dbo.wapi_addWeatherAlert";

                //defining sql commaind with query and connection
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();

                cmd.CommandType = CommandType.StoredProcedure;

                // passing datatable dt as parameter to stored procedure wapi_addWeatherAlert
                var parameters = cmd.Parameters.AddWithValue("@lstAlerts", dt);
                parameters.SqlDbType = SqlDbType.Structured;

                // defining sql data adapter with sql command
                SqlDataAdapter ada = new SqlDataAdapter(cmd);

                // executing defined commad and filling data in ada with returning data by sp
                cmd.ExecuteNonQuery();

                //var pars = new DynamicParameters();

                //pars.Add("@lstAlerts", dt);

                //await _dbcon.ExecuteAsync("dbo.wapi_addWeatherAlert", pars, commandType: CommandType.StoredProcedure);

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);

            }
        }
        async Task<AlertScheduleView> IAlertContract.GetScheduleAlerts(int providerid, int? pagesize, int? pagenumber)
        {
            // IEnumerable<Alert> appointments = null;
            List<AlertSchedule> alerts = null;
            AlertScheduleView alertViews = null;
            try
            {

                var pars = new DynamicParameters();
                pars.Add("@providerid", providerid);
                pars.Add("@pageSize", pagesize);
                pars.Add("@pageNumber", pagenumber);

                var alert = await _dbcon.QueryMultipleAsync("dbo.wapi_getAlerts", pars, commandType: CommandType.StoredProcedure);

                alertViews = alert.Read<AlertScheduleView>().FirstOrDefault();

                alerts = alert.Read<AlertSchedule>().ToList();
                if (alerts.Count != 0)
                {
                    alertViews.Alert = alerts;
                }
                else
                {
                    return alertViews = null;
                }


            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);
                //Log and Throw
            }
            return alertViews;
        }
        async Task<int> IAlertContract.Acknowledge(int userid, int alertid, string action)
        {
            int result = 1;
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@userid", userid);
                pars.Add("@alertid", alertid);
                pars.Add("@action", action);
                pars.Add("@Result", null, DbType.Int32, ParameterDirection.ReturnValue);
                await _dbcon.ExecuteScalarAsync<int>("dbo.wapi_updateAlertStatus", pars, commandType: CommandType.StoredProcedure);
                result = pars.Get<int>("Result");
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);

            }
            return result;
        }

        async Task<int> IAlertContract.AlertSubscription(NotificationsSubscription notificationsSubscription)
        {
            int result;

            try
            {

                var pars = new DynamicParameters();
                pars.Add("@UserRef", notificationsSubscription.userRef);
                pars.Add("@SubscriptionStatus", notificationsSubscription.subscriptionStatus);
                pars.Add("@ConnectionId", notificationsSubscription.currentConnectionId);
                pars.Add("@ConnectionStatus", notificationsSubscription.connectionStatus);
                pars.Add("@UpdatedBy", notificationsSubscription.updatedBy);
                pars.Add("@Result", null, DbType.Int32, ParameterDirection.Output);

                await _dbcon.ExecuteScalarAsync<int>("dbo.wapi_addMobileAlertSubscription", pars, commandType: CommandType.StoredProcedure);

                int SubscriptionId = pars.Get<int>("Result");

                result = SubscriptionId;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);

            }
            return result;
        }

        async Task<int> IAlertContract.Notify(int userid, Notify motify)
        {
            int result;

            try
            {

                var pars = new DynamicParameters();
                pars.Add("@AlertType", motify.type);
                pars.Add("@RecipientType", motify.recipientType);
                pars.Add("@AlertDateTime", motify.alertDateTime);
                pars.Add("@AlertMessage", motify.message);
                pars.Add("@TargetedUser", motify.targetedUser);
                pars.Add("@SourceLkup", motify.source);
                pars.Add("@ExpiresOn", motify.expiresOn);
                pars.Add("@Result", null, DbType.Int32, ParameterDirection.Output);

                await _dbcon.ExecuteScalarAsync<int>("dbo.wapi_addNotify", pars, commandType: CommandType.StoredProcedure);

                int TaskId = pars.Get<int>("Result");

                result = TaskId;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);

            }
            return result;
        }

        public Task<int> NotifyPending(int userid)
        {
            throw new NotImplementedException();
        }

        async Task<IEnumerable<Addendum>> IAlertContract.GetAddendumsCount(int providerId)
        {

            IEnumerable<Addendum> addendum = null;
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@providerId", providerId);
                var res = await _dbcon.QueryAsync<Addendum>("dbo.wapi_getAddendums", pars, commandType: CommandType.StoredProcedure);
                addendum = res;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);

            }
            return addendum;
        }

        async Task<IEnumerable<WeatherAlertView>> IAlertContract.GetWeatherAlerts(string state, string city)
        {

            IEnumerable<WeatherAlertView> alerts = null;
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@state", state);
                pars.Add("@city", city);
                var res = await _dbcon.QueryAsync<WeatherAlertView>("dbo.wapi_getWeatherAlerts", pars, commandType: CommandType.StoredProcedure);
                alerts = res;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);

            }
            return alerts;
        }

        async Task<int> IAlertContract.AddAlert(string type, string description, string date, long dateEpoch, string expires, long expiresEepoch,
            string message, string phenomena, char significance, string city, string state, DateTime alertServerExpiresDate)
        {
            int result = 0;

            try
            {

                var pars = new DynamicParameters();
                pars.Add("@Type", type);
                pars.Add("@Description", description);
                pars.Add("@Date", date);
                pars.Add("@DateEpoch", dateEpoch);
                pars.Add("@Expires", expires);
                pars.Add("@ExpiresEpoch", expiresEepoch);
                pars.Add("@Message", message);
                pars.Add("@Phenomena", phenomena);
                pars.Add("@Significance", significance);
                pars.Add("@City", city);
                pars.Add("@State", state);
                pars.Add("@AlertServerExpiresDate", alertServerExpiresDate);
                pars.Add("@Result", null, DbType.Int32, ParameterDirection.Output);
                await _dbcon.ExecuteScalarAsync<int>("dbo.wapi_addWeatherAlert", pars, commandType: CommandType.StoredProcedure);

                int alertId = pars.Get<int>("Result");

                result = alertId;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);

            }
            return result;
        }

        async Task<IEnumerable<QualityAssurance>> IAlertContract.GetQACount(int providerId)
        {

            IEnumerable<QualityAssurance> qarecord = null;
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@providerId", providerId);

                var res = await _dbcon.QueryAsync<QualityAssurance>("dbo.wapi_getQualityAssurance", pars, commandType: CommandType.StoredProcedure);
                qarecord = res;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);

            }
            return qarecord;
        }

        async Task<IEnumerable<PTOAlertView>> IAlertContract.GetPTOAlerts(int providerId)
        {
            IEnumerable<PTOAlertView> alerts = null;
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@providerId", providerId);
                var res = await _dbcon.QueryAsync<PTOAlertView>("dbo.wapi_getPTO", pars, commandType: CommandType.StoredProcedure);
                alerts = res;
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);
            }
            return alerts;
        }


        async Task<IEnumerable<NoAvailability>> IAlertContract.GetNoAvailability(int providerId)
        {
            IEnumerable<NoAvailability> noavail = null;
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@providerId", providerId);
                var res = await _dbcon.QueryAsync<NoAvailability>("dbo.wapi_getNoAvailability", pars, commandType: CommandType.StoredProcedure);
                noavail = res;
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);
            }
            return noavail;
        }
    }
}
