﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using Dapper;
using HCProviderDataModel.DataContracts;
using System.Threading.Tasks;
using log4net;

/// <summary>
/// https://github.com/StackExchange/dapper-dot-net
/// </summary>
namespace HCProviderDataModel.DataFactory
{
    /// <summary>
    /// version 1 appointment services
    ///  
    /// </summary>

    public class Appointmentdatafactory : basedatafactory, IAppointmentscontract
    {
        ILog _logger;
        public Appointmentdatafactory(string connectionstring, ILog logger) : base(connectionstring)
        {
            _logger = logger;

        }



        /// <summary>
        /// GetAppointments
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="aptStartDate"></param>
        /// <param name="aptEndDate"></param>
        /// <param name="appointmentid"></param>
        /// <returns></returns>
        async Task<IEnumerable<Appointment>> IAppointmentscontract.GetAppointments(int providerid, DateTime? aptStartDate, DateTime? aptEndDate, int appointmentid)
        {
            IEnumerable<Appointment> appointments = null;
            try
            {

                var pars = new DynamicParameters();
                pars.Add("@providerId", providerid);
                pars.Add("@stdate", aptStartDate);
                pars.Add("@enddate", aptEndDate);
                pars.Add("@appointmentId", appointmentid);
                var apptask = await _dbcon.QueryAsync<Appointment>("dbo.wapi_getappointments", pars, commandType: CommandType.StoredProcedure);

                appointments = apptask;


            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);
                //Log and Throw
            }
            return appointments;
        }

        /// <summary>
        /// GetAppointmentCountView
        /// </summary>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <param name="providerid"></param>
        /// <returns></returns>
        async Task<IEnumerable<AppointmentCount>> IAppointmentscontract.GetAppointmentCountView(int year, int month, int providerid)
        {
            IEnumerable<AppointmentCount> appointmentsView = null;
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@providerid", providerid);
                pars.Add("@year", year);
                pars.Add("@month", month);
                var aview = await _dbcon.QueryAsync<AppointmentCount>("dbo.wapi_getappointmentview", pars, commandType: CommandType.StoredProcedure);
                appointmentsView = aview;
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp.InnerException);

            }
            return appointmentsView;
        }

        /// <summary>
        /// GetDailySupply
        /// </summary>
        /// <param name="Aptdate"></param>
        /// <param name="providerid"></param>
        /// <returns></returns>
        async Task<IEnumerable<SupplyCount>> IAppointmentscontract.GetDailySupply(DateTime Aptdate, int providerid)
        {

            IEnumerable<SupplyCount> supplyCount = null;

            try
            {
                var pars = new DynamicParameters();

                pars.Add("@providerid", providerid);
                pars.Add("@aptdate", Aptdate);
                var supplytask = await _dbcon.QueryAsync<SupplyCount>("dbo.wapi_getAppointmentSupplies", pars, commandType: CommandType.StoredProcedure);
                supplyCount = supplytask;// supplytask.FirstOrDefault<DailySupply>();
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp.InnerException);

            }
            return supplyCount;
        }

         /// <summary>
        /// GetAutoCallFileStatus
        /// </summary>
        /// <param name="providerID"></param>
        /// <returns></returns>
        async Task<bool> IAppointmentscontract.GetAutoCallFileStatus(int providerID)
        {
            bool _status = false;
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@Provider_ID", providerID);

                var res = await _dbcon.QueryAsync("dbo.wapi_getAutoCallFile", pars, commandType: CommandType.StoredProcedure);
                if (res != null && res.Count() > 0)
                    _status = true;


            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);

            }

            return _status;
        }

        /// <summary>
        /// InsertAutoCall
        /// </summary>
        /// <param name="providerID"></param>
        /// <param name="appointmentid"></param>
        async void IAppointmentscontract.InsertAutoCall(int providerID, int appointmentid,bool insertfile)
        {
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@Provider_ID", providerID);
                pars.Add("@MEMBER_CALL_APPT_ID", appointmentid);
                pars.Add("@INSERT_FILE", insertfile);


                int insertID = await _dbcon.ExecuteScalarAsync<int>("dbo.wapi_insertAutoCall", pars, commandType: CommandType.StoredProcedure);



            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp.InnerException);

            }
        }
    }
}
