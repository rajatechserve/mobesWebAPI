﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace HCProviderDataModel. DataFactory
{
  public class basedatafactory:IDisposable 
    {

         /// <summary>
        /// db connection
        /// </summary>
       protected IDbConnection _dbcon;
       public basedatafactory(string connectionString)
        {

            _dbcon =  new SqlConnection(connectionString);
        }
      
        #region IDisposable Support
         private  bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                _dbcon = null;

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~basedbfactory() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion

        public virtual bool CheckDBConnectivity()
        {

            bool dbstatus = false;
            try
            {
                //check db connectivity 
                _dbcon.Open();
                if (_dbcon.State == ConnectionState.Open)
                {

                    dbstatus = true;
                }
                else
                {

                    dbstatus = false;
                }


            }
            catch (Exception exp)
            {
                dbstatus = false;
            }
            finally
            {
                _dbcon.Close();
                _dbcon.Dispose();
            }

            return dbstatus;
        }


    }
}
