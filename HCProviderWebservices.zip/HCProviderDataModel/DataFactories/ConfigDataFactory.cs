﻿using Dapper;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataModels;
using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataFactory
{
    public class ConfigDataFactory : basedatafactory, IConfigContract
    {
        ILog _logger;
        public ConfigDataFactory(string connectionstring, ILog logger)
            : base(connectionstring)
        {
            _logger = logger;

        }
        async Task<IdleTimeView> IConfigContract.GetIdleTimeValues()
        {
           List<IdleTime> idleTime = null;
            IdleTimeView idleTimeView = null;
            try
            {

                var pars = new DynamicParameters();
                
                var res = await _dbcon.QueryMultipleAsync("dbo.wapi_getIdleTimeConfig", pars, commandType: CommandType.StoredProcedure);

                idleTime = res.Read<IdleTime>().ToList();
                if (idleTime != null)
                {
                    if (idleTime.Count != 0)
                    {
                        idleTimeView = new IdleTimeView();
                        idleTimeView.IdleTime = idleTime;
                    }
                    else
                    {
                        return idleTimeView = null;
                    }
                }
                return idleTimeView;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);
               
            }
        }

        int IConfigContract.GetServerTimeZoneDiff()
        {
            int res = 0;
            try
            {

                var pars = new DynamicParameters();

                res = _dbcon.Query<int>("dbo.wapi_getServerTimeZoneDiff", pars, commandType: CommandType.StoredProcedure).SingleOrDefault<int>();

                return res;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);
                //Log and Throw
            }

        }
    }
}
