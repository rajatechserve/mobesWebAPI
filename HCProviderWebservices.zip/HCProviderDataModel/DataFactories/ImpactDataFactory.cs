﻿using Dapper;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataFactory;
using HCProviderDataModel.DataModels;
using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataFactories
{
   public class ImpactDataFactory : basedatafactory, IImpactContract 
    {
        ILog _logger;
        public ImpactDataFactory(string connectionstring, ILog logger)
            : base(connectionstring)
        {
            _logger = logger;
        }

        /// <summary>
        /// Add Goal
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="targetedAnnualGoal"></param>
        /// <param name="userId"></param>
        ///  <param name="year"></param>
        /// <returns></returns>

        async Task<int> IImpactContract.AddGoal(int providerId, int targetedAnnualGoal,int userId, int year)
        {
            int result = 0;

            try
            {

                var pars = new DynamicParameters();
                pars.Add("@ProviderID", providerId);
                pars.Add("@Goal", targetedAnnualGoal);
                pars.Add("@UserId", userId); 
                pars.Add("@GoalYear", year);
                pars.Add("@Result", null, DbType.Int32, ParameterDirection.Output);
                await _dbcon.ExecuteScalarAsync<int>("dbo.wapi_addGoal", pars, commandType: CommandType.StoredProcedure);
                 result = pars.Get<int>("Result");                          
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);
            }
            return result;
        }

        /// <summary>
        /// Get Impact List
        /// </summary>
        /// <param name="Type"></param>
        /// <param name="Frequency"></param>
        /// <param name="ProviderId"></param>
        /// <returns></returns>
        async Task<ImpactMetrix> IImpactContract.GetImpactList(int providerId, int inputmonth, int year)
        {

            int month;
            ImpactMetrix impact = null;
            List<MonthlyStat> monthlystat = null;
            DateTime currentDate = DateTime.Now;
            month = inputmonth;
            try
            {
                if (month == 0)
                {
                    month = year < DateTime.Today.Year ? 12 : DateTime.Today.Month;
                }

                var pars = new DynamicParameters();
                pars.Add("@providerId", providerId);
                pars.Add("@month", month);
                pars.Add("@year", year);              


                var aview = await _dbcon.QueryMultipleAsync("dbo.wapi_getImpactList ", pars, commandType: CommandType.StoredProcedure);

                impact = aview.Read<ImpactMetrix>().FirstOrDefault();

                if (inputmonth != 0)
                {
                    monthlystat = aview.Read<MonthlyStat>().Where(x=>x.Month == inputmonth).ToList();
                }
                else
                {
                    monthlystat = aview.Read<MonthlyStat>().ToList();
                }

                if (monthlystat.Count != 0)
                {
                    impact.monthlystat = monthlystat;
                }
                else
                {
                    return impact;
                }
              
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new System.Data.DataException(exp.Message, exp.InnerException);

            }
            return impact;
        }


    }
}
