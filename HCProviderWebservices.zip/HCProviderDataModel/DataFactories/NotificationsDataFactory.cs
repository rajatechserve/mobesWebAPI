﻿using Dapper;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataFactory;
using HCProviderDataModel.DataModels;
using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataFactories
{
    
    public class NotificationsDataFactory : basedatafactory,INotificationsContract 
    {
        ILog _logger;
        public NotificationsDataFactory(string connectionstring, ILog logger) : base(connectionstring)
        {
            _logger = logger;

        }
       async Task<int> INotificationsContract.addAlertSubscription(NotificationsSubscription notificationsSubscription)
        {
            int result = 0;

            try
            {

                var pars = new DynamicParameters();
                pars.Add("@UserRef", notificationsSubscription.userRef);
                pars.Add("@SubscriptionStatus", notificationsSubscription.subscriptionStatus);
                pars.Add("@ConnectionId", notificationsSubscription.currentConnectionId);
                pars.Add("@ConnectionStatus", notificationsSubscription.connectionStatus);
                pars.Add("@UpdatedBy", notificationsSubscription.updatedBy);                
                pars.Add("@Result", null, DbType.Int32, ParameterDirection.Output);

                await _dbcon.ExecuteScalarAsync<int>("dbo.wapi_addMobileAlertSubscription", pars, commandType: CommandType.StoredProcedure);

                int SubscriptionId = pars.Get<int>("Result");

                result = SubscriptionId;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);

            }
            return result;
        }
    }
}
