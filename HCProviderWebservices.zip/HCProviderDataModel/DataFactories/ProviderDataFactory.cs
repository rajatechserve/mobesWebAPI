﻿using HCProviderDataModel.DataContracts;
using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using Dapper;

namespace HCProviderDataModel.DataFactory
{
    public class ProviderDataFactory : basedatafactory, IProviderDataContract
    {
        ILog _logger;
        public ProviderDataFactory(string connectionstring, ILog logger)
            : base(connectionstring)
        {
            _logger = logger;
        }

        async Task<IEnumerable<Provider>> IProviderDataContract.GetProviders(int userid)
        {
            IEnumerable<Provider> providers = null;
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@userid", userid);
                
                var lstProviders = await _dbcon.QueryAsync<Provider>("dbo.wapi_getproviders", pars, commandType: CommandType.StoredProcedure);

                providers = lstProviders;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);
                //Log and Throw
            }
            return providers;
            }
    }
}
