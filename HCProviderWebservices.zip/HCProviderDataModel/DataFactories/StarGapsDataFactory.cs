﻿using Dapper;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataFactory;
using HCProviderDataModel.DataModels;
using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataFactories
{
    public class StarGapsDataFactory : basedatafactory, IStarGapsContract
    {
        ILog _logger;
        public StarGapsDataFactory(string connectionstring, ILog logger)
            : base(connectionstring)
        {
            _logger = logger;
        }

        /// <summary>
        /// Get Star Gaps
        /// </summary>
        /// <param name="ProviderId"></param>
        /// /// <param name="inputmonth"></param>
        /// /// <param name="year"></param>
        /// <returns></returns>
        async Task<StarGapsView> IStarGapsContract.GetStarGaps(int providerId, int inputmonth, int year)
        {

            int month;
            List<StarGaps> starGaps = null;
            StarGapsView starGapsView = null;

            DateTime currentDate = DateTime.Now;
            month = inputmonth;
            try
            {
                if (month == 0)
                {
                    month = year < DateTime.Today.Year ? 12 : DateTime.Today.Month;
                }

                var pars = new DynamicParameters();
                pars.Add("@providerId", providerId);
                pars.Add("@month", month);
                pars.Add("@year", year);
                
                var aview = await _dbcon.QueryAsync<StarGaps>("dbo.wapi_getStarGap_Data", pars, commandType: CommandType.StoredProcedure);

                //starGapsView = aview.Read<StarGapsView>().FirstOrDefault();
                starGapsView = new StarGapsView();
                starGaps = new List<StarGaps>();
                starGaps.Add(aview.SingleOrDefault<StarGaps>());
                //starGaps = aview.Read<StarGaps>().ToList();
                if (starGaps.Count != 0)
                {
                    starGapsView.StarGaps = starGaps;
                }
                else
                {
                    return starGapsView = null;
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
               // throw new System.Data.DataException(exp.Message, exp.InnerException);

            }
            return starGapsView;
        }
    }
}
