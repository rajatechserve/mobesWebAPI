﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using HCProviderDataModel.DataContracts;
using log4net;
using Dapper;
using System.Data;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataFactory
{
    /// <summary>
    ///  SupportDataFactory
    /// </summary>
    public class SupportdataFactory : basedatafactory, ISupportContract
    {
        ILog _logger;
        public SupportdataFactory(string connectionstring, ILog logger) : base(connectionstring)
        {
            logger = _logger;
        }



        /// <summary>
        /// add new clinical contact and return id
        /// </summary>
        /// <param name="contact"></param>
        /// <param name="userid"></param>
        /// <param name="providerid"></param>
        /// <returns></returns>
        //async Task<int> ISupportContract.AddClinicalContact(SupportContact contact, int userid)
        //{
        //    int result;

        //    try
        //    {

        //        var pars = new DynamicParameters();
        //        pars.Add("@ContactName", contact.ContactName);
        //        pars.Add("@ContactNumber", contact.ContactPhone);
        //        pars.Add("@ContactType", contact.ContactType);
        //        pars.Add("@UserRef", userid);
        //        pars.Add("@Result", null, DbType.Int32, ParameterDirection.Output);

        //        await _dbcon.ExecuteScalarAsync<int>("dbo.wapi_addTask", pars, commandType: CommandType.StoredProcedure);

        //        int ContactId = pars.Get<int>("Result");

        //        result = ContactId;

        //    }
        //    catch (Exception exp)
        //    {
        //        _logger.Error("Error :", exp);
        //        throw new DataException(exp.Message, exp);

        //    }
        //    return result;
        //}

        /// <summary>
        /// add new technical contact  and return the id
        /// </summary>
        /// <param name="contact"></param>
        /// <param name="userid"></param>
        /// <param name="providerid"></param>
        /// <returns></returns>
        //async Task<int> ISupportContract.AddTechnicalContact(SupportContact contact, int userid)
        //{
        //    int result;

        //    try
        //    {

        //        var pars = new DynamicParameters();
        //        pars.Add("@ContactName", contact.ContactName);
        //        pars.Add("@ContactNumber", contact.ContactPhone);
        //        pars.Add("@ContactType", contact.ContactType);
        //        pars.Add("@UserRef", userid);
        //        pars.Add("@Result", null, DbType.Int32, ParameterDirection.Output);

        //        await _dbcon.ExecuteScalarAsync<int>("dbo.wapi_addTask", pars, commandType: CommandType.StoredProcedure);

        //        int ContactId = pars.Get<int>("Result");

        //        result = ContactId;

        //    }
        //    catch (Exception exp)
        //    {
        //        _logger.Error("Error :", exp);
        //        throw new DataException(exp.Message, exp);

        //    }
        //    return result;
        //}


        /// <summary>
        /// add or Edit  clinical/technical contact and return id
        /// </summary>
        /// <param name="contact"></param>
        /// <param name="userid"></param>
        /// <param name="providerid"></param>
        /// <returns></returns>
        async Task<int> ISupportContract.AddSupportContact(SupportContact contact, int userid)
        {
            int result=0;

            try
            {

                var pars = new DynamicParameters();
                pars.Add("@ContactName", contact.ContactName);
                pars.Add("@ContactNumber", contact.ContactPhone);
                pars.Add("@ContactType", contact.ContactType);
                pars.Add("@UserRef", userid);
                pars.Add("@Result", null, DbType.Int32, ParameterDirection.Output);

                await _dbcon.ExecuteScalarAsync<int>("dbo.wapi_addUserContact", pars, commandType: CommandType.StoredProcedure);

                int ContactId = pars.Get<int>("Result");

                result = ContactId;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);

            }
            return result;
        }


        /// <summary>
        /// mark user defined contact as removed/deleted
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="contactid"></param>
        /// <param name="providerid"></param>
        /// <returns></returns>
        async Task<int> ISupportContract.DeleteSupportContact(int userid, int contactid)
        {
            int result=0;

            try
            {

                var pars = new DynamicParameters();
                pars.Add("@ContactIdentifier", contactid);
                pars.Add("@UserRef", userid);
                pars.Add("@Result", null, DbType.Int32, ParameterDirection.Output);

                await _dbcon.ExecuteScalarAsync<int>("dbo.wapi_deleteUserContact", pars, commandType: CommandType.StoredProcedure);

                int ContactId = pars.Get<int>("Result");

                result = ContactId;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);

            }
            return result;
        }

        /// <summary>
        /// return List of support learning objects
        /// </summary>
        /// <param name="learningtype"></param>
        /// <param name="userid"></param>
        /// <param name="providerid"></param>
        /// <param name="learningId"></param>
        /// <returns></returns>

        IEnumerable<Supportlearning> ISupportContract.GetLearnings(int userid, int learningId, string learningtype)
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// Get Contacts  all/clinical/technical/memberservice
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="contacttype">default filter all, support multiple comma seperated, filter?contacttype= all/clinical/technical/memberservice</param>
        /// <returns></returns>
        async Task<IEnumerable<SupportContact>> ISupportContract.GetSupportContacts(string contacttype, int userid, int contactid)
        {

            IEnumerable<SupportContact> supportcontact = null;
            try
            {

                var pars = new DynamicParameters();
                pars.Add("@contactType", contacttype);
                pars.Add("@userId", userid);
                pars.Add("@contactId", contactid);
                var supportcontacttask = await _dbcon.QueryAsync<SupportContact>("dbo.wapi_getContacts", pars, commandType: CommandType.StoredProcedure);

                supportcontact = supportcontacttask;


            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);
                //Log and Throw
            }
            return supportcontact;
        }

        async Task<int> ISupportContract.UpdateSupportContact(SupportContact contact, int userid)
        {
            int result=0;

            try
            {

                var pars = new DynamicParameters();
                pars.Add("@ContactIdentifier", contact.ContactId);
                pars.Add("@ContactName", contact.ContactName);
                pars.Add("@ContactNumber", contact.ContactPhone);
                pars.Add("@ContactType", contact.ContactType);
                pars.Add("@UserRef", userid);
                pars.Add("@Result", null, DbType.Int32, ParameterDirection.Output);

                await _dbcon.ExecuteScalarAsync<int>("dbo.wapi_updateUserContact", pars, commandType: CommandType.StoredProcedure);

                int ContactId = pars.Get<int>("Result");

                result = ContactId;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);

            }
            return result;
        }
    }
}