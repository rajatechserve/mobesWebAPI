﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataFactory;
using log4net;
using System.Data;
using Dapper;

namespace HCProviderDataModel.DataFactories
{
    public class TaskDataFactory : basedatafactory, ITaskDataContract
    {
        ILog _logger;
        public TaskDataFactory(string connectionstring, ILog logger) : base(connectionstring)
        {
            _logger = logger;

        }
        /// <summary>
        /// Add Task
        /// </summary>
        /// <param name="TaskName"></param>
        /// <param name="TaskDescription"></param>
        /// <param name="TaskDueDate"></param>
        /// <param name="TaskCreatedBy"></param>
        /// <returns>TaskID</returns>
        async Task<int> ITaskDataContract.AddTask(string TaskName, string TaskDescription, DateTime TaskDueDate, int TaskCreatedBy)
        {
            int result=0;

            try
            {

                var pars = new DynamicParameters();
                pars.Add("@TaskName", TaskName);
                pars.Add("@TaskDescription", TaskDescription);
                pars.Add("@DueByDate", TaskDueDate);
                pars.Add("@CreatedByIdentifier", TaskCreatedBy);
                pars.Add("@Result",null, DbType.Int32, ParameterDirection.Output);
                              
                await _dbcon.ExecuteScalarAsync<int>("dbo.wapi_addTask", pars, commandType: CommandType.StoredProcedure);

                int TaskId = pars.Get<int>("Result");
              
               result = TaskId;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);

            }
            return result;
        }

        /// <summary>
        /// Update Task
        /// </summary>
        /// <param name="TaskName"></param>
        /// <param name="TaskDescription"></param>
        /// <param name="TaskDueDate"></param>
        /// <param name="TaskCreatedBy"></param>
        /// <returns>TaskID</returns>
        async Task<int> ITaskDataContract.UpdateTask(int taskId, string taskName, string taskDescription, string taskStatus, int taskUpdatedBy, DateTime? taskDueDate)
        {

            int result = 1;
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@TaskId", taskId);
                pars.Add("@TaskName", taskName);
                pars.Add("@TaskDescription", taskDescription);
                pars.Add("@Status", taskStatus);
                pars.Add("@DueByDate", taskDueDate);
                pars.Add("@UpdatedByIdentifier", taskUpdatedBy);
                pars.Add("@Result", null, DbType.Int32, ParameterDirection.ReturnValue);
                await _dbcon.ExecuteScalarAsync<int>("dbo.wapi_updateTask", pars, commandType: CommandType.StoredProcedure);
                result = pars.Get<int>("Result");                                  
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);

            }
            return result;
        }

               /// <summary>
        /// Get Tasks
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <param name="preDate"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="status"></param>
        /// <param name="pagesize"></param>
        /// <param name="pagenumber"></param>
        /// <returns>TaskList</returns>

        async Task<TaskView> ITaskDataContract.GetTaskList(int userid, int? taskid, DateTime? fromDate, DateTime? toDate,  int? pagesize, int? pagenumber, string status)
        {

           List<Task> tasks = null;
            TaskView taskViews = null;
            try
            {

                var pars = new DynamicParameters();
                pars.Add("@Userid", userid);
                pars.Add("@Taskid", taskid);
                pars.Add("@fromDate", fromDate);
                pars.Add("@toDate", toDate);
                pars.Add("@Status", status);
                pars.Add("@pagesize", pagesize);
                pars.Add("@pageNumber", pagenumber);

                var  aview = await _dbcon.QueryMultipleAsync("dbo.wapi_getTasks", pars, commandType: CommandType.StoredProcedure);

                taskViews = aview.Read<TaskView>().FirstOrDefault();
                tasks = aview.Read<Task>().ToList();
                if (tasks.Count != 0)
                {
                    taskViews.Task = tasks;
                }
                else
                {
                    return taskViews = null;
                }


            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);

            }
            return taskViews;

        }

        async Task<TaskView> ITaskDataContract.GetNewTaskList(int userid, int? taskid, DateTime? fromDate, DateTime? toDate, int? pagesize, int? pagenumber, string status)
        {

            List<Task> tasks = null;
            TaskView taskViews = null;
            try
            {

                var pars = new DynamicParameters();
                pars.Add("@Userid", userid);
                pars.Add("@Taskid", taskid);
                pars.Add("@fromDate", fromDate);
                pars.Add("@toDate", toDate);
                pars.Add("@Status", status);
                pars.Add("@pagesize", pagesize);
                pars.Add("@pageNumber", pagenumber);

                var aview = await _dbcon.QueryMultipleAsync("dbo.wapi_getNewTasks", pars, commandType: CommandType.StoredProcedure);

                taskViews = aview.Read<TaskView>().FirstOrDefault();
                tasks = aview.Read<Task>().ToList();
                if (tasks.Count != 0)
                {
                    taskViews.Task = tasks;
                }
                else
                {
                    return taskViews = null;
                }


            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
               // throw new DataException(exp.Message, exp);

            }
            return taskViews;

        }

        /// <summary>
        /// Get Task Count View
        /// </summary>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        async Task<IEnumerable<TaskCount>> ITaskDataContract.GetTaskCountView(int year, int month, int userid)
        {
            IEnumerable<TaskCount> taskView = null;
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@userId", userid);
                pars.Add("@year", year);
                pars.Add("@month", month);
                var aview = await _dbcon.QueryAsync<TaskCount>("dbo.wapi_getTaskView", pars, commandType: CommandType.StoredProcedure);
                taskView = aview;
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp.InnerException);

            }
            return taskView;
        }


        //throw new NotImplementedException();

    }
}
