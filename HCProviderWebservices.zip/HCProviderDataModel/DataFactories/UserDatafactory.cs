﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using HCProviderDataModel.DataContracts;
using System.Data;
using log4net;

namespace HCProviderDataModel.DataFactory
{
    public class UserDatafactory : basedatafactory, IUsercontract
    {
        ILog _logger;
        public UserDatafactory(string connectionstring, ILog logger)
            : base(connectionstring)
        {
            _logger = logger;

        }


        User IUsercontract.GetUserById(int userid)
        {
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@userid", userid);

                ///TODO - wapi_getuser

                var user = _dbcon.Query<User>("wapi_getuser", pars, commandType: CommandType.StoredProcedure).SingleOrDefault<User>();

                return user;
            }
            catch (Exception ex)
            {

            }
            return null;
        }


        User IUsercontract.GetUserBylogin(string login)
        {
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@Login_Name", login);


                var user = _dbcon.Query<User>("wapi_getuser", pars, commandType: CommandType.StoredProcedure).SingleOrDefault<User>();

                return user;
            }
            catch (Exception ex)
            {

            }
            return null;
        }





        User IUsercontract.GetUserByToken(string token)
        {
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@Login_Name", token);


                var user = _dbcon.Query<User>("wapi_getuser", pars, commandType: CommandType.StoredProcedure).SingleOrDefault<User>();

                return user;
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        User IUsercontract.GetUser(string username, string password)
        {
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@userid", username);
                pars.Add("@password", password);


                //var user = _dbcon.Query<User>("wapi_getuser", pars, commandType: CommandType.StoredProcedure).SingleOrDefault<User>();
                var user = new User() { userid = 1, providerid = 78473 };

                return user;
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        User IUsercontract.GetUserByOptumId(string optumId)
        {
            try
            {
                var pars = new DynamicParameters();
                pars.Add("@optumId", optumId);

                var user = _dbcon.Query<User>("dbo.wapi_getUserProfileByOptumId", pars, commandType: CommandType.StoredProcedure).SingleOrDefault<User>();
                return user;
            }
            catch (Exception ex)
            {

            }
            return null;
        }

    }



}
