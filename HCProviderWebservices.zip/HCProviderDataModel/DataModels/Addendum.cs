﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataModels
{
    public sealed class Addendum
    {
        public DateTime Date { get; set; }
        public string Type { get; set; }
        public string Wave { get; set; }
        public int HCC_Amendment_ID { get; set; }
    }

}
