﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HCProviderDataModel
{
    public sealed class AlertView
    {
        /// <summary>
        /// providerid
        /// </summary>
        public int RecordCount { get; set; }
        /// <summary>
        /// Year
        /// </summary>
        public int PageCount { get; set; }



        /// <summary>
        /// AppointmentCount
        /// </summary>
        public List<Alert> Alert;
        public AlertView()
        {


        }
    }
    public sealed class Alert
    {
        public int AlertId { get; set; }

        public string Message { get; set; }

        public string Title { get; set; }

        public DateTime AlertDate { get; set; }

        //ACknolwedged / Acknolwedged
        public string Ackstatus { get; set; }


        public DateTime Expiry { get; set; }


        public string source { get; set; }

        public string NotificationType { get; set; }

    }






}