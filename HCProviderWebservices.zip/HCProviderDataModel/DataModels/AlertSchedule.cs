﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HCProviderDataModel
{
    public sealed class AlertScheduleView
    {
        /// <summary>
        /// providerid
        /// </summary>
        public int RecordCount { get; set; }
        /// <summary>
        /// Year
        /// </summary>
        public int PageCount { get; set; }



        /// <summary>
        /// AppointmentCount
        /// </summary>
        public List<AlertSchedule> Alert;
        public AlertScheduleView()
        {


        }
    }
    public sealed class AlertSchedule
    {
        //public int AlertId { get; set; }

        //public string Message { get; set; }

        //public string Title { get; set; }

        //public DateTime AlertDate { get; set; }

        ////ACknolwedged / Acknolwedged
        //public string Ackstatus { get; set; }


        //public DateTime Expiry { get; set; }


        //public string source { get; set; }

        //public string NotificationType { get; set; }
        public long dm_patient_id { get; set; }
        public long member_call_schedule_id { get; set; }
        public string Member { get; set; }
        public DateTime? CancelledAppointmentDate { get; set; }
        public DateTime? RescheduledAppointmentDate { get; set; }
        public string Notes { get; set; }
        public string Type { get; set; }
        public DateTime? OriginalAppointmentDate { get; set; }
        

    }






}