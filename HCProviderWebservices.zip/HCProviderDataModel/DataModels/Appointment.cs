﻿
using System;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;

namespace HCProviderDataModel

{

    public sealed class Appointment
    {

        public int AppointmentId { get; set; }

        public int ProviderId { get; set; }

        public DateTime SlotStart { get; set; }

        public DateTime SlotEnd { get; set; }

        public string TransLanguage { get; set; }

        public int FluVaccine { get; set; }

        public int MTMRequired { get; set; }
        public string LabKit { get; set; }
        public string Status { get; set; }

        public string SubStatus { get; set; }

        public string PatientID { get; set; }

        public string firstname { get; set; }

        public string middlename { get; set; }

        public string lastname { get; set; }

        public string Addressline1 { get; set; }

        public string Addressline2 { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string Zip5 { get; set; }

        public string Zip4 { get; set; }
        public string Source { get; set; }

        public string SubSource { get; set; }

        public string LOB_NM { get; set; }
        public string CLI_NM { get; set; }
        public string SUBCLI_NM { get; set; }
        public string GRP_NM { get; set; }
        public string CDO_NM { get; set; }

        public string MemberCategory { get; set; }
        public string Notes { get; set; }

        public string PrimaryPhone { get; set; }
        public string AlternatePhone { get; set; }

        public int AddressOrder { get; set; }
        public string FamilyInfo { get; set; }

        public string Lat { get; set; }

        public string Long { get; set; }
        public string VisitAddress { get; set; }
        public string LastyearInfo { get; set; }

        public bool Is_AltLoc { get; set; }
        public string Loc_Name { get; set; }
        public string Loc_Type { get; set; }
        public string Loc_Address { get; set; }
        public int Member_Count { get; set; }
        public bool Is_AutoCall_Placed { get; set; }

        public string Auto_Call_Status { get; set; }

        public DateTime Autocall_StartTime { get; set; }
        public DateTime Autocall_EndTime { get; set; }


    }






}