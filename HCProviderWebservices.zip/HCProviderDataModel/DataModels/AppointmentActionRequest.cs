﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderEntities
{
   public class AppointmentActionRequest
    {

        public int appointmentId { get; set; }
        public bool triggerIVR { get; set; }

       
    }
}
