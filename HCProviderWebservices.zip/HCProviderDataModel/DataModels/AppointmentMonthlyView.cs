﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
namespace HCProviderDataModel
{
    
    public sealed class AppointmentCountView
    {
        /// <summary>
        /// providerid
        /// </summary>
        public int providerid { get; set; }
        /// <summary>
        /// Year
        /// </summary>
        public int Year { get; set; }

        /// <summary>
        /// Month
        /// </summary>
        public int Month { get; set; }

        /// <summary>
        /// AppointmentCount
        /// </summary>
        public List<AppointmentCount> AppointmentCount;
        public AppointmentCountView()
        {


        }
    }
    public sealed class AppointmentCount
    {
        /// <summary>
        /// count
        /// </summary>
        public int Count { get; set; }
        /// <summary>
        /// Appointmentdate
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// AppointmentCount
        /// </summary>
        public AppointmentCount()
        {


        }

    }
}
