﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HCProviderDataModel
{
    public sealed class DailySupply
    {
        /// <summary>
        /// providerid
        /// </summary>
        public int providerid { get; set; }

        /// <summary>
        /// aptdate
        /// </summary>
        public DateTime aptdate { get; set; }

        /// <summary>
        /// SupplyCount
        /// </summary>
        public List<SupplyCount> SupplyCount;

    }


    /// <summary>
    /// SupplyCount
    /// </summary>
    public sealed class SupplyCount
    {

        /// <summary>
        /// SupplyCount()
        /// </summary>
        public SupplyCount()
        {


        }
        /// <summary>
        /// Category
        /// </summary>
        public string Category { get; set; }

        /// <summary>
        /// itemId
        /// </summary>
        public string itemId { get; set; }

        /// <summary>
        /// SupplyName
        /// </summary>
        public string SupplyName { get; set; }

        /// <summary>
        /// SortOrder
        /// </summary>
        public string SortOrder { get; set; }

        /// <summary>
        /// Count
        /// </summary>
        public string Count { get; set; }
        

    }
}