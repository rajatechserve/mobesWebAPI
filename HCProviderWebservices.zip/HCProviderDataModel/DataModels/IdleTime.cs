﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataModels
{
    public sealed class IdleTimeView
    {
        /// <summary>
        /// providerid
        /// </summary>
        public int RecordCount { get; set; }
        /// <summary>
        /// Year
        /// </summary>
        public int PageCount { get; set; }



        /// <summary>
        /// AppointmentCount
        /// </summary>
        public List<IdleTime> IdleTime;
        public IdleTimeView()
        {


        }
    }
    public sealed class IdleTime
    {
        public int IdleTimeWarnMins { get; set; }
        public int IdleTimeLogoutMins { get; set; }
    }
}
