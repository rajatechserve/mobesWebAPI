﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataModels
{
    public sealed class ImpactMetrix
    {              
        public int? ProviderId { get; set; }
        public int? Year { get; set; }
        public int? AnnualGoal { get; set; }

        public List<MonthlyStat> monthlystat;
        public ImpactMetrix() { }
    }

        public sealed class MonthlyStat
         {
            public int? Month { get; set; }
            public int? VisitTotal { get; set; }
            public int? TeamTotal { get; set; }      
            public int? NetworkTotal { get; set; }      
            public int? LabsCompletionRate_FOBT { get; set; }
            public int? LabsCompletionRate_A1C { get; set; }
            public int? VisitCompletionRate { get; set; }
            public int? ChartReturnTime { get; set; }
            public int? QualityAssurance { get; set; }
            public DateTime? SyncDateTime { get; set; }
        }
}

