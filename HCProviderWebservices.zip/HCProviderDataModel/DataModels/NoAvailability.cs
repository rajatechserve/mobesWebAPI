﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataModels
{
    public sealed class NoAvailability
    {
        public DateTime FROM_DATE { get; set; }
        public DateTime TO_DATE { get; set; }
        public int COMMITED { get; set; }
        public int DEFINED_HOURS { get; set; }
        public int DEFICIT_HOURS { get; set; }


    }
}
