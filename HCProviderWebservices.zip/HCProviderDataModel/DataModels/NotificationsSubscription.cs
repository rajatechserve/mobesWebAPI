﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataModels
{
   public class NotificationsSubscription
    {
        public int hubSubscriptionId { get; set; }
        public int userRef { get; set; }
        public string subscriptionStatus { get; set; }
        public string currentConnectionId { get; set; }
        public string connectionStatus { get; set; }
        public int updatedBy { get; set; }

        public DateTime updatedOnDateTime { get; set; }

        public DateTime createdOnDateTime { get; set; }

    }
}
