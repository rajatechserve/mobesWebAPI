﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataModels
{
   public sealed class PTOAlertView
    {
        public String MESSAGE { get; set; }
        public String PTO_STATUS { get; set; }
        public String TYPE { get; set; }

    }
}
