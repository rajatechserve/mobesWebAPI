﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataModels
{
    public sealed class QualityAssurance
    {
        public string TYPE { get; set; }

        public int RECORDCOUNT { get; set; }

    }
}
