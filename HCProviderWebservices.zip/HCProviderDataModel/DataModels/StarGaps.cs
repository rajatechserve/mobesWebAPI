﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel.DataModels
{
    public sealed class StarGapsView
    {

        public int RecordCount { get; set; }

        public int PageCount { get; set; }

        public List<StarGaps> StarGaps;
        public StarGapsView()
        {
        }
    }
    public sealed class StarGaps
    {
        public int? TOTAL_GAPS_CLOSED { get; set; }
        public int? TOTAL_GAPS_NOT_CLOSED { get; set; }
        public string CONSISTENT_GAP_CLOSED { get; set; }
        public string NONCONSISTENT_GAP_CLOSED { get; set; }
        public int? A1C_GAP_CLOSED { get; set; }
        public int? FOBT_GAP_CLOSED { get; set; }
        public int? URINE_DIPSTICK_GAP_CLOSED { get; set; }
        public int? BMI_GAP_CLOSED { get; set; }
        public int? A1C_GAP_NOT_CLOSED { get; set; }
        public int? FOBT_GAP_NOT_CLOSED { get; set; }
        public int? URINE_DIPSTICK_GAP_NOT_CLOSED { get; set; }
        public int? BMI_NOT_GAP_CLOSED { get; set; }
        public float? PERCENT_GAP_CLOSED { get; set; }

    }
}
