﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel
{


    public sealed class SupportContact
    {
        /// <summary>
        /// contact Name
        /// </summary>
        public string ContactName { set; get; }

        /// <summary>
        /// contact phone number
        /// </summary>
        public string ContactPhone { set; get; }

        /// <summary>
        /// clinical/technical/member service 
        /// </summary>
       
        public string ContactType { get; set; }

        
        /// <summary>
        /// contact id
        /// </summary>
        public int ContactId { get; set; }

        /// <summary>
        /// contact status
        /// </summary>
        public int Status { get; set; }

        /// <summary>
        /// system/user
        /// users cannot remove system contacts
        /// users can remove only remove/modify user added contact
        /// </summary>
        // public string contactgroup { get; set; }
       // public string ContactGroup { get; set; }

        /// <summary>
        /// Action -- Add/Edit/Delete
        /// </summary>

       // public string Action { get; set; }

    }
}
