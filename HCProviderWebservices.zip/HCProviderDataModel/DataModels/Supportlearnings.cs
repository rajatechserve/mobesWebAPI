﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel
{
   public sealed class Supportlearning
    {

        public int learningid { get; set; }
     public   string learningtitle { get; set; }

        /// <summary>
        /// video/pdf/audio
        /// </summary>
        public string contenttype { get; set; } 
        

        /// <summary>
        /// file extn
        /// mp3/mp4/
        /// </summary>
        public string contentsubtype { get; set; }


        /// <summary>
        /// clinical/techincal
        /// </summary>
        public string learningtype { get; set; }

        /// <summary>
        /// Filepath for resource
        /// </summary>
        public string filepath { get; set; }

        

    }
}
