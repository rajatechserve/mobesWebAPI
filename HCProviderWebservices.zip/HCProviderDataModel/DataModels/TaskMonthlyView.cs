﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
namespace HCProviderDataModel
{
    
    public sealed class TaskCountView
    {
        
        /// <summary>
        /// Year
        /// </summary>
        public int Year { get; set; }

        /// <summary>
        /// Month
        /// </summary>
        public int Month { get; set; }

        /// <summary>
        /// AppointmentCount
        /// </summary>
        public List<TaskCount> TaskCount;
        public TaskCountView()
        {


        }
    }
    public sealed class TaskCount
    {
        /// <summary>
        /// count
        /// </summary>
        public int Count { get; set; }
        /// <summary>
        /// Appointmentdate
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// AppointmentCount
        /// </summary>
        public TaskCount()
        {


        }

    }
}
