﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HCProviderDataModel
{


    public sealed class TaskView
    {
        /// <summary>
        /// providerid
        /// </summary>
        public int RecordCount { get; set; }
        /// <summary>
        /// Year
        /// </summary>
        public int PageCount { get; set; }

        

        /// <summary>
        /// AppointmentCount
        /// </summary>
        public List<Task> Task;
        public TaskView()
        {


        }
    }
    public sealed class Task    {
               
        public int TaskId { get; set; }

        public string TaskName { get; set; }

        public string TaskDescription { get; set; }

        public DateTime TaskDue { get; set; }

        public string TaskStatus { get; set; }


        public string AssignedBy { get; set; }

        public DateTime AssignedOn { get; set; }

    }
}