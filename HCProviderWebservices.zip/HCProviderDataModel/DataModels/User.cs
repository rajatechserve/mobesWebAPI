﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderDataModel
{
 public sealed class User
    {

        public User()
        {
            Claims = new List<UserClaim>();
        }

        public int userid { get; set; }
        public string login { get; set; }
        public string Name { get; set; }
        
        public string PasswordHash { get; set; }
        public string Credentials { get; set; }

         public int providerid { get; set; }

        public IEnumerable<UserClaim> Claims;

        public string ErrorCode { get; set; }

        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public DateTime? LastLoginDateTime { get; set; }
        public string ProviderName { get; set; }
    }

    /// <summary>
    /// User Roles
    /// </summary>
    public sealed class UserClaim
    {

        public int userid { get; set; }
        public string claimType { get; set; }
        public string claimValue { get; set; }


    }







}


