﻿using System;
using System.Data.SqlClient;
using System.Data;

namespace HCProviderServices
{
    public  class DBSettings
    {
        string _connectionstring = string.Empty;
        private IDbConnection _db;


        public DBSettings(string connectionstring)
        {
            _connectionstring = connectionstring;
        }
     
        public  bool CheckDBConnectivity()
        {

            bool dbstatus = false;
            
            try
            {
                if (string.IsNullOrWhiteSpace(_connectionstring))
                    return false;


                _db = new SqlConnection(_connectionstring);
                //check db connectivity 
                _db.Open();
                if (_db.State == ConnectionState.Open)
                {

                    dbstatus = true;
                }
                else
                {
                  
                    dbstatus = false;
                }
             

            }
            catch (Exception exp)
            {
                dbstatus = false;
                throw new DataException("Unable to Connect to database", exp.InnerException);

               
            }
            finally {
                _db.Close();
                _db.Dispose();
            }
            
            return dbstatus;
        }

        
    }

}