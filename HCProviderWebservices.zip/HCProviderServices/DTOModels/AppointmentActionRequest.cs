﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderServices.DTOModels
{
   public sealed class AppointmentActionRequest
    {

        public int appointmentId { get; set; }
        public bool triggerIVR { get; set; }

       
    }
}
