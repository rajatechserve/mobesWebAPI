﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderServices.DTOModels
{
   public class notification
    {

        public string message
        {
            get; set;
        }
        public int id
        {
            get; set;
        }

        public bool AckRequired { get; set; }

        public DateTime expiry { get; set; }

        public string source { get; set;}


    }
}
