﻿using HCProviderDataModel.DataModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderServices.DTOModels
{
    public class v1Addendumdto
    {
        


        public v1Addendumdto(Addendum view)
        {

            try
            {
                this.Date = view.Date;
                this.Type = view.Type;
                this.Wave = view.Wave;
                this.HCC_Amendment_ID = view.HCC_Amendment_ID;
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }

        }

        public DateTime Date { get; set; }
        public string Type { get; set; }
        public string Wave { get; set; }
        public int HCC_Amendment_ID { get; set; }
    }
}
