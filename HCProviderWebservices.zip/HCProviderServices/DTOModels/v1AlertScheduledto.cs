﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HCProviderDataModel;
using System.Data;

namespace HCProviderServices.DTOModels
{
    public class v1AlertScheduledto
    {

        /// <summary>
        /// RecordCount
        /// </summary>
        public int RecordCount { get; set; }
        /// <summary>
        /// PageCount
        /// </summary>
        public int PageCount { get; set; }



        /// <summary>
        /// Alert
        /// </summary>
        public List<AlertSchedule> Alert;

        /// <summary>
        /// v1Alertdto
        /// </summary>
        /// <param name="view"></param>
        public v1AlertScheduledto(AlertScheduleView view)
        {

            try
            {
                this.RecordCount = view.RecordCount;
                this.PageCount = view.PageCount;
                foreach (AlertSchedule alert in view.Alert)
                {
                    if (this.Alert == null)
                    {
                        this.Alert = new List<AlertSchedule>();
                    }

                    this.Alert.Add(alert);
                }
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }

        }
    }






}