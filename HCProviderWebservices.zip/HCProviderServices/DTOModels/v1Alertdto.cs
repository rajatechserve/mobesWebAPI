﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HCProviderDataModel;
using System.Data;

namespace HCProviderServices.DTOModels
{
    public class v1Alertdto
    {

        /// <summary>
        /// RecordCount
        /// </summary>
        public int RecordCount { get; set; }
        /// <summary>
        /// PageCount
        /// </summary>
        public int PageCount { get; set; }



        /// <summary>
        /// Alert
        /// </summary>
        public List<Alert> Alert;

        /// <summary>
        /// v1Alertdto
        /// </summary>
        /// <param name="view"></param>
        public v1Alertdto(AlertView view)
        {

            try
            {
                this.RecordCount = view.RecordCount;
                this.PageCount = view.PageCount;
                foreach (Alert alert in view.Alert)
                {
                    if (this.Alert == null)
                    {
                        this.Alert = new List<Alert>();
                    }
                    alert.AlertDate = alert.AlertDate.ToUniversalTime();
                    alert.Expiry = alert.Expiry.ToUniversalTime();
                    this.Alert.Add(alert);
                }
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }

        }
    }





   
}