﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HCProviderDataModel;
using System.Reflection;
using System.Data;

namespace HCProviderServices.DTOModels
{
    

    public class v1AppointmentCountViewDto 
    {
        /// <summary>
        /// providerId
        /// </summary>
        public int providerId { get; set; }

        /// <summary>
        /// Year
        /// </summary>
        public int Year { get; set; }

        public List<AppointmentCount> AppointmentCounts;
        /// <summary>
        /// 1-Jan ,2-Feb,.....12-Dec
        /// </summary>
        public int Month { get; set; }



        /// <summary>
        /// v1AppointmentCountViewDto
        /// </summary>
        public v1AppointmentCountViewDto()
        {


        }

        /// <summary>
        /// v1AppointmentCountViewDto
        /// </summary>
        /// <param name="view"></param>
        public v1AppointmentCountViewDto(AppointmentCountView view)
        {
            try
            {
                this.providerId = view.providerid;
                this.Year = view.Year;
                this.Month = view.Month;
                foreach (AppointmentCount apt in view.AppointmentCount)
                {
                    if (this.AppointmentCounts == null)
                    {
                        this.AppointmentCounts = new List<AppointmentCount>();
                    }
                    this.AppointmentCounts.Add(apt);
                }
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }

        }


        /// <summary>
        /// v1AppointmentCountViewDto
        /// </summary>
        /// <param name="viewdto"></param>
        public v1AppointmentCountViewDto(v1AppointmentCountViewDto viewdto)
        {

            //this.count = viewdto.count;
            //this.Appointmentdate = viewdto.Appointmentdate;
        }
    }
    //public class v1AppointmentCountDto
    //{
    //    public int count { get; set; }
    //    public DateTime Appointmentdate { get; set; }
    //}
}
