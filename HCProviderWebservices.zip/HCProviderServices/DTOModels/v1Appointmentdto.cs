﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using HCProviderDataModel;
using System.Data;

namespace HCProviderServices.DTOModels
{
    /// <summary>
    /// Appointment
    /// version:1
    /// 
    ///</summary>
    public class v1Appointmentdto : v1basedto
    {


        public v1Appointmentdto()
        { }


        /// <summary>
        /// v1Appointmentdto
        /// </summary>
        /// <param name="appt"></param>
        public v1Appointmentdto(Appointment appt)
        {

            try
            {
                // initialize all values from appt to model
                this.id = appt.AppointmentId;
                this.AddressLine1 = appt.Addressline1;
                this.AddressLine2 = appt.Addressline2;
                this.id = appt.AppointmentId;
                this.AppointmentDate = appt.SlotStart;
                this.Appointmentstatus = appt.Status;
                this.ApptTime = appt.SlotStart.ToString("hh:mm tt") + "-" + appt.SlotEnd.ToString("hh:mm tt");
                this.Providerid = appt.ProviderId;
                this.labKit = appt.LabKit;
                this.isMTM = appt.MTMRequired > 0 ? true : false;
                this.isFlu = appt.FluVaccine > 0 ? true : false;
                this.FirstName = appt.firstname;
                this.MiddleName = appt.middlename;
                this.LastName = appt.lastname;
                this.MemberId = appt.PatientID;
                this.PrimaryPhone = appt.PrimaryPhone;
                this.MobilePhone = appt.AlternatePhone;
                this.TransLanguage = appt.TransLanguage;
                this.TeamCareNotes = appt.Notes;
                this.languages = appt.TransLanguage;
                this.MemberSource = appt.SubSource;


                this.Long = appt.Long;
                this.Lat = appt.Lat;
                this.State = appt.State;
                this.City = appt.City;
                this.Zip = appt.Zip5 + (!string.IsNullOrWhiteSpace(appt.Zip4) ? "-" + appt.Zip4 : "");
                this.FamilyInfo = appt.FamilyInfo;
                this.Directions = "";
                this.ApptVisitOrder = appt.AddressOrder;
                this.VisitAddress = appt.VisitAddress;
                this.LastyearInfo = appt.LastyearInfo;
                
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }

        }

        /// <summary>
        /// Addressline 1
        /// 
        /// </summary>
        public string AddressLine1
        {
            get;
            set;
        }

        /// <summary>
        /// ApptVisitOrder
        /// </summary>
        public int ApptVisitOrder { get; set; }


        /// <summary>
        /// Appointment Date
        /// </summary>
        public DateTime AppointmentDate
        {
            get;
            set;
        }


        public string ApptTime
        {
            get;
            set;
        }

        /// <summary>
        /// Member Name
        /// </summary>
        public string FirstName
        {
            get;
            set;
        }


        /// <summary>
        /// Member Last Name
        /// </summary>
        public string LastName
        {
            get;
            set;
        }


        /// <summary>
        /// Member Last Name
        /// </summary>
        public string MiddleName
        {
            get;
            set;
        }

        /// <summary>
        /// Member/Patient Id
        /// </summary>
        public string MemberId
        {
            get;
            set;
        }

        /// <summary>
        /// PrimaryPhone
        /// </summary>
        public string PrimaryPhone
        {
            get;
            set;
        }

        /// <summary>
        /// MobilePhone
        /// </summary>
        public string MobilePhone { get; set; }

        /// <summary>
        /// Providerid
        /// </summary>
        public int Providerid
        {
            get;
            set;
        }

        /// <summary>
        /// AddressLine2
        /// </summary>
        public string AddressLine2
        {
            get;
            set;
        }

        /// <summary>
        /// City
        /// </summary>
        public string City
        { get; set; }


        /// <summary>
        /// State
        /// </summary>
        public string State
        { get; set; }


        /// <summary>
        /// Zip
        /// </summary>
        public string Zip
        { get; set; }


        /// <summary>
        /// flu vaccine?
        /// </summary>
        public bool isFlu
        { get; set; }


        /// <summary>
        /// ilabkit - 1/2/3/4
        /// </summary>
        public string labKit
        { get; set; }

        /// <summary>
        /// MTM required?
        /// </summary>
        public bool isMTM
        { get; set; }

        /// <summary>
        /// TeamCareNotes
        /// </summary>
        public string TeamCareNotes
        { get; set; }

        /// <summary>
        /// languages
        /// </summary>
        public string languages
        { get; set; }


        /// <summary>
        /// FamilyInfo
        /// </summary>
        public string FamilyInfo
        { get; set; }

        /// <summary>
        /// Directions
        /// </summary>
        public string Directions
        { get; set; }

        public string MemberSource
        { get; set; }

        /// <summary>
        /// Tranlator Language
        /// </summary>
        public string TransLanguage
        { get; set; }


        /// <summary>
        /// appointment Status
        /// </summary>
        public string Appointmentstatus { get; set; }

        public string Lat { get; set; }

        public string Long { get; set; }

        public string VisitAddress { get; set; }
        public string LastyearInfo { get; set; }
        
        public v1Appointmentdto(v1Appointmentdto apt)
        {

            foreach (PropertyInfo p in apt.GetType().GetProperties())
            {
                p.SetValue(this, p.GetValue(apt));
            }

        }

    }



}
