﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HCProviderDataModel;
using System.Data;

namespace HCProviderServices.DTOModels
{
    public class v1DailySupplydto 
    {

        /// <summary>
        /// v1DailySupplydto
        /// </summary>
        public v1DailySupplydto()
        {


        }

        /// <summary>
        /// v1DailySupplydto
        /// </summary>
        /// <param name="supply"></param>
        public v1DailySupplydto(DailySupply supply)
        {
            
            try
            {
                this.providerid = supply.providerid;
                this.aptdate = supply.aptdate;
                
                foreach (SupplyCount apt in supply.SupplyCount)
                {
                    if (this.SupplyCount == null)
                    {
                        this.SupplyCount = new List<SupplyCount>();
                    }
                    this.SupplyCount.Add(apt);
                }
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }


        }


        /// <summary>
        /// aptdate
        /// </summary>
        public DateTime aptdate { get; set; }


        /// <summary>
        /// providerid
        /// </summary>
        public int providerid { get; set; }


        /// <summary>
        /// SupplyCount
        /// </summary>
        public List<SupplyCount> SupplyCount;

    }
}