﻿using HCProviderServices.DTOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HCProviderDataModel;
using System.Data;
using HCProviderDataModel.DataModels;

namespace HCProviderServices.DTOModels
{
    public class v1IdleTimedto 
    {

        /// <summary>
        /// providerid
        /// </summary>
        public int RecordCount { get; set; }
        /// <summary>
        /// Year
        /// </summary>
        public int PageCount { get; set; }



        /// <summary>
        /// IdleTimeCount
        /// </summary>
        public List<IdleTime> IdleTimeList;


        public v1IdleTimedto(IdleTimeView view)
        {

            try
            {
                this.RecordCount = view.IdleTime.Count;
                this.PageCount = view.PageCount;
                foreach (IdleTime idleTime in view.IdleTime)
                {
                    if (this.IdleTimeList == null)
                    {
                        this.IdleTimeList = new List<IdleTime>();
                    }
                    this.IdleTimeList.Add(idleTime);
                }
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }

        }
   
    }
}