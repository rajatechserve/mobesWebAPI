﻿using HCProviderServices.DTOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HCProviderDataModel;
using System.Data;
using HCProviderDataModel.DataModels;

namespace HCProviderServices.DTOModels
{
    public class v1ImpactMetrixdto
    {
        public int? ProviderId { get; set; }

        public int? Year { get; set; }
        public int? AnnualGoal { get; set; }


        public List<MonthlyStat> monthlystat;

        public  v1ImpactMetrixdto(ImpactMetrix metrix)
        {
        try{
            this.ProviderId = metrix.ProviderId;
                this.Year = metrix.Year;
                this.AnnualGoal = metrix.AnnualGoal;
                if (metrix.monthlystat != null)
                {
                    foreach (MonthlyStat item in metrix.monthlystat)
                    {
                        if (this.monthlystat == null)
                        {
                            this.monthlystat = new List<MonthlyStat>();
                        }
                        this.monthlystat.Add(item);
                    }
                }
            }
        catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
         }
            }
}




   
}
