﻿using HCProviderDataModel.DataModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HCProviderServices.DTOModels
{
    public class v1NoAvailabilitydto
    {
        public v1NoAvailabilitydto(NoAvailability view)
        {
            try
            {
                this.FROM_DATE = view.FROM_DATE;
                this.TO_DATE = view.TO_DATE;
                this.COMMITED = view.COMMITED;
                this.DEFINED_HOURS = view.DEFINED_HOURS;
                this.DEFICIT_HOURS = view.DEFICIT_HOURS;
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
        }

        public DateTime FROM_DATE { get; set; }
        public DateTime TO_DATE { get; set; }
        public int COMMITED { get; set; }
        public int DEFINED_HOURS { get; set; }
        public int DEFICIT_HOURS { get; set; }
    }
}
