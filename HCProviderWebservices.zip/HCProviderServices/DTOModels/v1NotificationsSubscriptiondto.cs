﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Data;
using HCProviderDataModel.DataModels;

namespace HCProviderServices.DTOModels
{
   public class v1NotificationsSubscriptiondto
    {
        public v1NotificationsSubscriptiondto()
        {

        }
        public v1NotificationsSubscriptiondto(NotificationsSubscription notificationsSubscription)
        {

            this.HubSubscriptionId = notificationsSubscription.hubSubscriptionId;
            this.UserRef = notificationsSubscription.userRef;
            this.SubscriptionStatus = notificationsSubscription.subscriptionStatus;
            this.CurrentConnectionId = notificationsSubscription.currentConnectionId;
            this.ConnectionStatus = notificationsSubscription.connectionStatus;
            this.UpdatedBy = notificationsSubscription.updatedBy;
            this.CreatedOnDateTime = notificationsSubscription.createdOnDateTime;
        }

        public int HubSubscriptionId { get; set; }
        public int UserRef { get; set; }
        public string SubscriptionStatus { get; set; }
        public string CurrentConnectionId { get; set; }
        public string ConnectionStatus { get; set; }
        public int UpdatedBy { get; set; }

        public DateTime UpdatedOnDateTime { get; set; }

        public DateTime CreatedOnDateTime { get; set; }
    }
}
