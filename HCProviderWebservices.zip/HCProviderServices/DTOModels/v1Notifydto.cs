﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HCProviderDataModel;
using System.Data;

namespace HCProviderServices.DTOModels
{
    public class v1Notifydto
    {
        /// <summary>
        /// NotifyType
        /// </summary>
        public Int32 type { get; set; }

        /// <summary>
        /// RecipientType
        /// </summary>
        public Int32 recipientType { get; set; }

        /// <summary>
        /// NotifyDateTime
        /// </summary>
        public DateTime alertDateTime { get; set; }

        /// <summary>
        /// NotifyMessage
        /// </summary>
        public string message { get; set; }

        /// <summary>
        /// TargetedUser
        /// </summary>
        public Int32 targetedUser { get; set; }

        /// <summary>
        /// SourceLkup
        /// </summary>
        public Int32 source { get; set; }

        /// <summary>
        /// ExpiresOn
        /// </summary>
        public DateTime expiresOn { get; set; }



    }





   
}