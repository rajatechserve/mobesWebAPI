﻿using HCProviderDataModel.DataModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderServices.DTOModels
{
   public class v1PTOAlertdto
    {
        public v1PTOAlertdto(PTOAlertView view)
        {
            try
            {
                this.MESSAGE = view.MESSAGE;
                this.PTO_STATUS = view.PTO_STATUS;
                this.TYPE = view.TYPE;
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
        }

        public String MESSAGE { get; set; }
        public String PTO_STATUS { get; set; }
        public String TYPE { get; set; }
    }
}
