﻿using HCProviderDataModel.DataModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderServices.DTOModels
{
    public class v1QualityAssurancedto
    {

        public v1QualityAssurancedto(QualityAssurance view)
        {

            try
            {
                this.TYPE = view.TYPE;
                this.RECORDCOUNT = view.RECORDCOUNT;
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }

        }

        public string TYPE { get; set; }

        public int RECORDCOUNT { get; set; }
    }
}
