﻿using HCProviderDataModel.DataModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderServices.DTOModels
{

    public class v1StarGapsdto : v1basedto
    {
        public int RecordCount { get; set; }
        public int PageCount { get; set; }

        public List<StarGaps> StarGaps;


        public v1StarGapsdto(StarGapsView view)
        {

            try
            {
                this.RecordCount = view.RecordCount;
                this.PageCount = view.PageCount;
                foreach (StarGaps starGap in view.StarGaps)
                {
                    if (this.StarGaps == null)
                    {
                        this.StarGaps = new List<StarGaps>();
                    }
                    this.StarGaps.Add(starGap);
                }
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }

        }
    }

}
