﻿using HCProviderServices.DTOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HCProviderDataModel;

namespace HCProviderServices.DTOModels
{
    public class v1SupportContactdto : v1basedto
    {

        public v1SupportContactdto()
        {
            
        }
        public v1SupportContactdto(SupportContact scontact)
        {
            
                this.id = scontact.ContactId;
                this.ContactName = scontact.ContactName;
               // this.ContactGroup = scontact.ContactGroup;
                this.ContactPhone = scontact.ContactPhone;
                this.ContactType = scontact.ContactType;
           
        }
        /// <summary>
        /// contact Name
        /// </summary>
        public string ContactName { set; get; }

        /// <summary>
        /// contact phone number
        /// </summary>
        public string ContactPhone { set; get; }

        /// <summary>
        /// clinical/technical/member service 
        /// </summary>
        public string ContactType { get; set; }




        /// <summary>
        /// system/user
        /// users cannot remove system contacts
        /// users can remove only remove/modify user added contact
        /// </summary>
     //   public string ContactGroup { get; set; }

    }
}
