﻿using HCProviderServices.DTOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HCProviderDataModel;

namespace HCProviderServices.DTOModels
{
   public class v1Supportlearningdto:v1basedto
    {

        public v1Supportlearningdto(Supportlearning learning)
        {
            this.id = learning.learningid;
            this.title = learning.learningtitle;
            this.contentsubtype = learning.contentsubtype;
            this.contenttype = learning.contenttype;
            this.learningtype = learning.learningtype;

            this.filepath = learning.filepath;
        }
     public   string title { get; set; }

        /// <summary>
        /// video/pdf/audio
        /// </summary>
        public string contenttype { get; set; } 
        

        /// <summary>
        /// file extn
        /// mp3/mp4/
        /// </summary>
        public string contentsubtype { get; set; }


        /// <summary>
        /// clinical/techincal
        /// </summary>
        public string learningtype { get; set; }



        
        /// <summary>
        /// Filepath for resource: 
        /// Private : shouldn't be send to 
        /// </summary>
     public   string filepath { get; set; }

        public string GetFilepath()
        { return filepath;
        }
        

    }
}
