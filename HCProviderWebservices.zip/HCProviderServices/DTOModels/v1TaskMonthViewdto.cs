﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HCProviderDataModel;
using System.Reflection;
using System.Data;

namespace HCProviderServices.DTOModels
{
    

    public class v1TaskCountViewDto 
    {
       

        /// <summary>
        /// Year
        /// </summary>
        public int Year { get; set; }

        public List<TaskCount> TaskCounts;
        /// <summary>
        /// 1-Jan ,2-Feb,.....12-Dec
        /// </summary>
        public int Month { get; set; }



        /// <summary>
        /// v1TaskCountViewDto
        /// </summary>
        public v1TaskCountViewDto()
        {


        }

        /// <summary>
        /// v1TaskCountViewDto
        /// </summary>
        /// <param name="view"></param>
        public v1TaskCountViewDto(TaskCountView view)
        {
            try
            {              
                this.Year = view.Year;
                this.Month = view.Month;
                foreach (TaskCount apt in view.TaskCount)
                {
                    if (this.TaskCounts == null)
                    {
                        this.TaskCounts = new List<TaskCount>();
                    }
                    this.TaskCounts.Add(apt);
                }
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }

        }


        /// <summary>
        /// v1TaskCountViewDto
        /// </summary>
        /// <param name="viewdto"></param>
        public v1TaskCountViewDto(v1TaskCountViewDto viewdto)
        {

            //this.count = viewdto.count;
            //this.Taskdate = viewdto.Taskdate;
        }
    }
    //public class v1TaskCountDto
    //{
    //    public int count { get; set; }
    //    public DateTime Taskdate { get; set; }
    //}
}
