﻿using HCProviderServices.DTOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HCProviderDataModel;
using System.Data;

namespace HCProviderServices.DTOModels
{
    public class v1Taskdto:v1basedto
    {

        /// <summary>
        /// providerid
        /// </summary>
        public int RecordCount { get; set; }
        /// <summary>
        /// Year
        /// </summary>
        public int PageCount { get; set; }



        /// <summary>
        /// AppointmentCount
        /// </summary>
        public List<Task> Task;


        public v1Taskdto(TaskView view)
        {

            try
            {
                this.RecordCount = view.RecordCount;
                this.PageCount = view.PageCount;
                foreach (Task task in view.Task)
                {
                    if (this.Task == null)
                    {
                        this.Task = new List<Task>();
                    }
                    this.Task.Add(task);
                }
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }

        }
   
    }
}