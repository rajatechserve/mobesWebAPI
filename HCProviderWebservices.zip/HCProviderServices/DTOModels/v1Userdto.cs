﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HCProviderDataModel;

namespace HCProviderServices.DTOModels
{
    public class v1Userdto : v1basedto
    {

        public int providerid { get; set; }
        public string name { get; set; }


        public string Credentials { get; set; }
        Dictionary<string, string> roles;


        public v1Userdto(User usr)
        {
//            this.id = usr.userid;
            this.providerid = usr.providerid;
            this.name = usr.Name;
            this.Credentials = usr.Credentials;

            if (usr.Claims != null)
            {

                roles = new Dictionary<string, string>();
                foreach (UserClaim clm in usr.Claims)
                    roles.Add(clm.claimType, clm.claimValue);

            }
        }
    }
}
