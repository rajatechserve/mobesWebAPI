﻿using HCProviderDataModel.DataModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderServices.DTOModels
{
    public class v1WeatherAlertdto
    {
        public v1WeatherAlertdto(WeatherAlertView view)
        {

            try
            {
                this.AlertId = view.AlertId;
                this.type = view.Type;
                this.description = view.Description;
                this.date = view.Date;
                this.date_epoch = view.DateEpoch;
                this.expires = view.Expires;
                this.expires_epoch = view.ExpiresEpoch;
                this.message = view.Message;
                this.phenomena = view.Phenomena;
                this.significance = view.Significance;
                this.city = view.City;
                this.state = view.State;
                this.alertServerExpiresDate = view.AlertServerExpiresDate;
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }

        }

        public int AlertId { get; set; }
        public string type { get; set; }
        public string description { get; set; }
        public string date { get; set; }
        public long date_epoch { get; set; }
        public string expires { get; set; }
        public long expires_epoch { get; set; }
        public String message { get; set; }
        public string phenomena { get; set; }
        public char significance { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public DateTime alertServerExpiresDate { get; set; }


    }
}
