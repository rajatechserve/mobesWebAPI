﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderServices.DTOModels
{
   public abstract class v1basedto
    {

    public int id;
        
    }
}
