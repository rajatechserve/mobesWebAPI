﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HCProviderServices;
using HCProviderDataModel;



namespace HCProviderServices.DTOModels
{

    /// <summary>
    /// v2 appointment 
    ///
    /// </summary>
    public class v2Appointmentdto : v1Appointmentdto
    {

        /// <summary>
        /// Member Full Name
        /// </summary>
        public string patientFullName
        {

            get { return this.FirstName + " " + this.MiddleName + " " + this.LastName; }

        }

        public string LOB_NM { get; set; }
        public string CLI_NM { get; set; }
        public string SUBCLI_NM { get; set; }
        public string GRP_NM { get; set; }
        public string CDO_NM { get; set; }

        public bool Is_AltLoc { get; set; }
        public string Loc_Name { get; set; }
        public string Loc_Type { get; set; }
        public string Loc_Address { get; set; }
        public int Member_Count { get; set; }
        public bool Is_AutoCall_Placed { get; set; }
       
        public string Auto_Call_Status { get; set; }

        public DateTime Autocall_StartTime { get; set; }
        public DateTime Autocall_EndTime { get; set; }

        public v2Appointmentdto(v1Appointmentdto apt) : base(apt)
        { }

        public v2Appointmentdto(Appointment aptEntity) : base(aptEntity)
        {
            this.LOB_NM = aptEntity.LOB_NM;
            this.CLI_NM = aptEntity.CLI_NM;
            this.SUBCLI_NM = aptEntity.SUBCLI_NM;
            this.GRP_NM = aptEntity.GRP_NM;
            this.CDO_NM = aptEntity.CDO_NM;

            this.Is_AltLoc = aptEntity.Is_AltLoc;
            this.Loc_Name = aptEntity.Loc_Name;
            this.Loc_Type = aptEntity.Loc_Type;
            this.Loc_Address = aptEntity.Loc_Address;
            this.Member_Count = aptEntity.Member_Count;
            this.Is_AutoCall_Placed = aptEntity.Is_AutoCall_Placed;
            this.Auto_Call_Status = aptEntity.Auto_Call_Status;
            this.Autocall_StartTime = aptEntity.Autocall_StartTime;
            this.Autocall_EndTime = aptEntity.Autocall_EndTime;
            
        }
    }
}
