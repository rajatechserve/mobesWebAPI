﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HCProviderServices.DTOModels;
using HCProviderDataModel;
using HCProviderDataModel.DataModels;

namespace HCProviderServices
{
    public interface IAlertServices
    {
        Task<int> Notify(int userid, v1Notifydto message);

        Task<IEnumerable<v1Alertdto>> GetAlerts(int userid, int? alertid = 0, DateTime? fromDate = null, DateTime? toDate = null, int? pagesize = 10, int? pagenumber = 1, string status = "active", string type = "all", int? isDefault = 1);
        Task<IEnumerable<v1AlertScheduledto>> GetScheduleAlerts(int providerid,int? pagesize, int? pagenumber);


        int NotifyPending(int userid);


        Task<int> Acknowledge(int userid, int alertid, string action);

        Task<int> AlertSubscription(NotificationsSubscription notificationsSubscription);
        Task<IEnumerable<v1Addendumdto>> GetAddendumsCount(int providerId);
        Task<IEnumerable<v1WeatherAlertdto>> GetWeatherAlerts(string state, string city);
        Task<int> AddAlert(string type, string description, string date, long dateEpoch, string expires, long expiresEepoch,
            string message, string phenomena, char significance, string city, string state,DateTime alertServerExpiresDate);
        System.Threading.Tasks.Task AddAlerts(List<v1WeatherAlertdto> alerts);
        Task<IEnumerable<v1QualityAssurancedto>> GetQACount(int providerId);
        Task<IEnumerable<v1PTOAlertdto>> GetPTOAlerts(int providerId);

        Task<IEnumerable<v1NoAvailabilitydto>> GetNoAvailability(int providerId);
    }
}