﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HCProviderServices.DTOModels;
using HCProviderDataModel;

namespace HCProviderServices
{
    public interface IAppointmentServices
    {
        Task<IEnumerable<v1Appointmentdto>> getAppointments(int providerid, int userid, DateTime aptstdate);

        /// <summary>
        /// getAppointmentCount
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <returns></returns>
        Task<v1AppointmentCountViewDto> getAppointmentCount(int providerid, int userid, int year, int month);

        Task<IEnumerable<v1Appointmentdto>> getAppointmentById(int providerid, int userid, int appointmentId);

        Task<int> UpdateAppointmentAction(int providerid, int appointmentid, int userid, AppointmentActionRequest action);

        Task<IEnumerable<v2Appointmentdto>> getAppointmentsV2(int providerid, int userid, DateTime aptdate);

        Task<IEnumerable<v2Appointmentdto>> getAppointmentByIdV2(int providerid, int userid, int appointmentId);
        
        bool GetAutoCallFileStatus(int providerID);

        void InsertAutoCall(int providerID, int appointmentid, bool insertfile);
    }
}

