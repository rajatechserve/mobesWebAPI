﻿using HCProviderServices.DTOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderServices
{
    /// <summary>
    /// Config data service interface
    /// </summary>
    public interface IConfigService
    {
        Task<IEnumerable<v1IdleTimedto>> GetIdleTimeValues();//method declaration to get idletime vlaues from db

        int GetServerTimeZoneDiff();//method declaration to get Servertimezone difference value from db
    }
}
