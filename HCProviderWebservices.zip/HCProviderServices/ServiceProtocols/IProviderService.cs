﻿using HCProviderServices.DTOModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HCProviderServices
{
    public interface IProviderService
    {
        Task<IEnumerable<v1Providerdto>> getProviders(int userid);
    }
}
