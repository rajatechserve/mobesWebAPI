﻿using HCProviderServices.DTOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderServices.ServiceProtocols
{
    public interface IStarGapsService
    {
        /// <summary>
        /// Get Star Gaps
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="month"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        Task<IEnumerable<v1StarGapsdto>> GetStarGaps(int providerId, int month, int year);
    }
}
