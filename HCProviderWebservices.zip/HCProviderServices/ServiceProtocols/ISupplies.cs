﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HCProviderDataModel;
using HCProviderServices.DTOModels;

namespace HCProviderServices
{
   public interface ISuppliesServices
    {
      Task< v1DailySupplydto> GetSupply(int providerid, int userid, DateTime aptdate);


     }
}
