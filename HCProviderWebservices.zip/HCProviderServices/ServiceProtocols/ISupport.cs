﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using HCProviderServices.DTOModels;

namespace HCProviderServices
{
  public  interface Isupportservices
    {

        /// <summary>
        /// get contacts
        /// contact type: technical /clinical 
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="contacttype">all/technical/clinical/memberservice</param>
        /// <returns></returns>
       Task<IEnumerable<v1SupportContactdto>> GetSupportContacts( int userid, string contacttype );

        //Task<int> AddTechnicalContact( int userid, v1SupportContactdto contact);

        //Task<int> AddClinicalContact(int userid, v1SupportContactdto contact);

        Task<int> AddSupportContact(int userid, v1SupportContactdto contact);
        Task<int> UpdateSupportContact(int userid, v1SupportContactdto contact);
        Task<int> DeleteSupportContact(int userid, int contactid);

        IEnumerable<v1Supportlearningdto> GetLearnings(int userid , string learningtype);

        v1Supportlearningdto GetLearningById(int userid, int resourceid);

       


        

    }
}
