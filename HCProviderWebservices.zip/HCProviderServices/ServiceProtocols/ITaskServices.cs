﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HCProviderServices.DTOModels;

namespace HCProviderServices.ServiceProtocols
{
    public interface ITaskServices
    {
        /// <summary>
        /// Add Task
        /// </summary>
        /// <param name="TaskName"></param>
        /// <param name="TaskDescription"></param>
        /// <param name="TaskDueDate"></param>
        /// <param name="TaskCreatedBy"></param>
        /// <returns>TaskID</returns>

        Task<int> AddTask(string taskName, string taskDescription, int userId, DateTime dueDate);

        /// <summary>
        ///Update Task
        /// </summary>
        /// <param name="TaskName"></param>
        /// <param name="TaskDescription"></param>
        /// <param name="TaskDueDate"></param>
        /// <param name="TaskCreatedBy"></param>
        /// <returns>Result</returns>

        Task<int> UpdateTask(int taskId, string taskName, string taskDescription, string taskStatus, int taskCreatedBy, DateTime? taskDueDate);
        ///<summary>
        ///Get Task
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="status"></param>
        /// <param name="pagesize"></param>
        /// <param name="pagenumber"></param>
        /// <returns>TaskList</returns>

        Task<IEnumerable<v1Taskdto>> GetTaskList(int userid, int? taskid = 0, DateTime? fromDate = null, DateTime? toDate = null, int? pagesize = 10, int? pagenumber = 1, string status = "active");

        ///<summary>
        ///Get Task
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="status"></param>
        /// <param name="pagesize"></param>
        /// <param name="pagenumber"></param>
        /// <returns>TaskList</returns>

        Task<IEnumerable<v1Taskdto>> GetNewTaskList(int userid, int? taskid = 0, DateTime? fromDate = null, DateTime? toDate = null, int? pagesize = 10, int? pagenumber = 1, string status = "active");


        /// <summary>
        /// get  Task  Count
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <returns>v1TaskCountViewDto</returns>
        Task<v1TaskCountViewDto> getTaskCount( int year, int month, int userid);

    }
}
