﻿using HCProviderDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderServices
{
    public interface IUserService
    {
        User getUser(string username, string password);
        User getUserByOptumId(string optumId);
    }
}
