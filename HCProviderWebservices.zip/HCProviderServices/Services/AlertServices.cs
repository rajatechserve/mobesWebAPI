﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataFactory;
using HCProviderServices.DTOModels;
using HCProviderDataModel;
using Microsoft.AspNet.SignalR;
using System.Threading.Tasks;
using log4net;
using HCProviderDataModel.DataModels;

/// <summary>
/// https://github.com/StackExchange/dapper-dot-net
/// </summary>
namespace HCProviderServices
{
    /// <summary>
    /// version 1 alert services
    ///  
    /// </summary>
    
    public class Alertservices: IAlertServices
    {
        IAlertContract _alertdatafactory;
        ILog _logger;
        //reference to notification hub for real time notification
        IHubContext notifier;

       
       private readonly static Lazy<Alertservices> _instance = new Lazy<Alertservices>(
        () => new Alertservices(GlobalHost.ConnectionManager.GetHubContext<NotificationHub>()));



        public Alertservices(IAlertContract alertFact, ILog logger)
        {
            _alertdatafactory = alertFact;
            _logger = logger;
            notifier = GlobalHost.ConnectionManager.GetHubContext("notifier");
            
        }

        public Alertservices(IHubContext contxt)
        {
            notifier = contxt;
        }
        async Task<int> IAlertServices.Acknowledge(int userid, int alertid, string action)
        {
            try
            {
                var res =  await _alertdatafactory.Acknowledge(userid, alertid, action);
                return res;
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
        }

        async Task<IEnumerable<v1Alertdto>> IAlertServices.GetAlerts(int userid, int? alertid, DateTime? fromDate, DateTime? toDate, int? pagesize, int? pagenumber, string status, string type, int? isDefault)
        {
            AlertView alrts = null;
            IList<v1Alertdto> finalres = null;
            try
            {
                var res = await _alertdatafactory.GetAlerts(userid, alertid, fromDate, toDate, pagesize, pagenumber, status, type, isDefault);
                if (res != null)
                {
                    if (alrts == null)
                    {
                        alrts = new AlertView();
                    }
                    alrts = res;
                    if (finalres == null)
                    {
                        finalres = new List<v1Alertdto>();
                    }
                    finalres.Add(new v1Alertdto(alrts));
                }

            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
            return finalres;
        }

        async System.Threading.Tasks.Task IAlertServices.AddAlerts(List<v1WeatherAlertdto> alerts)
        {
            try
            {
                List<WeatherAlertView> alertView = new List<WeatherAlertView>();
                foreach (var alert in alerts)
                {
                    WeatherAlertView view = new WeatherAlertView();
                    view.Type = alert.type;
                    view.Description = alert.description;
                    view.Date = alert.date;
                    view.DateEpoch = alert.date_epoch;
                    view.Expires = alert.expires;
                    view.ExpiresEpoch = alert.expires_epoch;
                    view.Message = alert.message;
                    view.Phenomena = alert.phenomena;
                    view.Significance = alert.significance;
                    view.City = alert.city;
                    view.State = alert.state;
                    view.AlertServerExpiresDate = alert.alertServerExpiresDate;

                    alertView.Add(view);
                }

                await _alertdatafactory.AddAlerts(alertView);
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }

        }
        async Task<IEnumerable<v1AlertScheduledto>> IAlertServices.GetScheduleAlerts(int providerid, int? pagesize, int? pagenumber)
        {
            AlertScheduleView alrts = null;
            IList<v1AlertScheduledto> finalres = null;
            try
            {
                var res = await _alertdatafactory.GetScheduleAlerts(providerid, pagesize, pagenumber);
                if (res != null)
                {
                    if (alrts == null)
                    {
                        alrts = new AlertScheduleView();
                    }
                    alrts = res;
                    if (finalres == null)
                    {
                        finalres = new List<v1AlertScheduledto>();
                    }
                    finalres.Add(new v1AlertScheduledto(alrts));
                }

            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
            return finalres;
        }

        /// <summary>
        /// identify and notify all targeted users
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        async Task<int> IAlertServices.Notify(int userid, v1Notifydto message)
        {


            try
            {
                Notify notify = new Notify();
                notify.type = message.type;
                notify.recipientType = message.recipientType;
                notify.alertDateTime = message.alertDateTime;
                notify.message = message.message;
                notify.targetedUser = message.targetedUser;
                notify.source = message.source;
                notify.expiresOn = message.expiresOn;
                var res = await _alertdatafactory.Notify(userid, notify);
                notification alert = new notification();
                alert.id = 99;
                alert.message = message.message;
                alert.source = message.source.ToString();
                notifier.Clients.All.NotificationArrived(alert);
                return res;
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }

            ////Insert The Allert Message
            // notifier.Clients.All.NotificationArrived(alert);


        }

        int IAlertServices.NotifyPending(int userid)
        {
            throw new NotImplementedException();
        }



        async Task<int> IAlertServices.AlertSubscription(NotificationsSubscription notificationsSubscription)
        {
            try
            {
                var res = await _alertdatafactory.AlertSubscription(notificationsSubscription);
                return res;
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
        }
        async Task<IEnumerable<v1Addendumdto>> IAlertServices.GetAddendumsCount(int providerId)
        {
            
            IList<v1Addendumdto> finalres = null;
            try
            {
                var res = await _alertdatafactory.GetAddendumsCount(providerId);
                if (res != null)
                {
                    foreach (Addendum amd in res)
                    {
                        if (finalres == null)
                        {
                            finalres = new List<v1Addendumdto>();
                        }
                        finalres.Add(new v1Addendumdto(amd));
                    }

                    
                }

            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
            return finalres;
        }
        async Task<IEnumerable<v1WeatherAlertdto>> IAlertServices.GetWeatherAlerts(string state, string city)
        {

            IList<v1WeatherAlertdto> finalres = null;
            try
            {
                var res = await _alertdatafactory.GetWeatherAlerts(state, city);
                if (res != null)
                {
                    foreach (WeatherAlertView alerts in res)
                    {
                        if (finalres == null)
                        {
                            finalres = new List<v1WeatherAlertdto>();
                        }
                        finalres.Add(new v1WeatherAlertdto(alerts));
                    }


                }

            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
            return finalres;
        }

        async Task<int> IAlertServices.AddAlert(string type, string description, string date, long dateEpoch, string expires, long expiresEepoch,
            string message, string phenomena, char significance, string city, string state,DateTime alertServerExpiresDate)
        {
            try
            {
                var alertId = await _alertdatafactory.AddAlert(type, description, date, dateEpoch, expires, expiresEepoch, message, phenomena, significance,
                    city, state, alertServerExpiresDate);
                return alertId;
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }

        }
       

        async Task<IEnumerable<v1QualityAssurancedto>> IAlertServices.GetQACount(int providerId)
        {

            IList<v1QualityAssurancedto> finalres = null;
            try
            {
                var res = await _alertdatafactory.GetQACount(providerId);
                if (res != null)
                {
                    foreach (QualityAssurance amd in res)
                    {
                        if (finalres == null)
                        {
                            finalres = new List<v1QualityAssurancedto>();
                        }
                        finalres.Add(new v1QualityAssurancedto(amd));
                    }


                }

            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
            return finalres;
        }
        async Task<IEnumerable<v1PTOAlertdto>> IAlertServices.GetPTOAlerts(int providerId)
        {
            IList<v1PTOAlertdto> finalres = null;
            try
            {
                var res = await _alertdatafactory.GetPTOAlerts(providerId);
                if (res !=null)
                {
                    foreach (PTOAlertView alerts in res)
                    {
                        if (finalres == null)
                        {
                            finalres = new List<v1PTOAlertdto>();
                        }
                        finalres.Add(new v1PTOAlertdto(alerts));
                    }

                }
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
            return finalres;
        }

        async Task<IEnumerable<v1NoAvailabilitydto>> IAlertServices.GetNoAvailability(int providerId)
        {
            IList<v1NoAvailabilitydto> finalres = null;
            try
            {
                var res = await _alertdatafactory.GetNoAvailability(providerId);
                if (res != null)
                {
                    foreach (NoAvailability alerts in res)
                    {
                        if (finalres == null)
                        {
                            finalres = new List<v1NoAvailabilitydto>();
                        }
                        finalres.Add(new v1NoAvailabilitydto(alerts));
                    }

                }
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
            return finalres;
        }
    }
}
