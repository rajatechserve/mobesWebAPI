﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using HCProviderServices.DTOModels;
using HCProviderDataModel;
using System.Threading.Tasks;

namespace HCProviderServices
{
    /// <summary>
    /// mock appointment services . mock data is hardcoded and constructed for supplied proiderid and apt date.
    /// </summary>
    public class Appointmentv1Mockservice : IAppointmentServices
    {

        /// <summary>
        /// list of appointments for given provider id
        /// </summary>
        public List<v1Appointmentdto> Appts = null;
        public List<v2Appointmentdto> Apptsv2 = null;

        /// <summary>
        /// list of appointment view for a  given month
        /// </summary>
        public List<v1AppointmentCountViewDto> ApptCountView = null;


        public Appointmentv1Mockservice(List<v1Appointmentdto> appointments, List<v1AppointmentCountViewDto> apptCountView)
        {
            Appts = appointments;
            ApptCountView = apptCountView;
        }


        /// <summary>
        /// test data of views for current year
        /// </summary>
        /// <returns></returns>


        async Task<IEnumerable<v1Appointmentdto>> IAppointmentServices.getAppointments(int providerid, int userid, DateTime aptstdate)
        {
            if (Appts != null)

            {
                var apt = Appts.FindAll(a => a.Providerid == providerid && a.AppointmentDate.Date == aptstdate.Date);
                return await System.Threading.Tasks.Task.FromResult(apt);

            }

            return null;
        }

        /// <summary>
        /// getAppointmentCount
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <returns></returns>
        async Task<v1AppointmentCountViewDto> IAppointmentServices.getAppointmentCount(int providerid, int userid, int year, int month)
        {
            if (ApptCountView != null)

            {
                var apt = ApptCountView.Find(a => a.Month == month);
                return await System.Threading.Tasks.Task.FromResult(apt);

            }

            return null;
        }

        async Task<IEnumerable<v1Appointmentdto>> IAppointmentServices.getAppointmentById(int providerid, int userid, int appointmentId)
        {
            if (Appts != null)
            {
                var ap = Appts.FindAll(a => a.id == appointmentId);
                return await System.Threading.Tasks.Task.FromResult(ap);
            }
            return null;
        }

        Task<int> IAppointmentServices.UpdateAppointmentAction(int providerid, int appointmentid, int userid, AppointmentActionRequest action)
        {
            throw new NotImplementedException();


        }

        async Task<IEnumerable<v2Appointmentdto>> IAppointmentServices.getAppointmentsV2(int providerid, int userid, DateTime aptdate)
        {


            v2Appointmentdto apt;
            List<v2Appointmentdto> v2apts = null;
            if (this.Appts != null)
            {

                var v1apts = await System.Threading.Tasks.Task.FromResult(this.Appts.FindAll(ap => ap.Providerid == providerid && ap.AppointmentDate.Date == aptdate.Date));

                if (v1apts != null)
                {
                    v2apts = new List<v2Appointmentdto>();
                    foreach (v1Appointmentdto a in v1apts)
                    {
                        apt = new v2Appointmentdto(a);
                        v2apts.Add(apt);
                    }
                }
            }
            return v2apts;
        }

        async Task<IEnumerable<v2Appointmentdto>> IAppointmentServices.getAppointmentByIdV2(int providerid, int userid, int appointmentId)
        {
            if (Apptsv2 != null)
            {
                var ap = Apptsv2.FindAll(a => a.id == appointmentId);
                return await System.Threading.Tasks.Task.FromResult(ap);
            }
            return null;
        }


        bool IAppointmentServices.GetAutoCallFileStatus(int providerID)
        {
            throw new NotImplementedException();
        }

        public void InsertAutoCall(int providerID, int appointmentid, bool insertfile)
        {
            throw new NotImplementedException();
        }
    } 
    
}
