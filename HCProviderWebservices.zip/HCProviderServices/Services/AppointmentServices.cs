﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataFactory;
using HCProviderServices.DTOModels;
using HCProviderDataModel;
using System.Threading.Tasks;
using log4net;

/// <summary>
/// https://github.com/StackExchange/dapper-dot-net
/// </summary>
namespace HCProviderServices
{
    /// <summary>
    /// version 1 appointment services
    ///  
    /// </summary>

    public class AppointmentServices : IAppointmentServices
    {

        IAppointmentscontract _aptdatafactory;
        ILog _logger ;
        

        /// <summary>
        /// AppointmentServices
        /// </summary>
        /// <param name="apptFact"></param>
        public AppointmentServices(IAppointmentscontract apptFact, ILog logger)
        {
            _aptdatafactory = apptFact;
            _logger = logger;

        }

        /// <summary>
        /// getAppointmentById
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="appointmentId"></param>
        /// <returns></returns>
        async Task<IEnumerable<v1Appointmentdto>> IAppointmentServices.getAppointmentById(int providerid, int userid, int appointmentId)
        {
            IList<v1Appointmentdto> apts = null;

            try
            {

                var res = await _aptdatafactory.GetAppointments(providerid, appointmentid: appointmentId);

                foreach (Appointment apt in res)
                {
                    if (apts == null)
                    {
                        apts = new List<v1Appointmentdto>();
                    }
                    apts.Add(new v1Appointmentdto(apt));
                }
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);
            }

            return apts;
        }

        /// <summary>
        /// UpdateAppointmentAction
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="appointmentid"></param>
        /// <param name="userid"></param>
        /// <param name="action"></param>
        /// <returns></returns>
        async Task<int> IAppointmentServices.UpdateAppointmentAction(int providerid, int appointmentid, int userid, AppointmentActionRequest action)
        {
           
            throw new NotImplementedException();
        }


        /// <summary>
        /// getAppointmentsV2
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="aptdate"></param>
        /// <returns></returns>
        async Task<IEnumerable<v2Appointmentdto>> IAppointmentServices.getAppointmentsV2(int providerid, int userid, DateTime aptdate)
        {

            List<v2Appointmentdto> res = null;
            try
            {

                var aptlist = await _aptdatafactory.GetAppointments(providerid, aptdate, aptdate, appointmentid: 0);


                if (aptlist != null && aptlist.Count<Appointment>() > 0)
                {

                    foreach (Appointment apt in aptlist)
                    {
                        if (res == null)
                            res = new List<v2Appointmentdto>();
                        res.Add(new v2Appointmentdto(apt));
                    }
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);
            }
            return res;
        }
        /// <summary>
        /// getAppointments
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="aptstdate"></param>
        /// <returns></returns>
        async Task<IEnumerable<v1Appointmentdto>> IAppointmentServices.getAppointments(int providerid, int userid, DateTime aptstdate)
        {
            IList<v1Appointmentdto> apts = null;

            try
            {

                var res = await _aptdatafactory.GetAppointments(providerid, aptstdate, aptstdate, appointmentid: 0);

                _logger.Info("Get Appointments Service Method called");

                foreach (Appointment apt in res)
                {
                    if (apts == null)
                    {
                        apts = new List<v1Appointmentdto>();
                    }
                    apts.Add(new v1Appointmentdto(apt));
                }
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);
            }

            return apts;
        }


        /// <summary>
        ///  getAppointmentCount
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <returns></returns>
        async Task<v1AppointmentCountViewDto> IAppointmentServices.getAppointmentCount(int providerid, int userid, int year, int month)
        {
            AppointmentCountView apts = null;
            v1AppointmentCountViewDto finalres = null;
            try
            {
                var res = await _aptdatafactory.GetAppointmentCountView(year, month, providerid);

                //  return res != null ? new v1AppointmentCountViewDto(apts) : null;
                if (res != null)
                {
                    if (res.ToList().Count != 0)
                    {
                        if (apts == null)
                        {
                            apts = new AppointmentCountView();
                        }
                        apts.providerid = providerid;
                        apts.Year = year;
                        apts.Month = month;
                        apts.AppointmentCount = res.ToList();
                        finalres = new v1AppointmentCountViewDto(apts);
                    }
                }
               
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);
            }

            return finalres;
        }

        /// <summary>
        /// GetAppointmentByIdv2
        /// </summary>
        /// <param name="aptId"></param>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
       

        async Task<IEnumerable<v2Appointmentdto>> IAppointmentServices.getAppointmentByIdV2(int providerid, int userid, int appointmentId)
        {
            IList<v2Appointmentdto> apts = null;

            try
            {

                var res = await _aptdatafactory.GetAppointments(providerid, appointmentid: appointmentId);

                foreach (Appointment apt in res)
                {
                    if (apts == null)
                    {
                        apts = new List<v2Appointmentdto>();
                    }
                    apts.Add(new v2Appointmentdto(apt));
                }
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);
            }

            return apts;
        }

        

        /// <summary>
        /// GetAutoCallFileStatus
        /// </summary>
        /// <param name="providerID"></param>
        /// <returns></returns>
        bool IAppointmentServices.GetAutoCallFileStatus(int providerID)
        {
            bool _status = false;

            try
            {
                _status = _aptdatafactory.GetAutoCallFileStatus(providerID).Result;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);

            }

            return _status;
        }

        /// <summary>
        /// InsertAutoCall
        /// </summary>
        /// <param name="providerID"></param>
        /// <param name="appointmentid"></param>
        void IAppointmentServices.InsertAutoCall(int providerID, int appointmentid, bool insertfile)
        {
            try
            {
                _aptdatafactory.InsertAutoCall(providerID, appointmentid, insertfile);
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);

            }
        }
    }
}
