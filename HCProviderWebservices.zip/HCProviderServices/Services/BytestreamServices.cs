﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net.Http;
using System.Net;

namespace HCProviderServices
{
    public class byteStream
    {
        private readonly string _filename;
        

        public byteStream(string filename)
        {
            _filename = filename;
        }

        public  async void WriteToStreamAsync(Stream outputStream, HttpContent content, TransportContext context)
        {
            try
            {
                var buffer = new byte[65536];

                using (var fs = File.Open(_filename, FileMode.Open, FileAccess.Read))
                {
                    var length = (int)fs.Length;
                    var bytesRead = 1;

                    while (length > 0 && bytesRead > 0)
                    {
                        bytesRead = fs.Read(buffer, 0, Math.Min(length, buffer.Length));
                        await  outputStream.WriteAsync(buffer, 0, bytesRead);
                        length -= bytesRead;
                    }
                }
            }
            catch (Exception ex)
            {
                return;
            }
            finally
            {
                outputStream.Close();
            }

            return;
        }
    }


}
