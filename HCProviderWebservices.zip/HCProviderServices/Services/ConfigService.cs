﻿using HCProviderDataModel;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataModels;
using HCProviderServices.DTOModels;
using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderServices
{
    public class ConfigService : IConfigService
    {
        IConfigContract _configContract;
        ILog _logger;

        public ConfigService(IConfigContract configContract, ILog logger)
        {
            _configContract = configContract;
            _logger = logger;
        }
        async Task<IEnumerable<v1IdleTimedto>> IConfigService.GetIdleTimeValues()
        {
            IdleTimeView IdleTimes = null;
            IList<v1IdleTimedto> finalres = null;
            try
            {
                var res = await _configContract.GetIdleTimeValues();
                if (res != null)
                {
                    if (IdleTimes == null)
                    {
                        IdleTimes = new IdleTimeView();
                    }
                    IdleTimes = res;
                    if (finalres == null)
                    {
                        finalres = new List<v1IdleTimedto>();
                    }
                    //tasks.TotalCount = 5;
                    //tasks.TotalPages = 1;
                    //tasks.Task = res.ToList();
                    finalres.Add(new v1IdleTimedto(IdleTimes));
                }
                
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
            return finalres;
        }

        int IConfigService.GetServerTimeZoneDiff()
        {
            int res = 0;
            try
            {
                res = _configContract.GetServerTimeZoneDiff();
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
            return res;
        }
    }
}
