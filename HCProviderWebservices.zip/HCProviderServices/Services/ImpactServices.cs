﻿using HCProviderServices.ServiceProtocols;
using System;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataFactory;
using HCProviderServices.DTOModels;
using HCProviderDataModel;
using log4net;
using HCProviderServices.ServiceProtocols;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Data;
using HCProviderDataModel.DataModels;

namespace HCProviderServices.Services
{
    public class ImpactServices :IImpactServices
    {
        IImpactContract _impactdatafactory;
        ILog _logger;
        public ImpactServices(IImpactContract impactdatafactory, ILog logger)
           
        {
            _impactdatafactory = impactdatafactory;
            _logger = logger;
        }

        /// <summary>
        /// Add Goal
        /// </summary>
        /// <param name="providerId"></param>
        /// <param name="targetedAnnualGoal"></param>
        /// <param name="userId"></param>
        ///  <param name="year"></param>
        /// <returns></returns>
        async Task<int> IImpactServices.AddGoal(int providerId, int targetedAnnualGoal, int userId, int year)
        {
            try
            {
                var impactId = await _impactdatafactory.AddGoal(providerId, targetedAnnualGoal, userId, year);
                return impactId;
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
        }

        /// <summary>
        /// Get Impact List
        /// </summary>
        /// <param name="Type"></param>
        /// <param name="Frequency"></param>
        /// <param name="ProviderId"></param>
        /// <returns></returns>
        async Task<IEnumerable<v1ImpactMetrixdto>> IImpactServices.GetImpactList(int providerId, int month, int year)
        {
          //  ImpactMetrix metrix1 = null;
            IList<v1ImpactMetrixdto> impactres = null;

            try
            {

                ImpactMetrix metrix = await _impactdatafactory.GetImpactList(providerId, month, year); 
                                              
                if (metrix != null)
                {                    
                    if (impactres == null)
                    {
                        impactres = new List<v1ImpactMetrixdto>();
                    }
                  
                    impactres.Add(new v1ImpactMetrixdto(metrix));
                }
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new System.Data.DataException(exp.Message, exp);
            }

            return impactres;
        }
       
    }
}
