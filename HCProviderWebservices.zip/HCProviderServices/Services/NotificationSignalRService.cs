﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNet.SignalR;
using HCProviderServices.DTOModels;
using Microsoft.AspNet.SignalR.Hubs;
using HCProviderDataModel.DataContracts;
using log4net;
using HCProviderDataModel.DataModels;
using HCProviderDataModel.DataFactories;
using System.Collections.Generic;

namespace HCProviderServices
{
    [HubName("notifier")]
    public class NotificationHub : Hub
    {
        // INotificationsContract _notificationdatafactory;
        IAlertContract _alertContract;
        ILog _logger;
        //v1NotificationsSubscriptiondto notifiSubs =null;
        NotificationsSubscription notifiSubs = null;

        public NotificationHub(IAlertContract alertContract, ILog logger)
        {
            _alertContract = alertContract;
            _logger = logger;
        }

        public void Notify(int userid, notification message)
        {
            try
            {

                Clients.AllExcept(Context.ConnectionId).NotificationArrived(message);
                Clients.Caller.MessageAck(message.id);
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                Clients.Caller.DisplayError("Sorry, the request could not be processed.");

            }
        }


        public override Task OnConnected()
        {
            try
            {
                notifiSubs = new NotificationsSubscription();
                var request = Context.Request;
                if (Context.Request.Headers["userid"] != null)
                {
                    if (!string.IsNullOrEmpty(Context.Request.Headers["userid"]))
                    {
                        notifiSubs.userRef = Convert.ToInt32(Context.Request.Headers["userid"]);
                    }
                }
                if (Context.ConnectionId != null)
                {
                    if (!string.IsNullOrEmpty(Context.ConnectionId))
                    {
                        notifiSubs.currentConnectionId = Context.ConnectionId;
                        notifiSubs.connectionStatus = "Connected";
                        // notifiSubs.subscriptionStatus = "Subscribed";
                        notifiSubs.updatedBy = notifiSubs.userRef;
                    }
                }
                _alertContract.AlertSubscription(notifiSubs);

                //Get the Pending Alerts and Send Back to User
                // For Each Need to Call Send
                //Clients.Caller.Send()
                HCProviderDataModel.AlertView alertView = _alertContract.GetAlerts(notifiSubs.userRef, 0, null, null, null, null, "active", "all", 0).Result;

                if (alertView != null)
                {
                    if (alertView.Alert.Count != 0)
                    {
                        List<HCProviderDataModel.Alert> alert = alertView.Alert;
                        foreach (HCProviderDataModel.Alert alertItem in alert)
                        {
                            notification message = new DTOModels.notification();
                            message.message = alertItem.Message;
                            message.AckRequired = true;
                            message.source = alertItem.source;
                            message.expiry = alertItem.Expiry;

                            Clients.Client(Context.ConnectionId).NotificationArrived(message);
                            Clients.Caller.MessageAck(message.id);
                        }
                    }
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
            }
            return base.OnConnected();
        }

        public override Task OnDisconnected(bool stopCalled)
        {
            try
            {
                notifiSubs = new NotificationsSubscription();
                var request = Context.Request;
                if (Context.Request.Headers["userid"] != null)
                {
                    if (!string.IsNullOrEmpty(Context.Request.Headers["userid"]))
                    {
                        notifiSubs.userRef = Convert.ToInt32(Context.Request.Headers["userid"]);
                    }
                }
                if (Context.ConnectionId != null)
                {
                    if (!string.IsNullOrEmpty(Context.ConnectionId))
                    {
                        notifiSubs.currentConnectionId = Context.ConnectionId;
                        notifiSubs.connectionStatus = "Disconnected";
                        notifiSubs.subscriptionStatus = "Subscribed";
                        notifiSubs.updatedBy = notifiSubs.userRef;
                    }
                }
                _alertContract.AlertSubscription(notifiSubs);

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
            }
            return base.OnDisconnected(stopCalled);
        }

        public override Task OnReconnected()
        {
            try
            {
                notifiSubs = new NotificationsSubscription();
                var request = Context.Request;
                if (Context.Request.Headers["userid"] != null)
                {
                    if (!string.IsNullOrEmpty(Context.Request.Headers["userid"]))
                    {
                        notifiSubs.userRef = Convert.ToInt32(Context.Request.Headers["userid"]);
                    }
                }
                if (Context.ConnectionId != null)
                {
                    if (!string.IsNullOrEmpty(Context.ConnectionId))
                    {
                        notifiSubs.currentConnectionId = Context.ConnectionId;
                        notifiSubs.connectionStatus = "Reconnected";
                        notifiSubs.subscriptionStatus = "Subscribed";
                        notifiSubs.updatedBy = notifiSubs.userRef;
                    }
                }
                _alertContract.AlertSubscription(notifiSubs);

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
            }
            return base.OnReconnected();
        }
    }
}

