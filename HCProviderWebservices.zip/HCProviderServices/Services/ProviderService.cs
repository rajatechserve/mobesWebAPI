﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using log4net;
using HCProviderServices.DTOModels;
using HCProviderDataModel;
using System.Data;
using HCProviderDataModel.DataContracts;

namespace HCProviderServices
{
    public class ProviderService : IProviderService
    {
        IProviderDataContract _providerDataFactory;
        ILog _logger;

        /// <summary>
        /// ProviderService
        /// </summary>
        /// <param name="providerDataFactory"></param>
        /// <param name="logger"></param>
        public ProviderService(IProviderDataContract providerDataFactory, ILog logger)
        {
            _providerDataFactory = providerDataFactory;
            _logger = logger;

        }

        async Task<IEnumerable<v1Providerdto>> IProviderService.getProviders(int userid)
        {
            IList<v1Providerdto> providers = null;

            try
            {

                var res = await _providerDataFactory.GetProviders(userid);

                _logger.Info("Get Providers Service Method called");

                foreach (Provider provider in res)
                {
                    if (providers == null)
                    {
                        providers = new List<v1Providerdto>();
                    }
                    providers.Add(new v1Providerdto(provider));
                }
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);
            }

            return providers;
        }
    }
}
