﻿using HCProviderServices.ServiceProtocols;
using System;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataFactory;
using HCProviderServices.DTOModels;
using HCProviderDataModel;
using log4net;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Data;
using HCProviderDataModel.DataModels;

namespace HCProviderServices.Services
{
    public class StarGapsService : IStarGapsService
    {
        public IStarGapsContract _starGaps = null;
        ILog _logger;

        public StarGapsService(IStarGapsContract starGaps, ILog logger)
        {
            _starGaps = starGaps;
            _logger = logger;
        }

        async Task<IEnumerable<v1StarGapsdto>> IStarGapsService.GetStarGaps(int providerId, int month, int year)
        {
            StarGapsView StarGaps = null;
            IList<v1StarGapsdto> finalres = null;
            try
            {
                var res = await _starGaps.GetStarGaps(providerId, month, year);
                if (res != null)
                {
                    if (StarGaps == null)
                    {
                        StarGaps = new StarGapsView();
                    }
                    StarGaps = res;
                    if (finalres == null)
                    {
                        finalres = new List<v1StarGapsdto>();
                    }
                    finalres.Add(new v1StarGapsdto(StarGaps));
                }
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);
            }

            return finalres;


        }
    }
}
