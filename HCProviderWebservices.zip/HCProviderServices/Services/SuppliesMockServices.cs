﻿using System;
using System.Data;
using System.Data.SqlClient;


using HCProviderServices;
using HCProviderDataModel;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataFactory;
using HCProviderServices.DTOModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HCProviderServices
{
    
    public class Suppliev1sMockService : ISuppliesServices
    {
        List<DailySupply> _supplies;

        Suppliev1sMockService(List<DailySupply> supplies)
        {

            _supplies = supplies;
        }

        Task<v1DailySupplydto> ISuppliesServices.GetSupply(int providerid, int userid, DateTime aptdate)
        {
            throw new NotImplementedException();
        }




    }
    

}
