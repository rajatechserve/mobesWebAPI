﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Data;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataFactory;
using HCProviderServices.DTOModels;
using System.Threading.Tasks;
using HCProviderDataModel;
using log4net;

namespace HCProviderServices
{
    /// <summary>
    /// Supplies Services
    /// </summary>
    public class SuppliesServices : ISuppliesServices
    {
        public IAppointmentscontract _apptdata = null;
        ILog _logger;

        public SuppliesServices(IAppointmentscontract apptdata, ILog logger)
        {
            _apptdata = apptdata;
            _logger = logger;
        }

        async Task<v1DailySupplydto> ISuppliesServices.GetSupply(int providerid, int userid, DateTime aptdate)
        {
            DailySupply apts = null;
            v1DailySupplydto finalres = null;
            try
            {
                var res = await _apptdata.GetDailySupply(aptdate, providerid);
                if (res != null)
                {
                    if (apts == null)
                    {
                        apts = new DailySupply();
                    }
                    apts.providerid = providerid;
                    apts.aptdate = aptdate;

                    apts.SupplyCount = res.ToList();
                    finalres = new v1DailySupplydto(apts);
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);
            }

            return finalres;

        }


    }


}
