﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Data.SqlClient;
using HCProviderDataModel;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataFactory;
using HCProviderServices.DTOModels;
using log4net;
using System.Data;

namespace HCProviderServices
{
    /// <summary>
    /// Support Services
    /// </summary>
    public class SupportServices : Isupportservices
    {


        ISupportContract _supportfact;
        ILog _logger;

        public SupportServices(SupportdataFactory supCont, ILog logger)
        {

            _supportfact = supCont;
            _logger = logger;
        }


        /// <summary>
        /// add new contact and return contact id.
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="contact"></param>
        /// <returns></returns>
       //async Task<int> Isupportservices.AddClinicalContact(int userid, v1SupportContactdto contact)
       // {
       //     int res = 0;
       //     SupportContact newcontact = new SupportContact();

       //     newcontact.ContactName = contact.ContactName;
       //     //newcontact.ContactType = "clinical";
       //     newcontact.ContactType = contact.ContactType;
       //     newcontact.ContactPhone = contact.ContactPhone;
       //     newcontact.ContactGroup = "user";
       //     newcontact.Status = 1;  // "active";
            
       //     //if exists reactivate and  return existing id
       //     res = await _supportfact.AddClinicalContact(newcontact, userid);

       //     return res;
       // }

        /// <summary>
        /// add new technical contact and return id
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="contact"></param>
        /// <returns></returns>
        //async Task<int> Isupportservices.AddTechnicalContact(int userid, v1SupportContactdto contact)
        //{
        //    int res = 0;
        //    SupportContact newcontact = new SupportContact();

        //    newcontact.ContactName = contact.ContactName;
        //    //newcontact.ContactType = "technical";
        //    newcontact.ContactType = contact.ContactType;
        //    newcontact.ContactPhone = contact.ContactPhone;
        //    newcontact.ContactGroup = "user";
        //    newcontact.Status = 1;  // "active";

        //    //if exists reactivate and  return existing id
        //    res = await _supportfact.AddClinicalContact(newcontact, userid);

        //    return res;
        //}

        async Task<int> Isupportservices.AddSupportContact(int userid, v1SupportContactdto contact)
        {
            int res = 0;
            SupportContact newcontact = new SupportContact();
            newcontact.ContactId = contact.id;
            newcontact.ContactName = contact.ContactName;
            newcontact.ContactPhone = contact.ContactPhone;
            newcontact.ContactType = contact.ContactType;


            //if exists reactivate and  return existing id
            res = await _supportfact.AddSupportContact(newcontact, userid);

            return res;
        }


        async Task<int> Isupportservices.UpdateSupportContact(int userid, v1SupportContactdto contact)
        {
            int res = 0;
            SupportContact updateContact = new SupportContact();
            updateContact.ContactId = contact.id;
            updateContact.ContactName = contact.ContactName;
            updateContact.ContactPhone = contact.ContactPhone;
            updateContact.ContactType = contact.ContactType;


            //if exists reactivate and  return existing id
            res = await _supportfact.UpdateSupportContact(updateContact, userid);

            return res;
        }

        async Task<int> Isupportservices.DeleteSupportContact(int userid, int contactid)
        {
            int res = 0;
            res = await _supportfact.DeleteSupportContact(userid, contactid);
            return res;
        }
        v1Supportlearningdto Isupportservices.GetLearningById(int userid, int resourceid)
        {
            var res = _supportfact.GetLearnings(userid, resourceid, "").SingleOrDefault ();

            return new v1Supportlearningdto(res);
        }

        IEnumerable<v1Supportlearningdto> Isupportservices.GetLearnings(int userid, string learningtype)
        {
            var res = _supportfact.GetLearnings(userid,learningtype: learningtype);

            return res.Cast<v1Supportlearningdto>();
        }

        async Task<IEnumerable<v1SupportContactdto>> Isupportservices.GetSupportContacts(int userid, string contacttype)
        {

            IList<v1SupportContactdto> SupportContac = null;

            try
            {
                var res = await _supportfact.GetSupportContacts(contacttype, userid, contactid : 0);

                _logger.Info("Get GetSupportContacts Service Method called");

                foreach (SupportContact sc in res)
                {
                    if (SupportContac == null)
                    {
                        SupportContac = new List<v1SupportContactdto>();
                    }
                    SupportContac.Add(new v1SupportContactdto(sc));
                }
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);
            }

            return SupportContac;
        }
    }
}