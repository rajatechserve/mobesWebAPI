﻿using System.Linq;
using System.Data;
using System.Data.SqlClient;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataFactory;
using HCProviderServices.DTOModels;
using HCProviderDataModel;
using System.Threading.Tasks;
using log4net;
using HCProviderServices.ServiceProtocols;
using System;
using System.Collections.Generic;

namespace HCProviderServices.Services
{
    public class TaskServices : ITaskServices
    {
        ITaskDataContract _taskDataFactory;
        ILog _logger;

        /// <summary>
        /// AppointmentServices
        /// </summary>
        /// <param name="apptFact"></param>
        public TaskServices(ITaskDataContract taskDataFactory, ILog logger)
        {
            _taskDataFactory = taskDataFactory;
            _logger = logger;

        }

        /// <summary>
        /// Add Task
        /// </summary>
        /// <param name="TaskName"></param>
        /// <param name="TaskDescription"></param>
        /// <param name="TaskDueDate"></param>
        /// <param name="TaskCreatedBy"></param>
        /// <returns>TaskID</returns>
        async Task<int> ITaskServices.AddTask(string taskName, string taskDescription, int userId, DateTime dueDate)
        {
             try
            {
                var taskId = await _taskDataFactory.AddTask(taskName, taskDescription,  dueDate, userId);               
                return taskId;
            }
            catch(Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
          
        }

        /// <summary>
        /// Add Task
        /// </summary>
        /// <param name="TaskName"></param>
        /// <param name="TaskDescription"></param>
        /// <param name="TaskDueDate"></param>
        /// <param name="TaskCreatedBy"></param>
        /// <returns>TaskID</returns>
        async Task<int> ITaskServices.UpdateTask(int taskId, string taskName, string taskDescription, string taskStatus, int taskCreatedBy, DateTime? taskDueDate)
        {
            try
            {
                var res = await _taskDataFactory.UpdateTask(taskId, taskName, taskDescription, taskStatus, taskCreatedBy, taskDueDate);
                return res;
            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }  

        }

        /// <summary>
        /// Get Tasks
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <param name="preDate"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="status"></param>
        /// <param name="pagesize"></param>
        /// <param name="pagenumber"></param>
        /// <returns>TaskList</returns>

        async Task<IEnumerable<v1Taskdto>> ITaskServices.GetTaskList(int userid, int? taskid, DateTime? fromDate, DateTime? toDate,  int? pagesize, int? pagenumber, string status)
        {
            TaskView tasks = null;
            IList<v1Taskdto> finalres = null;
            try
            {
                //IEnumerable<v1Taskdto> taskList = null;
                var res = await _taskDataFactory.GetTaskList(userid, taskid, fromDate, toDate,  pagesize, pagenumber, status);
                //if (res != null)
                //    taskList = res.Cast<v1Taskdto>();

                //return taskList;

                //  return res != null ? new v1AppointmentCountViewDto(apts) : null;
                if (res != null)
                {
                    if (tasks == null)
                    {
                        tasks = new TaskView();
                    }
                    tasks = res;
                    if (finalres == null)
                    {
                        finalres = new List<v1Taskdto>();
                    }
                    //tasks.TotalCount = 5;
                    //tasks.TotalPages = 1;
                    //tasks.Task = res.ToList();
                    finalres.Add(new v1Taskdto(tasks));
                }

            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
            return finalres;
        }


        /// <summary>
        /// Get Tasks
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <param name="preDate"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="status"></param>
        /// <param name="pagesize"></param>
        /// <param name="pagenumber"></param>
        /// <returns>TaskList</returns>

        async Task<IEnumerable<v1Taskdto>> ITaskServices.GetNewTaskList(int userid, int? taskid, DateTime? fromDate, DateTime? toDate, int? pagesize, int? pagenumber, string status)
        {
            TaskView tasks = null;
            IList<v1Taskdto> finalres = null;
            try
            {
                //IEnumerable<v1Taskdto> taskList = null;
                var res = await _taskDataFactory.GetNewTaskList(userid, taskid, fromDate, toDate, pagesize, pagenumber, status);
                
                //if (res != null)
                //    taskList = res.Cast<v1Taskdto>();

                //return taskList;

                //  return res != null ? new v1AppointmentCountViewDto(apts) : null;
                if (res != null)
                {
                    if (tasks == null)
                    {
                        tasks = new TaskView();
                    }
                    tasks = res;
                    if (finalres == null)
                    {
                        finalres = new List<v1Taskdto>();
                    }
                    //tasks.TotalCount = 5;
                    //tasks.TotalPages = 1;
                    //tasks.Task = res.ToList();
                    finalres.Add(new v1Taskdto(tasks));
                }

            }
            catch (Exception exp)
            {
                throw new DataException(exp.Message, exp);
            }
            return finalres;
        }


        /// <summary>
        ///  getAppointmentCount
        /// </summary>        
        /// <param name="userid"></param>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <returns></returns>
        async Task<v1TaskCountViewDto> ITaskServices.getTaskCount(int year, int month, int userid)
        {
            TaskCountView apts = null;
            v1TaskCountViewDto finalres = null;
            try
            {
                var res = await _taskDataFactory.GetTaskCountView(year, month, userid);

                //  return res != null ? new v1AppointmentCountViewDto(apts) : null;
                if (res != null)
                {
                    if (res.ToList().Count != 0)
                    {
                        if (apts == null)
                        {
                            apts = new TaskCountView();
                        }                       
                        apts.Year = year;
                        apts.Month = month;
                        apts.TaskCount = res.ToList();
                        finalres = new v1TaskCountViewDto(apts);
                    }
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw new DataException(exp.Message, exp);
            }

            return finalres;
        }

    }


}
