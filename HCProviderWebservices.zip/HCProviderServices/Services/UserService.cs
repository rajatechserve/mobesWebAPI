﻿using HCProviderDataModel;
using HCProviderDataModel.DataContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCProviderServices
{
    public class UserService : IUserService
    {
        IUsercontract _userdatafactory;

        public UserService(IUsercontract userFact)
        {
            _userdatafactory = userFact;
        }

        User IUserService.getUser(string username, string password)
        {

            User res = new User();
            try
            {

                res = _userdatafactory.GetUser(username, password);
            }
            catch (Exception exp)
            {

            }
            return res;
        }

        User IUserService.getUserByOptumId(string optumId)
        {

            User res = new User();
            try
            {

                res = _userdatafactory.GetUserByOptumId(optumId);
            }
            catch (Exception exp)
            {

            }
            return res;
        }
    }
}
