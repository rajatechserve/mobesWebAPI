﻿using HCProviderServices.DTOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace HCWebApi
{
  public  class AppointmentTestData
    {


        public static List<v1Appointmentdto> GetMockAppointments(int size, int providerid, DateTime aptDate)
        {
            v1Appointmentdto[] appts = new v1Appointmentdto[size];

            string[] Cities = new string[] { "Elkridge", "Ellicott", "Columbia", "Daytona", "Orlando", "Cocoa" };
            string[] ZipCodes = new string[] { "20143", "21043", "20145" };
            string[] States = new string[] { "TX", "FL", "AL", "AZ", "MD" };
            int j = 1;
            for (int i = 0; i < size; i++)
            {
                appts[i] = new v1Appointmentdto();
                appts[i].AddressLine1 = "Address1 " + j.ToString();
                appts[i].AddressLine2 = "Address2 " + j.ToString();
                appts[i].id = j;
                appts[i].AppointmentDate = aptDate;
                appts[i].FirstName = "John " + j.ToString();
                appts[i].MiddleName = "Smith" + j.ToString();
                appts[i].LastName = "K" + j.ToString();
                appts[i].MemberId = "Memberid_00" + j.ToString();
                appts[i].PrimaryPhone = " 999-999-999" + j.ToString();
                appts[i].Providerid = providerid;
                appts[i].isFlu = j % 5 == 0 ? true : false;
                //appts[i].isLabKit = j % 2 == 0 ? true : false;
                appts[i].labKit = "Blood Kit"+j.ToString();
                appts[i].isMTM = j % 2 == 0 ? true : false;
                appts[i].TransLanguage = j % 3 == 0 ? "Chinise" : "Mandorin";
                appts[i].TeamCareNotes = "scheduler notes; main door on " + (j % 2 == 0 ? "West" : "East");
                appts[i].ApptTime = j % 2 == 0 ? "8:00 AM-12:00 PM" : "1:00 PM - 5:00 PM";
                appts[i].languages = (j % 2 == 0 ? "English" : "Spanish,English");
                appts[i].MemberSource = (j % 2 == 0 ? "CIPP" : "UHC");
                appts[i].State = States[j % 5];
                appts[i].City = Cities[j % 6];
                appts[i].Zip = ZipCodes[j % 3];
                appts[i].ApptVisitOrder = j;
                appts[i].Appointmentstatus = j % 4 == 0 ? "completed" : "scheduled";
                appts[i].MobilePhone = new Random().Next(888888888, Convert.ToInt32(999999999)).ToString() + i.ToString();

                j++;

            }

            return new List<v1Appointmentdto>(appts);

        }

    
    }
}
