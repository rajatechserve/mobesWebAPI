﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Net.Http.Formatting;
using HCProviderServices;
using HCProviderServices.DTOModels;

using HCWebApi.Filters;
using HCWebApi.Providers;
using HCWebApi.Models;
using log4net;
using System.Data;
using System.Threading.Tasks;
using System.Linq;
using HCProviderDataModel.DataModels;
using static HCWebApi.Helpers.Errors;
using HCWebApi.Helpers;
using System.Configuration;
using System.IO;
using System.Web.Script.Serialization;
using System.Collections.Generic;
using HCProviderServices.ServiceProtocols;

namespace HCWebApi.Controllers
{
    
    [RoutePrefix("alerts")]
    [AuthorizeCustom]
    public class AlertController : BaseController
    {

        IAlertServices _AlertService;
        ILog _logger;
        ErrorRespData errorRespData;

        public AlertController(IAlertServices alertserv, ILog logger)
        {
            _AlertService = alertserv;
            _logger = logger;
        }


        /// <summary>
        /// Only Authorized users having roles = notifiers can call this method to get all alerts in queue
        /// 
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="source"></param>
        /// <param name="alertmessage"></param>
        /// <pa
        /// <returns></returns>
        [VersionedRoute("notify/{version}/index.{type}", "v1.0")]
        [VersionedRoute("notify/{version}", "v1.0")]
        [HttpPost]
        [ApiExceptionFilter]
        [CheckModelForNull]
        [ValidateModel]
        [HCAlertValidationFilter]
        public async Task<HttpResponseMessage> Notify([FromBody]v1Notifydto notify)
        {

            try
            {
                ValidateRequest();
                int res = 0;
                int userid = 0;
                res = await _AlertService.Notify(userid, notify);
                if (res > 0)
                {
                    return Request.CreateResponse(HttpStatusCode.Created);
                }
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }

            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
        }


        ///// <summary>
        ///// return all alerts in queue, 
        ///// use filters to get expired pending alerts if any
        ///// ?expired=1&from={date}
        ///// </summary>
        ///// <param name="userid"></param>
        ///// <param name="expired"></param>
        ///// <param name="from"></param>
        ///// <param name="to"></param>
        ///// <returns></returns>
        //[VersionedRoute("{version}/index.{type}", "v1.0")]
        //[VersionedRoute("{version}", "v1.0")]
        //[HttpGet]
        //[ApiExceptionFilter]
        //[HCAlertValidationFilter]
        //[HCETagFilter]
        //public async Task<HttpResponseMessage> GetAlerts(int? alertId = 0, string status = "active", string alerttype = "all", int? pagesize = 10, int? pagenumber = 1, int isDefault = 0, string fromdate = "", string todate = "")
        //{


        //    try
        //    {
        //        ValidateRequest();
        //        if (string.IsNullOrEmpty(fromdate))
        //        {
        //            fromdate = DateTime.Now.AddDays(-5).ToString();
        //        }
        //        if (string.IsNullOrEmpty(todate))
        //        {
        //            todate = DateTime.Now.ToString();
        //        }
        //        int userid = GetUserId();
        //        var alerts = await _AlertService.GetAlerts(userid, alertId, Convert.ToDateTime(fromdate), Convert.ToDateTime(todate), pagesize, pagenumber, status, alerttype, isDefault);
        //        if (alerts != null)
        //        {
        //            v1Alertdto result = alerts.ToList().FirstOrDefault();
        //            ResponseData resp = new HCWebApi.ResponseData(result.Alert, result.RecordCount, result.PageCount);
        //            return Request.CreateResponse(HttpStatusCode.OK, resp);
        //        }

        //    }
        //    catch (Exception exp)
        //    {
        //        _logger.Error("Error :", exp);
        //        throw exp;
        //    }
        //    throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
        //}

        [VersionedRoute("schedule/{version}/index.{type}", "v1.0")]
        [VersionedRoute("schedule/{version}", "v1.0")]
        [HttpPost]
        [ApiExceptionFilter]
        [HCAlertValidationFilter]
        [HCETagFilter]
        public async Task<HttpResponseMessage> GetScheduleAlerts(RequestParameters requestParam)
        {


            try
            {
                ValidateRequest();
                ValidateProviderId(requestParam.providerid);
                int providerid = GetProviderId();
                var alerts = await _AlertService.GetScheduleAlerts(providerid, requestParam.pagesize, requestParam.pagenumber);
                if (alerts != null)
                {
                    v1AlertScheduledto result = alerts.ToList().FirstOrDefault();
                    ResponseData resp = new HCWebApi.ResponseData(result.Alert, result.RecordCount, result.PageCount);
                    return Request.CreateResponse(HttpStatusCode.OK, resp);
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }
            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
        }



        /// <summary>
        /// Acknowledge
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="alertid"></param>
        /// <returns></returns>

        [ApiExceptionFilter]
        [VersionedRoute("{version}/{alertid}/index.{type}", "v1.0")]
        [VersionedRoute("{version}/{alertid}", "v1.0")]
        [HttpPut]
        [ApiExceptionFilter]
        [HCAlertValidationFilter]

        public async Task<HttpResponseMessage> Acknowledge(int alertid, [FromBody] UpdateAlertStatus alertStatus)
        {
            try
            {
                ValidateRequest();
                int userid = GetUserId();
                int result = await _AlertService.Acknowledge(userid, alertid, alertStatus.action);

                if (result == 0)
                {
                    return Request.CreateResponse(HttpStatusCode.Accepted);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NotAcceptable);

                }
                throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;

            }
            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
        }

        [HttpPut]
        [ApiExceptionFilter]
        [VersionedRoute("subscribe/{version}/index.{type}", "v1.0")]
        [VersionedRoute("subscribe/{version}", "v1.0")]

        public async Task<HttpResponseMessage> AlertSubscription([FromBody] NotificationsSubscription notificationsSubscription)
        {
            try
            {
                ValidateRequest();
                int userid = GetUserId();
                int result = await _AlertService.AlertSubscription(notificationsSubscription);

                if (result == 0)
                {
                    return Request.CreateResponse(HttpStatusCode.Accepted);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NotAcceptable);

                }
                throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;

            }
        }

        [HttpPost]
        [ApiExceptionFilter]
        [VersionedRoute("addendums/{version}/index.{type}", "v1.0")]
        [VersionedRoute("addendums/{version}", "v1.0")]
        [HCAlertValidationFilter]
        [HCETagFilter]

        public async Task<HttpResponseMessage> GetAddendums(RequestParameters requestParam)
        {
            try
            {
                ValidateRequest();
                ValidateProviderId(requestParam.providerid);
                
                var result = await _AlertService.GetAddendumsCount(requestParam.providerid);
                if (result != null)
                {
                    ResponseData resp = new HCWebApi.ResponseData(result);
                    var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                    return response;
                }


            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;

            }
            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
        }

        //[HttpPost]
        //[ApiExceptionFilter]
        //[VersionedRoute("weather/{version}/index.{type}", "v1.0")]
        //[VersionedRoute("weather/{version}", "v1.0")]
        //[HCAlertValidationFilter]
        //[HCETagFilter]

        public async Task<HttpResponseMessage> GetWeatherAlerts(string state, string city, RequestParameters requestParam)
        {
            try
            {

                ValidateRequest();
                ValidateProviderId(requestParam.providerid);
                int userId = GetUserId();
                string cacheKey = state + "*" + city;
                var cacheValue = MemoryCacher.GetValue(cacheKey);

                if (cacheValue == null)
                {
                    var result = await _AlertService.GetWeatherAlerts(state, city);

                    if (result != null)
                    {
                        MemoryCacher.Add(cacheKey, result, UNIXHelper.FromUnixTimeSeconds(result.Min(x => x.expires_epoch)).LocalDateTime);

                        ResponseData resp = new HCWebApi.ResponseData(result);
                        var responseBack = Request.CreateResponse(HttpStatusCode.OK, resp);
                        return responseBack;
                    }
                    else
                    {
                        MemoryCacher.Delete(cacheKey);
                    }

                    string apiUrl = ConfigurationManager.AppSettings["weatherApiUrl"];

                    string apiKey = ConfigurationManager.AppSettings["weatherApiKey"];

                    var webRequest = (HttpWebRequest)WebRequest.Create(string.Format(apiUrl, apiKey, state, city));

                    var httpWebResponse = await Task.FromResult(webRequest.GetResponseAsync());

                    Stream responseStream = httpWebResponse.Result.GetResponseStream();


                    StreamReader streamReader = new StreamReader(responseStream);

                    string data = streamReader.ReadToEnd();

                    WeatherAlert weatherAlert = (WeatherAlert)new JavaScriptSerializer().Deserialize(data, typeof(WeatherAlert));

                    if (weatherAlert.alerts == null || weatherAlert.alerts.Count() == 0)
                    {
                        List<v1WeatherAlertdto> noAlerts = new List<v1WeatherAlertdto>();
                        noAlerts.Add(new v1WeatherAlertdto(new WeatherAlertView()) { message = "No Alerts!" });
                        MemoryCacher.Add(cacheKey, noAlerts, DateTimeOffset.Now.AddHours(1));
                        ResponseData respNoData = new ResponseData(noAlerts);

                        var respNoAlerts = Request.CreateResponse(HttpStatusCode.OK, respNoData);

                        return respNoAlerts;

                    }
                    List<v1WeatherAlertdto> alerts = new List<v1WeatherAlertdto>(); 
                    foreach (var alert in weatherAlert.alerts)
                    {
                        //alert.city = city;
                        //alert.state = state;
                        //var alertServerExpiresDate = UNIXHelper.FromUnixTimeSeconds(alert.expires_epoch).LocalDateTime;
                        ////alert.localExpiryDate = UNIXHelper.FromUnixTimeSeconds(alert.expires_epoch).LocalDateTime;


                        //var alertId = await _AlertService.AddAlert(alert.type, alert.description, alert.date, alert.date_epoch, alert.expires,
                        //    alert.expires_epoch, alert.message, alert.phenomena, alert.significance, alert.city, alert.state, alertServerExpiresDate);

                        alerts.Add(new v1WeatherAlertdto(new WeatherAlertView()
                        {
                            City = city,
                            Date = alert.date,
                            DateEpoch = alert.date_epoch,
                            Description = alert.description,
                            Expires = alert.expires,
                            ExpiresEpoch = alert.expires_epoch,
                            Message = alert.message,
                            Phenomena = alert.phenomena,
                            Significance = alert.significance,
                            State = state,
                            Type = alert.type,
                            AlertServerExpiresDate = UNIXHelper.FromUnixTimeSeconds(alert.expires_epoch).LocalDateTime

                        }));
                    }

                    await _AlertService.AddAlerts(alerts);
                    var resultAlerts = await _AlertService.GetWeatherAlerts(state, city);

                    if (resultAlerts == null)
                    {
                        List<v1WeatherAlertdto> noAlerts = new List<v1WeatherAlertdto>();
                        noAlerts.Add(new v1WeatherAlertdto(new WeatherAlertView()) { message = "No Alerts!" });
                        MemoryCacher.Add(cacheKey, noAlerts, DateTimeOffset.Now.AddHours(1));
                        ResponseData respNoData = new ResponseData(noAlerts);

                        var respNoAlerts = Request.CreateResponse(HttpStatusCode.OK, respNoData);

                        return respNoAlerts;
                    }

                    MemoryCacher.Add(cacheKey, result, UNIXHelper.FromUnixTimeSeconds(resultAlerts.Min(x => x.expires_epoch)).LocalDateTime);

                    ResponseData responseData = new ResponseData(resultAlerts);

                    var response = Request.CreateResponse(HttpStatusCode.OK, responseData);

                    return response;

                }
                else
                {

                    ResponseData responseData = new ResponseData((IEnumerable<v1WeatherAlertdto>)cacheValue);

                    var response = Request.CreateResponse(HttpStatusCode.OK, responseData);

                    return response;

                }


            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);

                throw exp;

            }
            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
        }
       

        [HttpPost]
        [ApiExceptionFilter]
        [VersionedRoute("qa/{version}/index.{type}", "v1.0")]
        [VersionedRoute("qa/{version}", "v1.0")]
        [HCAlertValidationFilter]
        [HCETagFilter]

        public async Task<HttpResponseMessage> GetQA(RequestParameters requestParam)
        {
            try
            {
                ValidateRequest();
                ValidateProviderId(requestParam.providerid);

                var result = await _AlertService.GetQACount(requestParam.providerid);
                if (result != null)
                {
                    ResponseData resp = new HCWebApi.ResponseData(result);
                    var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                    return response;
                }


            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;

            }
            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
        }


        [HttpPost]
        [ApiExceptionFilter]
        [VersionedRoute("PTOAlerts/{version}/index.{type}", "v1.0")]
        [VersionedRoute("PTOAlerts/{version}", "v1.0")]
        [HCAlertValidationFilter]
        [HCETagFilter]

        public async Task<HttpResponseMessage> GetPTOAlerts(RequestParameters requestParam)
        {
            try
            {
                ValidateRequest();
                ValidateProviderId(requestParam.providerid);
                var result = await _AlertService.GetPTOAlerts(requestParam.providerid);
                if (result !=null)
                {
                    ResponseData resp = new ResponseData(result);
                    var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                    return response;
                }
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }

            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);

        }

        [HttpPost]
        [ApiExceptionFilter]
        [VersionedRoute("NoAvailability/{version}/index.{type}", "v1.0")]
        [VersionedRoute("NoAvailability/{version}", "v1.0")]
        [HCAlertValidationFilter]
        [HCETagFilter]

        public async Task<HttpResponseMessage> GetNoAvailability(RequestParameters requestParam)
        {
            try
            {
                ValidateRequest();
                ValidateProviderId(requestParam.providerid);
                var result = await _AlertService.GetNoAvailability(requestParam.providerid);
                if (result != null)
                {
                    ResponseData resp = new ResponseData(result);
                    var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                    return response;
                }
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }

            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);

        }
    }
}



