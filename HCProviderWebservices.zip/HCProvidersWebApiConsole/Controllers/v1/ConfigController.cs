﻿using HCProviderServices;
using HCProviderServices.DTOModels;

using HCWebApi.Helpers;
using HCWebApi.Models;
using HCWebApi.Providers;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using static HCWebApi.Helpers.Errors;

namespace HCWebApi.Controllers
{
    [AuthorizeCustom]
    public class ConfigController : BaseController
    {
        IConfigService _configSvc;
        ILog _logger;
        

        public ConfigController(IConfigService configsvc, ILog logger)
        {

            _configSvc = configsvc;
            _logger = logger;
           
        }

        [HttpGet]
        [ApiExceptionFilter]
        [Route("Config")]
        public async Task<HttpResponseMessage> Get()
        {
            try
            {
                var clientConfig = (IEnumerable<v1IdleTimedto>)MemoryCacher.GetValue("clientconfig");
                if (clientConfig != null)
                {
                   

                    var response = Request.CreateResponse(HttpStatusCode.OK, clientConfig);
                   
                    return response;
                }
                else
                {
                    var values = await _configSvc.GetIdleTimeValues();

                    if (values != null)
                    {
                        MemoryCacher.Add("clientconfig", values, DateTimeOffset.UtcNow.AddDays(1));
                        var response = Request.CreateResponse(HttpStatusCode.OK, values);
                        return response;
                    }
                    else
                        throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
                }
            }
            catch (Exception exp)
            {
                throw exp;

            }

        }

        //[HttpPost]
        //[ApiExceptionFilter]
        //[Route("Config")]
        //public async Task<HttpResponseMessage> Post(IdleTimeField data)
        //{
        //    try
        //    {
        //        var res = await _configSvc.SetIdleTimeValues(data.IdleTimeWarnMins, data.IdleTimeLogoutMins);

        //        return Request.CreateResponse(HttpStatusCode.Created, res);
        //    }
        //    catch (Exception exp)
        //    {
        //        throw new ItemNotFoundException();
        //    }
        //}

    }
}
