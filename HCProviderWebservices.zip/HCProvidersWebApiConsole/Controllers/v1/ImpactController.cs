﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using HCProviderServices;
using HCProviderServices.DTOModels;
using HCWebApi.Providers;
using HCWebApi.Filters;
using HCWebApi.Helpers;
using System.Threading.Tasks;
using System.Data;
using log4net;
using System.Linq;
using HCWebApi.Controllers;
using System.Collections.Generic;

using HCWebApi.Models;
using HCProviderServices.ServiceProtocols;
using HCWebApi.Filters;


namespace HCWebApi.Controllers.v1
{
    [RoutePrefix("providers/impacts")]
    [AuthorizeCustom]
    public class ImpactController : BaseController
    {
        IImpactServices _impactSvc;
        ILog _logger;
        
        private int _userId;
        private int _providerId;      
        
        /// <summary>
        /// constructor IOC.  Unity Injection
        /// </summary>
        /// <param name="apptsvc"></param>
        public ImpactController(IImpactServices impactSvc, ILog logger)
        {
            _impactSvc = impactSvc;
            _logger = logger;
           
        }


        /// <summary>
        /// Get Impacts
        /// </summary>
        /// <param name="providerid"></param> 
        /// <param name="month"></param> 
        /// <param name="year"></param>  
        /// <returns>List of Impact data </returns>

        [HttpPost]
        [VersionedRoute("{version}", "v1.0")]
        [VersionedRoute("{version}/search/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCImpactsValidationFilter]

        public async Task<HttpResponseMessage> GetImpacts(RequestParameters requestParam)
        {
                try
                {
                ValidateRequest();
                ValidateProviderId(requestParam.providerid);
                
                  var impactslist = await _impactSvc.GetImpactList(requestParam.providerid, requestParam.month, requestParam.year);
                  if (impactslist != null)
                    {
                        ResponseData resp = new HCWebApi.ResponseData(impactslist);
                        var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                        return response;
                    }

                }
                catch (Exception exp)
                {
                    _logger.Error("Error :", exp);
                throw exp; 
                }
                throw new ItemNotFoundException();
            
            }

        /// <summary>
        /// Add Goal
        /// </summary>
        /// <param name="providerid"></param> 
        /// <param name="targetedgoal"></param> 
        /// <param name="year"></param>  
        /// <returns>Http Status Code</returns>

        [HttpPost]
        [VersionedRoute("{version}", "v1.0")]
        [VersionedRoute("{version}/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCImpactsValidationFilter]

        public async Task<HttpResponseMessage> AddGoal(RequestParameters requestParam)
        {
            ValidateProviderId(requestParam.providerid);
            HttpResponseMessage response = new HttpResponseMessage();
            int userId = GetUserId();

            if (Request.Properties.ContainsKey("Validation"))
            {
                object ex = Request.Properties.Where(x => x.Key == "Validation").FirstOrDefault().Value;
                throw (Exception)ex;
            }
            else
            {
                try
                {
                    int res = await _impactSvc.AddGoal(requestParam.providerid, requestParam.targetedgoal, userId, requestParam.year);
                    if (res == 1)
                    {
                        response = Request.CreateResponse(HttpStatusCode.Accepted);
                    }
                    else
                    {
                       response = Request.CreateResponse(HttpStatusCode.NotAcceptable);

                    }
                   return response;
                }
                catch (Exception exp)
                {
                    _logger.Error("Error :", exp);
                    throw new DataException(exp.Message, exp);

                }
            }
        }
    }


}
    

