﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using HCProviderServices;
using HCProviderServices.DTOModels;
using HCWebApi.Providers;
using HCWebApi.Filters;
using System.Threading.Tasks;
using System.Data;
using log4net;
using System.Linq;
using HCWebApi.Controllers;
using System.Collections.Generic;
using static HCWebApi.Helpers.Errors;

namespace HCWebApi.Controllers
{
    /// <summary>
    /// Provider Controller 
    /// Version V1
    /// supports
    /// GetProvider Details
    /// v1/appointments/resourceversion.type(xml/json)
    /// /providers/{version}/index.{type}
    /// 
    [AuthorizeCustom]
    [RoutePrefix("providers")]
    public class ProviderController : BaseController
    {
        IProviderService _providerService;
        ILog _logger;
        private int _userId;
        ErrorRespData errorRespData;

        public ProviderController(IProviderService providerService, ILog logger)
        {
            _providerService = providerService;
            _logger = logger;
        }

        [HttpGet]
        [VersionedRoute("{version}/index.{type}", "v1.0")]
        [VersionedRoute("{version}", "v1.0")]
        [ApiExceptionFilter]
        [HCProviderValidationFilter]
        public async Task<HttpResponseMessage> GetProviders()
        {

            try
            {
                ValidateRequest();
                _userId = GetUserId();
                var providers = await _providerService.getProviders(_userId);
                if (providers != null)
                {
                    ResponseData resp = new HCWebApi.ResponseData(providers);
                    var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                    return response;
                }
                else
                {
                    throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
                }
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }

        }
    }
}
