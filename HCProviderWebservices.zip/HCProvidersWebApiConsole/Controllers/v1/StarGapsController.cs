﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using HCProviderServices;
using HCProviderServices.DTOModels;
using HCWebApi.Providers;
using HCWebApi.Filters;
using HCWebApi.Helpers;
using System.Threading.Tasks;
using System.Data;
using log4net;
using System.Linq;
using HCWebApi.Controllers;
using System.Collections.Generic;

using HCWebApi.Models;
using HCProviderServices.ServiceProtocols;



namespace HCWebApi.Controllers.v1
{
    [RoutePrefix("providers/stargaps")]
    [AuthorizeCustom]
    public class StarGapsController : BaseController
    {
        IStarGapsService _stargapsSvc;
        ILog _logger;
        
       

       
        public StarGapsController(IStarGapsService stargapsSvc, ILog logger)
        {
            _stargapsSvc = stargapsSvc;
            _logger = logger;
           
        }

        /// <summary>
        /// Get Star Gaps
        /// </summary>
        /// <param name="providerid"></param> 
        /// <param name="month"></param> 
        /// <param name="year"></param>  
        /// <returns>List of Impact data </returns>

        [HttpPost]
        [VersionedRoute("{version}", "v1.0")]
        [VersionedRoute("{version}/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCStarGapsValidationFilter]

        public async Task<HttpResponseMessage> GetStarGaps(RequestParameters requestParam)
        {
            try
            {
                ValidateRequest();
                ValidateProviderId(requestParam.providerid);

                var stargaps = await _stargapsSvc.GetStarGaps(requestParam.providerid, requestParam.month, requestParam.year);
                if (stargaps != null)
                {
                    v1StarGapsdto result = stargaps.ToList().FirstOrDefault();
                    ResponseData resp = new HCWebApi.ResponseData(result.StarGaps, result.RecordCount, result.PageCount);
                    var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                    return response;
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }
            throw new ItemNotFoundException();

        }
    }
}
