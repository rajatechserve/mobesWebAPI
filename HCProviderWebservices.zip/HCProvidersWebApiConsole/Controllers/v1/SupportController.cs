﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using HCProviderServices;
using System.Net.Http.Headers;
using HCWebApi.Providers;
using HCWebApi.Filters;
using System.Threading.Tasks;
using static HCWebApi.Helpers.Errors;
using log4net;

using System.Linq;
using System.Data;
using HCProviderServices.DTOModels;
using System.Collections.Generic;

namespace HCWebApi.Controllers
{
    /// <summary>
    /// support Controller 
    /// Version V1
    /// supports
    /// GetTechnical contacts
    /// Get Technical learnings
    /// Get clinical contacts
    /// Get clinical learnings
    /// </summary>


    [RoutePrefix("supports")]
    // [AuthorizeCustom]
    public class supportcontroller : BaseController
    {

        Isupportservices _supportservices;
        ILog _logger;
        

        /// <summary>
        /// Dependency injection
        /// </summary>
        /// <param name="isv"></param>
        public supportcontroller(Isupportservices isv, ILog logger)
        {
            _supportservices = isv;
            _logger = logger;
           


        }


        /// <summary>
        /// clinical contacts
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="contacttype">contact filter , default all, technical/clinical</param>
        /// <returns></returns>
        [HttpGet]
        [VersionedRoute("{version}", "v1.0")]
        [VersionedRoute("contacts/{version}/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCSupportValidationFilter]

        public async Task<HttpResponseMessage> GetContacts(string contacttype = "all")
        {
            int userid = 0;
            try
            {
                ValidateRequest();
                userid = GetUserId();
                var res = await _supportservices.GetSupportContacts(userid, contacttype);
                if (res != null)
                {

                    ResponseData resp = new HCWebApi.ResponseData(res);
                    var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                    return response;
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }


            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);


        }


        [HttpPost]
        [VersionedRoute("{version}", "v1.0")]
        [VersionedRoute("contacts/{version}/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCSupportValidationFilter]

        public async Task<HttpResponseMessage> AddContact([FromBody]v1SupportContactdto contact)
        {            
            try
            {
                ValidateRequest();
                int userId = GetUserId();
                var contactId = await _supportservices.AddSupportContact(userId, contact);
                if (contactId != 0)
                {
                    return Request.CreateResponse(HttpStatusCode.Created, contactId);
                }
                else
                {
                    throw new ItemNotFoundException(ErrorCodes.ContactNotSaved);
                }
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;

            }

        }

        [HttpPut]
        [VersionedRoute("{version}", "v1.0")]
        [VersionedRoute("contacts/{version}/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCSupportValidationFilter]

        public async Task<HttpResponseMessage> UpdateContact([FromBody]v1SupportContactdto updateContact)
        {

            try
            {
                ValidateRequest();
                int userId = GetUserId();
                var contactId = await _supportservices.UpdateSupportContact(userId, updateContact);
                List<v1SupportContactdto> respUpdateContact = new List<v1SupportContactdto>();
                respUpdateContact.Add(updateContact);
                ResponseData resp = new HCWebApi.ResponseData(respUpdateContact);
                if (contactId > 0)
                    return Request.CreateResponse(HttpStatusCode.Accepted, resp);
                else
                    return Request.CreateResponse(HttpStatusCode.NotAcceptable, resp);
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;

            }

        }


        [HttpPut]
        [VersionedRoute("{version}/{id}", "v1.0")]
        [VersionedRoute("contacts/{version}/{id}/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCSupportValidationFilter]

        public async Task<HttpResponseMessage> DeleteContact(int id = 0)
        {

            try
            {
                ValidateRequest();
                int userId = GetUserId();
                var contactId = await _supportservices.DeleteSupportContact(userId, id);
                v1SupportContactdto deleteContact = new v1SupportContactdto();
                deleteContact.id = id;
                List<v1SupportContactdto> respdeleteContact = new List<v1SupportContactdto>();
                respdeleteContact.Add(deleteContact);
                ResponseData resp = new HCWebApi.ResponseData(respdeleteContact);
                if (contactId > 0)
                    return Request.CreateResponse(HttpStatusCode.Accepted, resp);
                else
                    return Request.CreateResponse(HttpStatusCode.NotAcceptable, resp);
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;

            }


        }

        /// <summary>
        /// learnings
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="learningtype">clinical/technical/all {default}</param>
        /// <returns></returns>
        [HttpGet]
        [VersionedRoute("learnings/{learningtype}/{version}.{type}", "1")]
        [ApiExceptionFilter]
        public HttpResponseMessage GetLearnings(string learningtype = "all")
        {
            int userid = 1;
            var res = _supportservices.GetLearnings(userid, learningtype);
            if (res != null)
                return Request.CreateResponse(HttpStatusCode.OK, res);
            throw new ItemNotFoundException("Content not found!");
        }


        /// <summary>
        /// get the learning resources
        /// pdf/video/audio
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("learnings/{id:int}")]
        [ApiExceptionFilter]
        public HttpResponseMessage getLearningsById(int id)
        {
            int userid = 1;
            var res = _supportservices.GetLearningById(userid, id);

            if (res != null && !string.IsNullOrEmpty(res.filepath) && !string.IsNullOrEmpty(res.contenttype))
            {

                var bstream = new byteStream(res.filepath);
                var response = Request.CreateResponse();
                response.Content = new PushStreamContent((rstream, rcontent, rcontext) => bstream.WriteToStreamAsync(rstream, rcontent, rcontext), new MediaTypeHeaderValue(res.contenttype + "/" + res.contentsubtype));
                return response;
            }

            throw new ItemNotFoundException();


        }


    }
}