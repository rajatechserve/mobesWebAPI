﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using HCProviderServices;
using System.Reflection;
using HCWebApi.Filters;
using HCWebApi.Providers;

namespace HCWebApi.Controllers
{


    /// <summary>
    /// api/appointments- version 2 controller
    /// </summary>
    /// 
    [RoutePrefix("v2/providers/{providerid}")]
    public class appointmentsv2Controller:ApiController
    {

        IAppointmentServices _AptSvc;

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="v2AptServices"></param>
        public appointmentsv2Controller(IAppointmentServices v2AptServices)
        {
            _AptSvc = v2AptServices;

        }

        
        /// <summary>
       /// GetAppointments
       /// version:V2
       /// Returns OK, Bad Request, Not Found
       /// support xml/json
       /// </summary>
       /// <param name="version"></param>
       /// <param name="type"></param>
       /// <param name="aptdate"></param>
       /// <param name="providerid"></param>
       /// <returns></returns>
         
        [HttpGet]
        [VersionedRoute("{version}/appointments", "v1.0")]
        [VersionedRoute("{version}/appointments.{type}", "1.0")]
        [ApiExceptionFilter]
        public HttpResponseMessage getAppointments(int providerid ,DateTime ?aptdate =null)
        {
            int userid = 0;
            DateTime dt = DateTime.Now;

            if (aptdate != null)
                dt = aptdate.Value ;

            var resp = _AptSvc.getAppointmentsV2(providerid,userid, dt);

            if (resp != null)
                return Request.CreateResponse(HttpStatusCode.OK, resp);
            throw new ItemNotFoundException();
        }



        /// <summary>
        /// GetAppointmentsById - 
        /// Service Version : v2
        /// Returns  OK, Bad Request, Not Found 
        /// Resource Versions:  json/xml 
        /// </summary>
        /// <param name="appointmentid"></param>
        /// <param name="providerid"></param>
        /// <returns></returns>


        [HttpGet]
        [VersionedRoute("appointments/{version}/{appointmentid}", "v1.0")]
        [VersionedRoute("appointments/{version}/{appointmentid}.{type}", "1.0")]
        public HttpResponseMessage getAppointmentsById(int appointmentid, int providerid = 1)
        {

            int userid = 1;

            var res = _AptSvc.getAppointmentByIdV2(providerid, userid, appointmentid);
            if(res!=null)
                return Request.CreateResponse(HttpStatusCode.OK, res);

            throw new ItemNotFoundException();
        }


        /// <summary>
        /// call ivr acton
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="appointmentid"></param>
        /// <returns></returns>
        [HttpPut]
        [VersionedRoute("{appointmentid}/{version}.{type}", "v1.0")]
        public HttpResponseMessage updateappointment(int providerid , int appointmentid )
        {
            return Request.CreateResponse(HttpStatusCode.Accepted, "v2 updateAppointment");
        }
    }

   

}
