﻿using System.Web.Http.Controllers;
using System.Net;
using System.Net.Http;
using HCWebApi.Providers;
using System.Web.Http.Filters;
using HCWebApi.Models;
using System;
using HCProviderServices.DTOModels;
using HCWebApi.Helpers;
using static HCWebApi.Helpers.Errors;
using HCWebApi.Controllers;

namespace HCWebApi.Filters
{
    class HCAlertValidationFilterAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// OnActionExecuting
        /// </summary>
        /// <param name="actionContext"></param>
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            var descriptor = actionContext.ActionDescriptor as HttpActionDescriptor;

            string errorCode = "";

            if (descriptor != null)
            {

                #region GetAlerts
                if (descriptor.ActionName == "GetAlerts")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count == 0)
                        {
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.RequestParametersNotProvided));
                        }
                        else
                        {


                            RequestParameters param = (RequestParameters)actionContext.ActionArguments["requestParam"];

                            if (param == null)
                            {
                                errorCode = ErrorCodes.InvalidMissingRequestBodyPparameter;
                            }
                            else
                            {
                                Int32 providerId = param.providerid;
                                if (providerId == 0)
                                {
                                    errorCode = ErrorCodes.InvalidMissingProvideridParameter;
                                }

                            }
                            if (!string.IsNullOrWhiteSpace(errorCode))
                            {

                                actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                            }
                        }
                        //if (actionContext.ActionArguments.Count == 0)
                        //{
                        //    actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.RequestParametersNotProvided));
                        //}
                        //else
                        //{
                        //    Int32 isDefault = 0;

                        //    if (actionContext.ActionArguments["isDefault"] == null)
                        //    {
                        //        isDefault = 0;
                        //    }
                        //    else
                        //    {
                        //        isDefault = Convert.ToInt32(actionContext.ActionArguments["isDefault"]);
                        //    }
                        //    if (isDefault == 0)
                        //    {
                        //        if (actionContext.ActionArguments["fromdate"] == null)
                        //        {
                        //            errorCode = ErrorCodes.InvalidMissingFromDateParameter;
                        //        }
                        //        else if (actionContext.ActionArguments["todate"] == null)
                        //        {
                        //            errorCode = ErrorCodes.InvalidMissingToDateParameter;
                        //        }
                        //        else if(actionContext.ActionArguments["status"] == null)
                        //        {                                    
                        //            errorCode = ErrorCodes.InvalidMissingStatusParameter;
                        //        }
                        //        else if(actionContext.ActionArguments["alerttype"] == null)
                        //        {
                        //            errorCode = ErrorCodes.InvalidMissingAlertTypeParameter;
                        //        }
                        //        else if(actionContext.ActionArguments["pagesize"] == null)
                        //        {
                        //            errorCode = ErrorCodes.InvalidMissingPageSizeParameter;
                        //        }
                        //        else if(actionContext.ActionArguments["pagenumber"] == null)
                        //        {
                        //            errorCode = ErrorCodes.InvalidMissingPageNumberParameter;
                        //        }
                        //        DateTime? fromDate = null;
                        //        DateTime? toDate = null;
                        //        try
                        //        {
                        //            fromDate = Convert.ToDateTime(actionContext.ActionArguments["fromdate"]);
                        //        }
                        //        catch (Exception ex)
                        //        {

                        //            errorCode = ErrorCodes.InvalidFromDateParameter;
                        //        }
                        //        try
                        //        {
                        //            toDate = Convert.ToDateTime(actionContext.ActionArguments["todate"]);
                        //        }
                        //        catch (Exception ex)
                        //        {
                        //            errorCode = ErrorCodes.InvalidToDateParameter;
                        //        }


                        //        string status = Convert.ToString(actionContext.ActionArguments["status"]);
                        //        string alertType = Convert.ToString(actionContext.ActionArguments["alerttype"]);
                        //        Int32 pageSize = Convert.ToInt32(actionContext.ActionArguments["pagesize"]);
                        //        Int32 pageNumber = Convert.ToInt32(actionContext.ActionArguments["pagenumber"]);


                        //        if (fromDate != null && toDate != null)
                        //        {
                        //            if (fromDate > toDate)
                        //            {
                        //                errorCode = ErrorCodes.FromDateCannotBeGreaterThanToDate;
                        //            }
                        //            TimeSpan dateDiff = (TimeSpan)(toDate - fromDate);
                        //            if (dateDiff.TotalDays > 5)
                        //            {
                        //                errorCode = ErrorCodes.MaximumDateRangeDifferenceCanBe5DaysOnly;
                        //            }
                        //        }
                        //        else if(!String.IsNullOrEmpty(status))
                        //        {
                        //            if (status != "active" && status != "all" && status != "expired")
                        //            {
                        //                errorCode = ErrorCodes.InvalidStatusParameter;
                        //            }
                        //        }
                        //        else if(!String.IsNullOrEmpty(alertType))
                        //        {
                        //            if (alertType != "welcome" && alertType != "weather" && alertType != "schedule" && alertType != "chartsqa" && alertType != "announcements" && alertType != "all")
                        //            {
                        //                errorCode = ErrorCodes.InvalidAlertTypeParameter;
                        //            }
                        //        }
                        //    }
                        //}

                        //if (!string.IsNullOrWhiteSpace(errorCode))
                        //{

                        //    actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                        //}
                    }
                    catch (Exception exp)
                    {

                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingParameter));
                    }
                }
                #endregion


                #region Acknowledge
                if (descriptor.ActionName == "Acknowledge")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count == 0)
                        {
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.RequestParametersNotProvided));
                        }
                        else
                        {
                            UpdateAlertStatus param = (Models.UpdateAlertStatus)actionContext.ActionArguments["alertStatus"];
                            if (actionContext.ActionArguments["alertid"] == null)
                            {
                                errorCode = ErrorCodes.InvalidMissingAlertIdParameter;
                            }
                            if (param == null)
                            {
                                errorCode = ErrorCodes.InvalidMissingRequestBodyPparameter;
                            }
                            else
                            {
                                string action = param.action;
                                if (String.IsNullOrEmpty(action))
                                {
                                    errorCode = ErrorCodes.InvalidMissingActionParameter;
                                }
                                if (!String.IsNullOrEmpty(action))
                                {
                                    if (action != "ack" && action != "unack")
                                    {
                                        errorCode = ErrorCodes.InvalidMissingActionParameter;
                                    }
                                }
                            }

                        }


                        if (!string.IsNullOrWhiteSpace(errorCode))
                        {

                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                        }
                    }
                    catch (Exception exp)
                    {

                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingParameter));
                    }
                }
                #endregion

                #region Notify
                if (descriptor.ActionName == "Notify")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count == 0)
                        {
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.RequestParametersNotProvided));
                        }
                        else
                        {


                            v1Notifydto param = (v1Notifydto)actionContext.ActionArguments["notify"];

                            if (param == null)
                            {
                                errorCode = ErrorCodes.InvalidMissingRequestBodyPparameter;
                            }
                            else
                            {
                                Int32 type = param.type;
                                //100088  Appointment Reschedule
                                //100089  Appointment Cancel
                                //100090  QATK Failure
                                //100091  Weather                            
                                if (type != 100088 && type != 100089)
                                {
                                    errorCode = ErrorCodes.InvalidAlertType;
                                }
                                Int32 recipientType = param.recipientType;
                                //100094  User
                                //100097  Geolocations
                                //100098  City
                                //100104  CTM                           
                                if (recipientType != 100094)
                                {
                                    errorCode = ErrorCodes.InvalidRecipientType ;
                                }

                                string message = param.message;
                                if (String.IsNullOrEmpty(message))
                                {
                                    errorCode = ErrorCodes.InvalidMessage ;
                                }
                                Int32 targetedUser = param.targetedUser;
                                if (targetedUser < 1)
                                {

                                    errorCode = ErrorCodes.InvalidTargetedUser ;

                                }
                                Int32 source = param.source;
                                //100108  Scheduler
                                //100109  Weather API
                                //100110  QATK
                                //100111  Practitioner Portal
                                if (source != 100108 && source != 100109 && source != 100110 && source != 100111)
                                {

                                    errorCode = ErrorCodes.InvalidSource ;

                                }
                                DateTime expiresOn = param.expiresOn;
                                if (expiresOn < DateTime.Now)
                                {

                                    errorCode = ErrorCodes.InvalidExpiresOn;

                                }
                            }

                            if (!string.IsNullOrWhiteSpace(errorCode))
                            {

                                actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                            }
                        }
                    }
                    catch (Exception exp)
                    {

                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingParameter));
                    }
                }
                #endregion
                #region WeatherAlerts
                if (descriptor.ActionName == "GetWeatherAlerts")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count == 0)
                        {
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.RequestParametersNotProvided));
                        }
                        else
                        {


                            RequestParameters param = (RequestParameters)actionContext.ActionArguments["requestParam"];

                            if (param == null)
                            {
                                errorCode = ErrorCodes.InvalidMissingRequestBodyPparameter;
                            }
                            if (param.month > 0)
                            {
                                errorCode = ErrorCodes.InvalidMissingMonthparameter;
                            }
                            if (param.year > 0)
                            {
                                errorCode = ErrorCodes.InvalidMissingyearparameter;
                            }
                            if (param.targetedgoal > 0)
                            {
                                errorCode = ErrorCodes.InvalidMissingTargetedGoalparameter;
                            }
                            else
                            {
                                if (param.providerid == 0)
                                {
                                    errorCode = ErrorCodes.InvalidMissingProvideridParameter;
                                }
                            }
                            if (!string.IsNullOrWhiteSpace(errorCode))
                            {

                                actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                            }
                        }
                    }
                    catch (Exception exp)
                    {

                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingParameter));
                    }
                }
                #endregion
                #region Addendums
                if (descriptor.ActionName == "GetAddendums")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count == 0)
                        {
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.RequestParametersNotProvided));
                        }
                        else
                        {


                            RequestParameters param = (RequestParameters)actionContext.ActionArguments["requestParam"];

                            if (param == null)
                            {
                                errorCode = ErrorCodes.InvalidMissingRequestBodyPparameter;
                            }
                            if (param.month > 0)
                            {
                                errorCode = ErrorCodes.InvalidMissingMonthparameter;
                            }
                            if (param.year > 0)
                            {
                                errorCode = ErrorCodes.InvalidMissingyearparameter;
                            }
                            if (param.targetedgoal > 0)
                            {
                                errorCode = ErrorCodes.InvalidMissingTargetedGoalparameter;
                            }
                            else
                            {
                                Int32 providerId = param.providerid;
                                if (providerId == 0)
                                {
                                    errorCode = ErrorCodes.InvalidMissingProvideridParameter;
                                }

                            }
                            if (!string.IsNullOrWhiteSpace(errorCode))
                            {

                                actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                            }
                        }
                    }
                    catch (Exception exp)
                    {

                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingParameter));
                    }
                }
                #endregion
                #region Addendums
                if (descriptor.ActionName == "GetScheduleAlerts")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count == 0)
                        {
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.RequestParametersNotProvided));
                        }
                        else
                        {


                            RequestParameters param = (RequestParameters)actionContext.ActionArguments["requestParam"];

                            if (param == null)
                            {
                                errorCode = ErrorCodes.InvalidMissingRequestBodyPparameter;
                            }
                            if (param.month >0)
                            {
                                errorCode = ErrorCodes.InvalidMissingMonthparameter;
                            }
                            if (param.year > 0)
                            {
                                errorCode = ErrorCodes.InvalidMissingyearparameter;
                            }
                            if (param.targetedgoal > 0)
                            {
                                errorCode = ErrorCodes.InvalidMissingTargetedGoalparameter;
                            }
                            else
                            {
                                Int32 providerId = param.providerid;
                                if (providerId == 0)
                                {
                                    errorCode = ErrorCodes.InvalidMissingProvideridParameter;
                                }

                            }
                            if (!string.IsNullOrWhiteSpace(errorCode))
                            {

                                actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                            }
                        }
                    }
                    catch (Exception exp)
                    {

                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingParameter));
                    }
                }
                #endregion
                //#region GetAddendumsDetails
                //if (descriptor.ActionName == "GetAddendumsDetails")
                //{
                //    try
                //    {
                //        if (actionContext.ActionArguments.Count == 0)
                //        {
                //            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.RequestParametersNotProvided));
                //        }
                //        else
                //        {


                //            RequestParameters param = (RequestParameters)actionContext.ActionArguments["requestParam"];
                //            DateTime? date = (DateTime?)actionContext.ActionArguments["Date"];

                //            if (param == null)
                //            {
                //                errorCode = ErrorCodes.InvalidMissingRequestBodyPparameter;
                //            }
                //            if (date == null)
                //            {
                //                errorCode = ErrorCodes.InvalidMissingActionParameter;
                //            }
                //            else
                //            {
                //                Int32 providerId = param.providerid;
                //                if (providerId == 0)
                //                {
                //                    errorCode = ErrorCodes.InvalidMissingProvideridParameter;
                //                }

                //            }
                //            if (!string.IsNullOrWhiteSpace(errorCode))
                //            {

                //                actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                //            }
                //        }
                //    }
                //    catch (Exception exp)
                //    {

                //        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingParameter));
                //    }
                //}
                //#endregion

            }
            base.OnActionExecuting(actionContext);
        }
    }

}



