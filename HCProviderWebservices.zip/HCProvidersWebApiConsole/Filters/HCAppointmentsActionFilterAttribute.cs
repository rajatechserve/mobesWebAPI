﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Filters;

using System.Web.Routing;
using System.Security.Cryptography;
using HCWebApi.Helpers;
using System.ComponentModel;
using System.Web.Http.Controllers;
using System.Net;
using System.Net.Http;
using HCWebApi.Providers;
using HCWebApi.Models;
using static HCWebApi.Helpers.Errors;
using HCWebApi.Controllers;

namespace HCWebApi.Filters
{
    class HCAppointmentsActionFilterAttribute : ActionFilterAttribute
    {

        /// <summary>
        /// OnActionExecuting
        /// </summary>
        /// <param name="actionContext"></param>
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            string errorCode = string.Empty;
            var descriptor = actionContext.ActionDescriptor as HttpActionDescriptor;
            if (descriptor != null)
            {
                #region validation for getappointmentsview (montly view)
                if (descriptor.ActionName == "getappointmentsview")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count == 0)
                        {
                            errorCode = ErrorCodes.RequestParametersNotProvided;
                        }
                        else
                        {
                            RequestParameters param = (Models.RequestParameters)actionContext.ActionArguments["requestParam"];
                            if (param.providerid == 0)
                            {
                                errorCode = ErrorCodes.InvalidMissingProvideridParameter;
                            }
                            if (param.month < 1)
                            {
                                errorCode = ErrorCodes.InvalidMissingMonthparameter;
                            }
                            if (param.year < 1)
                            {
                                errorCode = ErrorCodes.InvalidMissingyearparameter;
                            }
                            if ((param.month >= 0) && (param.year >= 0))
                            {

                                if (param.month < 1 || param.month > 12)
                                {
                                    errorCode = ErrorCodes.InvalidMissingMonthparameter;
                                }
                                else if (param.year == 0 || param.year > DateTime.Now.Year + 1)
                                {
                                    errorCode = ErrorCodes.InvalidMissingyearparameter;
                                }
                                else if (!ValidateAppointmentDate(param.month, param.year))
                                {
                                    errorCode = ErrorCodes.MonthParameterShouldBeTwoMonthsPastOrOneMonthFuture;
                                }
                            }
                            else
                            {
                                errorCode = ErrorCodes.InvalidMissingMonthOrYearParameter;
                            }
                            
                        }

                        if (!string.IsNullOrWhiteSpace(errorCode))
                        {

                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                        }

                    }
                    catch (Exception ex)
                    {
                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingMonthOrYearParameter));
                    }
                }
                #endregion


                #region validation for GetAppointments List for date

                if (descriptor.ActionName == "GetAppointments")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count == 0)
                        {
                            errorCode = ErrorCodes.RequestParametersNotProvided;
                        }
                        else
                        {
                            RequestParameters param = (Models.RequestParameters)actionContext.ActionArguments["requestParam"];
                            if (param.aptdate == null)
                            {
                                errorCode = ErrorCodes.InvalidMissingAptdateParameter;
                            }

                            if (param.providerid < 1)
                            {
                                errorCode = ErrorCodes.InvalidMissingProvideridParameter;
                            }
                            if ((param.aptdate != null) && (param.providerid >= 1))
                            {
                                DateTime aptdate = (DateTime)param.aptdate;
                                if ((param.aptdate != null))
                                {
                                    if (!ValidateAppointmentDate(aptdate.Month, aptdate.Year))
                                    {
                                        errorCode = ErrorCodes.MonthParameterShouldBeTwoMonthsPastOrOneMonthFuture;
                                    }
                                }
                                else
                                {
                                    errorCode = ErrorCodes.InvalidMissingAptdateParameter;
                                }

                            }

                        }

                        if (!string.IsNullOrWhiteSpace(errorCode))
                        {

                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                        }
                    }
                    catch (Exception ex)
                    {
                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingAptdateParameter));
                    }
                }
                #endregion

                #region validation for GetAppointments List for datails
                if (descriptor.ActionName == "GetAppointmentDetails")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count == 0)
                        {
                            errorCode = ErrorCodes.RequestParametersNotProvided;
                        }
                        else
                        {
                            RequestParameters param = (RequestParameters)actionContext.ActionArguments["requestParam"];

                            if (param != null)
                            {
                                if (param.providerid < 1)
                                {
                                    errorCode = ErrorCodes.InvalidMissingProvideridParameter;
                                }
                               
                            }
                            else if (actionContext.ActionArguments["appointmentid"] == null)
                            {
                                errorCode = ErrorCodes.InvalidMissingAppointmentidParameter;
                            }
                        }
                        if (!string.IsNullOrWhiteSpace(errorCode))
                        {

                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                        }
                    }
                    catch (Exception ex)
                    {
                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingParameter));
                    }
                }
                #endregion

            }
            base.OnActionExecuting(actionContext);
        }


        #region ValidateAppointmentDate
        /// <summary>
        /// ValidateAppointmentDate
        /// </summary>
        /// <param name="month"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        public bool ValidateAppointmentDate(int month, int year)
        {
            DateTime dtcurrent = new DateTime(year, month, 1);
            DateTime dtstart = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddMonths(-2);
            DateTime dtend = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddMonths(2);
            return (dtcurrent >= dtstart) && (dtcurrent < dtend);
        }
    }
    #endregion
}
