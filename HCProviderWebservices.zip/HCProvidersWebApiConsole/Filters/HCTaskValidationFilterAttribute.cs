﻿using System.Web.Http.Controllers;
using System.Net;
using System.Net.Http;
using HCWebApi.Providers;
using System.Web.Http.Filters;
using HCWebApi.Models;
using System;
using static HCWebApi.Helpers.Errors;

namespace HCWebApi.Filters
{
    class HCTaskValidationFilterAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// OnActionExecuting
        /// </summary>
        /// <param name="actionContext"></param>
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            var descriptor = actionContext.ActionDescriptor as HttpActionDescriptor;

            string errorCode = "";    
                              
            if (descriptor != null)
            {
                if (descriptor.ActionName == "AddTask")
                    try
                    {
                        if (actionContext.ActionArguments.Count != 0)
                        {
                            InputTask task = (InputTask)actionContext.ActionArguments["task"];
                            if (String.IsNullOrEmpty(task.TaskName)|| String.IsNullOrEmpty(task.TaskDescription))
                            {
                                errorCode = ErrorCodes.TaskNameTaskDescriptionNullParameter ;                      
                            }
                            if(task.DueDate < DateTime.Now.Date)
                            {
                                errorCode = ErrorCodes.TaskDueDateNotTodayParameter;                                
                            }
                            if (task.DueDate == null)
                            {
                                errorCode = ErrorCodes.TaskDueDateNullParameter;
                                                
                            }

                        }

                        if(!string.IsNullOrWhiteSpace (errorCode))
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                    }
                    catch (Exception exp)
                    {
                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(exp.Message));
                    }

                    if (descriptor.ActionName == "GetTasks")
                    try
                    {
                        if (actionContext.ActionArguments.Count != 0)
                        {
                            DateTime fromDate = (DateTime)actionContext.ActionArguments["fromDate"];
                            DateTime toDate = (DateTime)actionContext.ActionArguments["toDate"];
                            string status = Convert.ToString(actionContext.ActionArguments["status"]);

                            if (fromDate != null && toDate != null)
                            {
                                if (fromDate > toDate)
                                {
                                    errorCode = ErrorCodes.FromDateCannotBeGreaterThanToDate;
                                }

                                if (!ValidateAppointmentDate(fromDate.Month, fromDate.Year))
                                {
                                    errorCode = ErrorCodes.TaskMonthParameterShouldBeTwoMonthsPastOrOneMonthFuture;
                                }
                            }
                            if (!String.IsNullOrEmpty(status))
                            {
                                if (status != "active" && status != "all")
                                    errorCode = ErrorCodes.InvalidStatusParameter;                                
                            }
                        }

                        if (!string.IsNullOrWhiteSpace(errorCode))

                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                    }
                    catch (Exception exp)
                    {

                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(exp.Message));
                    }

                if (descriptor.ActionName == "UpdateTask")
                    try
                    {
                        if (actionContext.ActionArguments.Count != 0)
                        {
                            int taskId = (int)actionContext.ActionArguments["id"];

                            UpdateTask task = (UpdateTask)actionContext.ActionArguments["task"];
                            if (String.IsNullOrEmpty(task.TaskName) & String.IsNullOrEmpty(task.TaskDescription)
                                & (task.DueDate == null) & String.IsNullOrEmpty(task.TaskStatus))
                            {
                                errorCode = ErrorCodes.Missingparamater;
                            }
                            if ((task.DueDate != null) &(task.DueDate < DateTime.Now.Date))
                            {
                                errorCode = ErrorCodes.TaskDueDateNotTodayParameter;
                                
                            }
                            if (taskId == 0)
                            {
                                errorCode = ErrorCodes.TaskIdNonZeroParameter;
                              
                            }
                        }

                        if (!string.IsNullOrWhiteSpace(errorCode))
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                    }
                    catch (Exception exp)
                    {
                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(exp.Message));
                    }
                if (descriptor.ActionName == "GetTasksDetails")
                    try
                    {
                        if (actionContext.ActionArguments["taskid"]==null)
                        {
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.TaskIdNonZeroParameter));
                        }
                        
                    }
                    catch (Exception exp)
                    {

                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(exp.Message));
                    }



                #region validation for gettaskview (montly view)
                if (descriptor.ActionName == "getTaskview")
                {
                    try
                    {


                        if (actionContext.ActionArguments["month"] == null)
                        {
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingMonthOrYearParameter));
                        }
                        if (actionContext.ActionArguments["year"] == null)
                        {
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingMonthOrYearParameter));
                        }
                        if ((actionContext.ActionArguments["month"] != null) && (actionContext.ActionArguments["year"] != null))
                        {
                            int month = (int)actionContext.ActionArguments["month"];
                            int year = (int)actionContext.ActionArguments["year"];

                            if (month < 1 || month > 12)
                            {
                                actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingMonthOrYearParameter));
                            }
                            else if (year == 0 || year > DateTime.Now.Year + 1)
                            {
                                actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingMonthOrYearParameter));
                            }
                            else if (!ValidateAppointmentDate(month, year))
                            {
                                actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.MonthParameterShouldBeTwoMonthsPastOrOneMonthFuture));
                            }
                        }
                        else
                        {
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingMonthOrYearParameter));
                        }
                    }
                    catch (Exception ex)
                    {
                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingMonthOrYearParameter));
                    }
                }
                #endregion
            }
            base.OnActionExecuting(actionContext);
        }

        #region ValidateAppointmentDate
        /// <summary>
        /// ValidateAppointmentDate
        /// </summary>
        /// <param name="month"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        public bool ValidateAppointmentDate(int month, int year)
        {
            DateTime dtcurrent = new DateTime(year, month, 1);
            DateTime dtstart = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddMonths(-2);
            DateTime dtend = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddMonths(2);
            return (dtcurrent >= dtstart) && (dtcurrent < dtend);
        }
    }
    #endregion
}

           

