﻿using System;
using log4net;

namespace HCWebApi.Helpers
{
    public interface ILogManagerAdapter
    { 
         ILog GetLog(Type typeAssociatedWithRequestedLog);
    }
}
