﻿using System;
using log4net;

namespace HCWebApi.Helpers
{
    public class LogManagerAdapter : ILogManagerAdapter
    {
        public ILog GetLog(Type typeAssociatedWithRequestedLog)
        {
            var log = LogManager.GetLogger(typeAssociatedWithRequestedLog);
            return log;
        }
    }
}
