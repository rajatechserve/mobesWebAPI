﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCWebApi.Helpers
{
    public static class UNIXHelper
    {
        public static DateTimeOffset FromUnixTimeSeconds(long seconds)
        {
            if (seconds < -62135596800L || seconds > 253402300799L)
            {
                throw new ArgumentOutOfRangeException("ArgumentOutOfRange_Range");
            }
            long ticks = seconds * 10000000L + 621355968000000000L;
            return new DateTimeOffset(ticks, TimeSpan.Zero);
        }

    }
}
