﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace HCWebApi.Models
{
    [DataContract]
    public class RequestParameters
    {

        public RequestParameters()
        {            
            month = 0;
            year = 0;       
        }
        
        [DataMember(IsRequired = true)]
        public int providerid { get; set; }

        [DataMember(IsRequired = false)]
        public DateTime? aptdate { get; set; }

        [DataMember(IsRequired = false)]
        public int month { get; set; }

        [DataMember(IsRequired = false)]
        public int year{ get; set; }

        [DataMember(IsRequired = false)]
        public int targetedgoal { get; set; }

        [DataMember(IsRequired = false)]
        public int pagesize { get; set; }

        [DataMember(IsRequired = false)]
        public int pagenumber { get; set; }

        [DataMember(IsRequired = false)]
        public int appointmentid { get; set; }

    }
}
