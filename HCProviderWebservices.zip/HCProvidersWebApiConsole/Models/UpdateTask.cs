﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace HCWebApi.Models
{
    [DataContract]
    public class UpdateTask
    {

        [DataMember(IsRequired = false)]
        public string TaskName { get; set; }

        [DataMember(IsRequired = false)]
        public string TaskDescription { get; set; }

        [DataMember(IsRequired = false)]
        public DateTime? DueDate { get; set; }

        [DataMember(IsRequired = false)]
        public int TaskId { get; set; }

        [DataMember(IsRequired = false)]
        public string TaskStatus { get; set; }

        [DataMember(IsRequired = false)]
        public bool ValueExists { set
            {
                if ((String.IsNullOrEmpty(TaskName) || String.IsNullOrEmpty(TaskDescription)))
                    ValueExists = true;

        }
    }
    }
}
