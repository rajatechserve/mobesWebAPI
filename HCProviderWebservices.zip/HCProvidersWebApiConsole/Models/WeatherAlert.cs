﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCWebApi.Models
{
    public class WeatherAlert
    {
        //public Response response { get; set; }
        public IEnumerable<Alerts> alerts { get; set; }
    }
    //public class Response
    //{
    //    public decimal version { get; set; }
    //    public string termsofService { get; set; }
    //    public Features features { get; set; }
    //}
    public class Alerts
    {
        public string type { get; set; }
        public string description { get; set; }
        public string date { get; set; }
        public long date_epoch { get; set; }
        public string expires { get; set; }
        public long expires_epoch { get; set; }
        public String message { get; set; }
        public string phenomena { get; set; }
        public char significance { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        //public IEnumerable<Zones> zones { get; set; }
        //public StormBased stormbased { get; set; }
    }
    //public class Features
    //{
    //    public int alerts { get; set; }
    //}
    //public class Zones
    //{
    //    public string state { get; set; }
    //    public string Zone { get; set; }
    //}
    //public class StormBased
    //{
    //    public IEnumerable<Vertice> vertices { get; set; }
    //    public int Vertex_count { get; set; }
    //    public StormInfo stormInfo { get; set; }
    //}
    //public class Vertice
    //{
    //    public decimal lat { get; set; }
    //    public decimal lon { get; set; }
    //}
    //public class StormInfo
    //{
    //    public Int32 time_epoch { get; set; }
    //    public int Motion_deg { get; set; }
    //    public int Motion_spd { get; set; }
    //    public decimal position_lat { get; set; }
    //    public decimal position_lon { get; set; }
    //}
}
