﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using HCWebApi;

namespace HCWebApi
{
    partial class OwinStartupService : ServiceBase
    {
        private IDisposable _webapp;

        public OwinStartupService()
        {

        }

        protected override void OnStart(string[] args)
        {
            System.Diagnostics.EventLog e = new System.Diagnostics.EventLog();
            e.Source = "Provider API Owin";
            e.WriteEntry(string.Format("Owin start: {0}\n{1}\n", "Entering", "1"));

            OwinStartupHelper ohelper = new HCWebApi.OwinStartupHelper();
            _webapp = ohelper.StartOwinServer();
           
            e.WriteEntry(string.Format("Owin start: {0}\n{1}\n", "Entering", "2"));

        }


        protected override void OnStop()
        {

            System.Diagnostics.EventLog e = new System.Diagnostics.EventLog();
            e.Source = "Provider API Owin";
            e.WriteEntry(string.Format("Owin Stop: {0}\n{1}\n", "Exiting", "1"));

            _webapp?.Dispose();
        }

    }
}
