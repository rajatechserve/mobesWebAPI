﻿using System;
using System.Linq;
using System.Web.Http;
using System.Net.Http.Formatting;
using System.Web.Hosting;
using HCProviderServices;
using Microsoft.Owin.Hosting;
using HCWebApi.Providers;
using Microsoft.Practices.Unity;
using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataFactory;
using System.ServiceProcess;
using System.Collections.Generic;
using System.Net.Http;
using HCProviderServices.ServiceProtocols;
using UnityLog4NetExtension;
using UnityLog4NetExtension.Log4Net;
using log4net;
using HCProviderServices.Services;
using HCProviderDataModel.DataFactories;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;

using HCWebApi.Providers;
using System.IO;
using log4net.Appender;
using System.Diagnostics;
using log4net.Config;
using System.Data.SqlClient;
using System.Data;
using System.Net.Mail;
using Unity;
using Unity.Lifetime;
using Unity.Injection;

namespace HCWebApi
{
    class Program
    {

        static OwinStartupHelper startuphelper;
        static System.Diagnostics.EventLog e;

        public static void Main(string[] args)
        {
            try
            {
                XmlConfigurator.Configure();
                //var date = DateTime.Now.AddDays(-10);
                var task = new LogFileCleanupTask();
                task.CleanUp();
                startuphelper = new HCWebApi.OwinStartupHelper();
                startuphelper.StartOwinServer();
                AppDomain.CurrentDomain.ProcessExit += new EventHandler(CurrentDomain_ProcessExit);
            }
            catch (Exception exp)
            {
                Console.WriteLine(string.Format("provider app : {0}\n{1}\n", exp.Message, exp.StackTrace));
            }
            Console.Write("\nPress Enter to Exit");
            Console.ReadLine();
        }
        static void CurrentDomain_ProcessExit(object sender, EventArgs e)
        {
            new EmailHelper().SendEmail("Service stopped", string.Format(EmailTemplate.EmailTemplate.ServiceStop, DateTime.Now), System.Configuration.ConfigurationManager.AppSettings["ToMailAddress"]);
        }
    }

    public class EmailHelper
    {
        private string FromAddress { get; set; }
        private string HostAddress { get; set; }
        public enum EmailConfiguration
        {
            FromAddress = 503000,
            HostAddress = 7905


        }
        private string ConnectionString
        {
            get
            {
                return System.Configuration.ConfigurationSettings.AppSettings["dbconnectionstring"].ToString();
            }
        }
        public EmailHelper()
        {
            string sqlQuery = string.Empty;
            SqlDataAdapter ad;
            DataSet dsMailAddress = new DataSet();
            try
            {
                using (SqlConnection myConnection = new SqlConnection(ConnectionString))
                {
                    if (myConnection.State == ConnectionState.Closed || myConnection.State == ConnectionState.Broken)
                        myConnection.Open();


                    sqlQuery = "SELECT Reference_Master_Id,Value FROM reference_Master with (nolock) WHERE reference_type_ref= 62 and Reference_Master_Id in (503000,7905)";
                    SqlCommand cmd = new SqlCommand(sqlQuery, myConnection);
                    cmd.CommandType = CommandType.Text;
                    ad = new SqlDataAdapter(cmd);
                    ad.Fill(dsMailAddress, "MailDetails");
                }

                dsMailAddress.Tables[0].TableName = "Mailconfig";

                if (dsMailAddress != null && dsMailAddress.Tables["Mailconfig"].Rows.Count > 0)
                {
                    for (int i = 0; i < dsMailAddress.Tables["Mailconfig"].Rows.Count; i++)
                    {
                        if (int.Parse(dsMailAddress.Tables["Mailconfig"].Rows[i]["Reference_Master_Id"].ToString()) == (long)EmailConfiguration.HostAddress)
                        {
                            if (dsMailAddress.Tables["Mailconfig"].Rows[i]["Value"] != DBNull.Value)
                                HostAddress = dsMailAddress.Tables["Mailconfig"].Rows[i]["Value"].ToString();
                        }

                        if (int.Parse(dsMailAddress.Tables["Mailconfig"].Rows[i]["Reference_Master_Id"].ToString()) == (long)EmailConfiguration.FromAddress)
                        {
                            if (dsMailAddress.Tables["Mailconfig"].Rows[i]["Value"] != DBNull.Value)
                                FromAddress = dsMailAddress.Tables["Mailconfig"].Rows[i]["Value"].ToString();

                        }



                    }
                }
            }
            catch (Exception ex)
            {

            }
        }



        public void SendEmail(string strSubject, string strBody, string ToAddress)//, out string message)
        {

            /// Description, Send an email using (SMTP).   
            MailMessage objMailMessage = new MailMessage();
            SmtpClient objSmtpClient = new SmtpClient();

            try
            {


                objMailMessage.From = new MailAddress(FromAddress);
                objMailMessage.To.Add(new MailAddress(ToAddress));

                objMailMessage.Subject = strSubject;
                objMailMessage.Body = strBody;
                objMailMessage.IsBodyHtml = true;
                objSmtpClient = new SmtpClient(HostAddress);  //new SmtpClient("172.0.0.1"); /// Server IP ? mailo2.uhc.com

                objSmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;

                objSmtpClient.Send(objMailMessage);

            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog e = new System.Diagnostics.EventLog();
                e.Source = "PhysicianEmailNotifcationConsole.ServerLog";
                e.WriteEntry(ex.Message + " ~ Message from Application : " + strBody);
            }

            finally
            {
                objMailMessage = null;
                objSmtpClient = null;
            }
        }
    }

    /// <summary>
    /// owin start helper
    /// </summary>
    public class OwinStartupHelper
    {
        string siteUrl = string.Empty;
        string productDomain = string.Empty;
        IDisposable _server = null;
        /// <summary>
        /// default constructor
        /// </summary>
        public OwinStartupHelper()
        {

        }


        /// <summary>
        /// initiates owin server
        /// </summary>
        /// <returns></returns>
        public IDisposable StartOwinServer()
        {
            _server = null;



            if (ValidateStartupConfiguration())
            {
                _server = WebApp.Start<Startup>(siteUrl);
               
                    new EmailHelper().SendEmail("Service started", string.Format(EmailTemplate.EmailTemplate.ServiceStart, DateTime.Now) , System.Configuration.ConfigurationManager.AppSettings["ToMailAddress"]);
            }
            else
            {
                throw new Exception("Cannot Start the Service. Please check configurations/error messages.\n");
            }

            return _server;
        }

        /// <summary>
        /// Called when serivce is stopped
        /// </summary>
        public void StopOwinServer()
        {
            new EmailHelper().SendEmail("Service stopped", string.Format(EmailTemplate.EmailTemplate.ServiceStop, DateTime.Now), System.Configuration.ConfigurationManager.AppSettings["ToMailAddress"]);
            _server?.Dispose();
            
        }


        /// <summary>
        /// validate configuration, database, log files
        /// </summary>
        /// <returns></returns>
        public bool ValidateStartupConfiguration()
        {
            bool status = false;

            var Validate = new HCValidateConfig();

            Validate.ValidateConfig();

            //string logpath = string.Empty;
            //bool logpathfound = true;
            //initialize config parameters
            ConfigProvider.initialize();

            siteUrl = ConfigProvider.SiteUrl;
            //logpath = ConfigProvider.logFilepath;
            productDomain = ConfigProvider.productDomain;


            //check server base url config
            if (string.IsNullOrWhiteSpace(siteUrl) == true)
            {
                throw new Exception("Site Url not configured!.\n");
                //return false;
            }

            ////check product domain name configuration
            if (string.IsNullOrWhiteSpace(productDomain))
            {

                return false;

            }



            status = new DBSettings(ConfigProvider.DBConnection).CheckDBConnectivity();

            if (!status)
            {
                throw new Exception(string.Format("Error : {0},{1}", ConfigProvider.DBConnection, " Cannot connect"));
                return false;
            }

            return status;

        }

    }
    public class LogFileCleanupTask
    {
        #region - Constructor -
        public LogFileCleanupTask()
        {
        }
        #endregion

        #region - Methods -
        /// <summary>
        /// Cleans up. Auto configures the cleanup based on the log4net configuration
        /// </summary>
        /// <param name="date">Anything prior will not be kept.</param>
        public void CleanUp()
        {
            string directory = string.Empty; 
            string filePrefix = string.Empty;

            var repo = LogManager.GetAllRepositories().FirstOrDefault();  
            if (repo == null)
                throw new NotSupportedException("Log4Net has not been configured yet.");

            var app = repo.GetAppenders().Where(x => x.GetType() == typeof(RollingFileAppender)).FirstOrDefault();
            if (app != null)
            {
                var appender = app as RollingFileAppender;

                directory = Path.GetDirectoryName(appender.File);
                filePrefix = Path.GetFileName(appender.File);
                
                CleanUp(directory, filePrefix, DateTime.Now.AddDays(-appender.MaxSizeRollBackups));
            }
        }

        /// <summary>
        /// Cleans up.
        /// </summary>
        /// <param name="logDirectory">The log directory.</param>
        /// <param name="logPrefix">The log prefix. Example: logfile dont include the file extension.</param>
        /// <param name="date">Anything prior will not be kept.</param>
        public void CleanUp(string logDirectory, string logPrefix, DateTime date)
        {
            if (string.IsNullOrEmpty(logDirectory))
                throw new ArgumentException("logDirectory is missing");

            if (string.IsNullOrEmpty(logPrefix))
                throw new ArgumentException("logPrefix is missing");

            var dirInfo = new DirectoryInfo(logDirectory);
            if (!dirInfo.Exists)
                return;

            var fileInfos = dirInfo.GetFiles("{0}*.*".Sub(logPrefix.Split('_')[0]));
            if (fileInfos.Length == 0)
                return;

            foreach (var info in fileInfos)
            {
                if (info.CreationTime < date && !(info.Name=="hclogs_"))
                {
                    info.Delete();
                }
            }

        }
        #endregion
    }
    [DebuggerStepThrough, DebuggerNonUserCode]
    public static class StringExtensions
    {
        /// <summary>
        /// Formats a string using the <paramref name="format"/> and <paramref name="args"/>.
        /// </summary>
        /// <param name="format">The format.</param>
        /// <param name="args">The args.</param>
        /// <returns>A string with the format placeholders replaced by the args.</returns>
        public static string Sub(this string format, params object[] args)
        {
            return string.Format(format, args);
        }
    }
    



    /// <summary>
    /// initialize dependency mapping
    /// 
    /// </summary>
    public class DependencyMapper
    {


        public static UnityContainer Prepare()
        {
            UnityContainer uoc = new UnityContainer();
            try
            {
                GlobalHost.DependencyResolver.Register(typeof(IHubActivator),() => new NotificationSignalRServiceHubActivator(uoc));
                uoc.RegisterType<NotificationHub, NotificationHub>(new TransientLifetimeManager());
                //uoc.AddNewExtension<Log4NetExtension>();

                uoc.RegisterType<IAppointmentServices, AppointmentServices>();
                uoc.RegisterType<ITaskServices, TaskServices>();
                //uoc.RegisterType<IHCOptumLogger, HCOptumLogger>(new InjectionConstructor(LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)));

                //uoc.RegisterType<ILogger, Logger>();
                //uoc.RegisterType(typeof(ILogManager), typeof(LogManagerAdapter));
                //uoc.RegisterType<IAppointmentv1Services, Appointmentv1Mockservice>(new InjectionConstructor (AppointmentTestData .GetMockAppointments(10,39366,DateTime.Today ) , 
                //    AppointmentTestData.GetAppointmentMockView (DateTime.Now.Year ,39366)));
                uoc.RegisterType<IAppointmentscontract, Appointmentdatafactory>(new InjectionConstructor(ConfigProvider.DBConnection, LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)));
               // uoc.RegisterType<INotificationsContract, NotificationsDataFactory>(new InjectionConstructor(ConfigProvider.DBConnection, LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)));
                
                uoc.RegisterType<ISuppliesServices, SuppliesServices>();

                uoc.RegisterType<Isupportservices, SupportServices>();
                uoc.RegisterType<ISupportContract, SupportdataFactory>(new InjectionConstructor(ConfigProvider.DBConnection, LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)));
                uoc.RegisterType<ITaskDataContract, TaskDataFactory>(new InjectionConstructor(ConfigProvider.DBConnection, LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)));

                uoc.RegisterType<IAlertContract, Alertdatafactory>(new InjectionConstructor(ConfigProvider.DBConnection, LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)));
                uoc.RegisterType<IAlertServices, Alertservices>();
                uoc.RegisterType<IProviderService, ProviderService>();
                uoc.RegisterType<IProviderDataContract, ProviderDataFactory>(new InjectionConstructor(ConfigProvider.DBConnection, LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)));
                uoc.RegisterType<IUserService, UserService>();
                uoc.RegisterType<IUsercontract, UserDatafactory>(new InjectionConstructor(ConfigProvider.DBConnection, LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)));
                uoc.RegisterType<IConfigService, ConfigService>();
                uoc.RegisterType<IConfigContract, ConfigDataFactory>(new InjectionConstructor(ConfigProvider.DBConnection, LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)));
                uoc.RegisterType<IImpactServices, ImpactServices>();
                uoc.RegisterType<IImpactContract, ImpactDataFactory>(new InjectionConstructor(ConfigProvider.DBConnection, LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)));
                uoc.RegisterType<IStarGapsService, StarGapsService>();
                uoc.RegisterType<IStarGapsContract, StarGapsDataFactory>(new InjectionConstructor(ConfigProvider.DBConnection, LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)));

            }
            catch (Exception exp)
            {

            }
            return uoc;

        }

       

    }
}