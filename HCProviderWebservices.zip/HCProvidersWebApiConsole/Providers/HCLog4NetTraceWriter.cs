﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Http.Tracing;
using log4net;
using HCWebApi.Helpers;
using System.IO;
using System.Text;
using System.ServiceProcess;

namespace HCWebApi.Providers
{
    public class HCLog4NetTraceWriter : ITraceWriter  
    
    {
        private readonly ILog _logger;
        String strLog;
        private static string servicename = ConfigProvider.servicename;   

        public HCLog4NetTraceWriter(ILogManagerAdapter logmanager)
        {
            _logger = logmanager.GetLog(typeof(HCLog4NetTraceWriter));
        }

        public void Trace(HttpRequestMessage request, string category, TraceLevel level, Action<TraceRecord> traceAction)
        {
            TraceRecord rec = new TraceRecord(request, category, level);
         
            traceAction(rec);
         
            if (rec.Level.ToString().Equals("Info"))
            {
                WriteInfoLevel(rec);
            }
            if (rec.Level.ToString().Equals("Debug"))
            {
                WriteDebugLevel(rec);
            }
            if (rec.Level.ToString().Equals("Warn"))
            {
                WriteWarnLevel(rec);
            }
            if (rec.Level.ToString().Equals("Error"))
            {
                WriteErrorLevel(rec);
                
            }
            if (rec.Level.ToString().Equals("Fatal"))
            {
                WriteFatalLevel(rec);
            }
        }

        private void WriteFatalLevel(TraceRecord rec)
        {
            strLog = string.Format("{0};{1};{2};{3};{4}", rec.Category, rec.Operator, rec.Operation, rec.Message, this.AdditionalMessage(rec));
            _logger.Fatal(strLog);
        }

        private void WriteErrorLevel(TraceRecord rec)
        {
            strLog = string.Format("{0};{1};{2};{3};{4}", rec.Category, rec.Operator, rec.Operation, rec.Message, this.AdditionalMessage(rec));
            _logger.Error(strLog);
        }

        private void WriteWarnLevel(TraceRecord rec)
        {
            strLog = string.Format("{0};{1};{2};{3};{4}", rec.Category, rec.Operator, rec.Operation, rec.Message, this.AdditionalMessage(rec));
            _logger.Warn(strLog);
        }

        private void WriteInfoLevel(TraceRecord rec)
        {
            strLog = string.Format("{0};{1};{2};{3};{4}", rec.Category, rec.Operator, rec.Operation, rec.Message, this.AdditionalMessage(rec));
            _logger.Info(strLog);       
        }
        private void WriteDebugLevel(TraceRecord rec)
        {
            strLog = string.Format("{0};{1};{2};{3};{4}", rec.Category, rec.Operator, rec.Operation, rec.Message, this.AdditionalMessage(rec));
            _logger.Debug(strLog);
        }

        private string AdditionalMessage(TraceRecord record)
        {
            var message = new StringBuilder();
            try
            {
                System.Object obj = new System.Object();

                if (record.Request != null)
                {
                    message.Append(record.Request.Method.ToString() + "  ").Append(record.Request.RequestUri.ToString() + " ")
                        .Append("Header :  " + record.Request.Headers.ToString());
                }
                    message.Append(record.Category + "  ").Append(record.Operator + "  ")
                    .Append(record.Operation + "  ").Append(record.Message + "  ");
                 

                if (record.Exception != null)
                {
                    message.Append(record.Exception.GetBaseException().Message);
                }                                            
                
            }
            catch (Exception ex)
            {
                Eventlogger(ex);

            }
            return message.ToString();

        }

        /// <summary>
        ///// Exception logger to Eventlog
        /// </summary>
        /// <param name="exp"></param>
        public void Eventlogger(Exception exp)
        {

            System.Diagnostics.EventLog e = new System.Diagnostics.EventLog();
            e.Source = servicename;
            e.WriteEntry(string.Format("Message:{0}\nStackTrace:{1}", exp.Message, exp.StackTrace));

        }

    }
}
