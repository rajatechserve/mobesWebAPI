﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HCWebApi.Enumeration
{
  
    //public enum LogSeverity : long
    //{
    //    Debug=1,
    //    Error=2,
    //}



}
