﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ExceptionHandling;
using System.Web.Http.Filters;
using System.Web.Http.Tracing;
using log4net;
using static HCWebApi.Helpers.Errors;

namespace HCWebApi.Providers
{

    public class ApiExceptionFilter : ExceptionFilterAttribute

    {
        public override void OnException(HttpActionExecutedContext context)
        {
            ErrorRespData resp = new HCWebApi.ErrorRespData(context.Exception.Message);

            if (context.Exception is NotImplementedException)
            {

                context.Response = context.Request.CreateResponse(HttpStatusCode.NotImplemented, resp);

            }
            else if (context.Exception is ItemNotFoundException)
            {
                
                context.Response = context.Request.CreateResponse(HttpStatusCode.NoContent);

            }
            else if (context.Exception is InvalidResourceVersion)
            {
                context.Response = context.Request.CreateResponse(HttpStatusCode.BadRequest, resp);
            }

            else if (context.Exception is InvalidResourceType)
            {
                context.Response = context.Request.CreateResponse(HttpStatusCode.BadRequest, resp);

            }
            else if (context.Exception is MissingParameterExecption)
            {
                context.Response = context.Request.CreateResponse(HttpStatusCode.BadRequest, resp);

            }
            else if (context.Exception is AuthenticationfailureException)
            {
                context.Response = context.Request.CreateResponse(HttpStatusCode.Unauthorized, resp);

            }
            else if (context.Exception is InvalidParamerterException)
            {
                context.Response = context.Request.CreateResponse(HttpStatusCode.BadRequest, resp);
            }
            else if (context.Exception is InvalidTokenException)
            {
                context.Response = context.Request.CreateResponse(HttpStatusCode.BadRequest, resp);
            }
            else if (context.Exception is TokenMissingException)
            {
                context.Response = context.Request.CreateResponse(HttpStatusCode.BadRequest, resp);
            }
            else if (context.Exception is TokenExpiredException)
            {
                context.Response = context.Request.CreateResponse(HttpStatusCode.BadRequest, resp);
            }
            else if (context.Exception is UserNotFountException)
            {
                context.Response = context.Request.CreateResponse(HttpStatusCode.BadRequest, resp);
            }
            else if (context.Exception is InactiveUserException)
            {
                context.Response = context.Request.CreateResponse(HttpStatusCode.BadRequest, resp);
            }
            else if (context.Exception is MultipleUsersException)
            {
                context.Response = context.Request.CreateResponse(HttpStatusCode.BadRequest, resp);
            }
            
            else if (context.Exception is UnAuthorizedProviderIdException)
            {
                context.Response = context.Request.CreateResponse(HttpStatusCode.BadRequest, resp);
            }
            else
            {
                context.Response = new HttpResponseMessage(HttpStatusCode.InternalServerError);
            }

        }

    }

    /// <summary>
    /// HC Custom exception handler- do not send exception details to customer. 
    /// </summary>
    public class ApiExceptionHandler : ExceptionHandler
    {
        public override void Handle(ExceptionHandlerContext context)
        {

            if (context.Exception is NotImplementedException)
            {

                var resp = new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.NotImplemented,
                    Content = new StringContent("Operation not Implemented!"),
                  //  Content = new StringContent(context.Exception.Message + context.Exception .InnerException.StackTrace),
                    ReasonPhrase = "Operation Not Implemented!"
                };
                context.Result = new ExceptionResult(context.Request, resp);
            }
            
            else
            {

                var resp = new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.InternalServerError,
                    Content = new StringContent("internal Server Error!"),
                    ReasonPhrase = "Internal Server Error!"
                };
                context.Result = new ExceptionResult(context.Request, resp);
            }            
        }
    }


    public class UnhandledExceptionLogger : ExceptionLogger
    {

        private readonly ILog _logger = LogManager.GetLogger(typeof(UnhandledExceptionLogger));

        public override void Log(ExceptionLoggerContext context)
        {
            var log = context.Exception.ToString();

        ITraceWriter tw = context.RequestContext.Configuration.Services.GetTraceWriter();

            if (tw != null)
                _logger.Error(context.Request, context.Exception);

            //tw.Trace(context.Request, "Error", TraceLevel.Error, context.Exception);



        }
    }


    public class ItemNotFoundException : Exception
    {
        // public ItemNotFoundException(string message="Item not Found!") : base(message) { }
        public ItemNotFoundException(string message = ErrorCodes.ItemNotFoundException) : base(message) { }
        public ItemNotFoundException(Exception ex, string message) : base(message, ex) { }
    }
    public class InvalidTokenException : Exception
    {
        public InvalidTokenException(string message = ErrorCodes.InvalidToken) : base(message) { }
        public InvalidTokenException(Exception ex, string message) : base(message, ex) { }
    }
    public class TokenMissingException : Exception
    {
        public TokenMissingException(string message = ErrorCodes.TokenMissing) : base(message) { }
        public TokenMissingException(Exception ex, string message) : base(message, ex) { }
    }
    public class TokenExpiredException : Exception
    {
        public TokenExpiredException(string message = ErrorCodes.TokenExpired) : base(message) { }
        public TokenExpiredException(Exception ex, string message) : base(message, ex) { }
    }
 
    public class UserNotFountException : Exception
    {
        public UserNotFountException(string message = ErrorCodes.UserNotFound) : base(message) { }
        public UserNotFountException(Exception ex, string message) : base(message, ex) { }
    }

    public class InactiveUserException : Exception
    {
        public InactiveUserException(string message = ErrorCodes.InactiveUser) : base(message) { }
        public InactiveUserException(Exception ex, string message) : base(message, ex) { }
    }
    public class MultipleUsersException : Exception
    {
        public MultipleUsersException(string message = ErrorCodes.MultipleUsers) : base(message) { }
        public MultipleUsersException(Exception ex, string message) : base(message, ex) { }
    }
    
    public class UnscheduledAppointmentStatusexception : Exception

    {
        public UnscheduledAppointmentStatusexception(string message= "This appointment status is not scheduled!") : base(message) { }
        public UnscheduledAppointmentStatusexception(string message, Exception ex) : base(message, ex) { }

    }
    public class InvalidResourceVersion : Exception
    {
        public InvalidResourceVersion(string message= ErrorCodes.InvalidResourceVersion) : base(message) { }
        public InvalidResourceVersion(string message, Exception ex) : base(message, ex) { }
    }

    public class InvalidResourceType : Exception
    {
        public InvalidResourceType(string message= ErrorCodes.InvalidResourceType) : base(message) { }
        public InvalidResourceType(string message, Exception ex) : base(message, ex) { }
    }

    public class MissingParameterExecption : Exception
    {
        public MissingParameterExecption(string message= ErrorCodes.Missingparamater ) :base(message)
        {
           
        }
        public MissingParameterExecption(string message, Exception ex) : base(message, ex) { }
    }

    public class AuthenticationfailureException : Exception
    {

        public AuthenticationfailureException(string message = ErrorCodes.UnAuthorized) :base(message)
        {

        }
        public AuthenticationfailureException(string message, Exception ex) : base(message, ex) { }

    }


    public class InvalidParamerterException : Exception
    {
        public InvalidParamerterException(string message = ErrorCodes.InvalidParameter) : base(message)
        {
        }
        public InvalidParamerterException(string message, Exception ex) : base(message, ex) { }
    }

    public class UnAuthorizedProviderIdException : Exception
    {
        public UnAuthorizedProviderIdException(string message = ErrorCodes.UnAuthorizedProviderId) : base(message)
        {
        }
        public UnAuthorizedProviderIdException(string message, Exception ex) : base(message, ex) { }
    }

    
    public class NotImplementedApiException : NotImplementedException
    {
        public NotImplementedApiException(string message = ErrorCodes.UrlDisabled) : base(message)
        {
        }
        public NotImplementedApiException(string message, Exception ex) : base(message, ex) { }
    }

    public class ExceptionResult : IHttpActionResult
    {
        private HttpRequestMessage _request;
        private HttpResponseMessage _httpResponseMessage;


        public ExceptionResult(HttpRequestMessage request, HttpResponseMessage httpResponseMessage)
        {
            _request = request;
            _httpResponseMessage = httpResponseMessage;
        }

        public Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult(_httpResponseMessage);
        }
    }

}
