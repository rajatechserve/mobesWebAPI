﻿using OptumLogging;
using System;
using System.Reflection;

namespace HCWebApi.Providers
{
    public static class HCOptumLogging
    {
        private static bool mIsOptumSecurityLogging = false;
        public static bool IsOptumSecurityLogging
        {
            get { return mIsOptumSecurityLogging; }
            set { mIsOptumSecurityLogging = value; }
        }

        private static bool mIsOptumMethodLogging = false;
        public static bool IsOptumMethodLogging
        {
            get { return mIsOptumMethodLogging; }
            set { mIsOptumMethodLogging = value; }
        }

        /// <summary>
        /// Opum Log MethodEntry
        /// </summary>
        /// <param name="moduleName"></param>
        public static void MethodEntry(string moduleName)
        {
            try
            {
                if (IsOptumSecurityLogging && IsOptumMethodLogging)
                    OptumLogger.LogEvent(OptumLogger.EVENT_TYPE.LOG_START, "Logged machine enter into " + moduleName, null);
            }
            catch (Exception ex)
            {
                if (IsOptumSecurityLogging && IsOptumMethodLogging)
                    OptumLogger.LogException(ex, moduleName);
            }
        }

        /// <summary>
        /// Optum Log MethodExit
        /// </summary>
        /// <param name="moduleName"></param>
        public static void MethodExit(string moduleName)
        {
            try
            {
                if (IsOptumSecurityLogging && IsOptumMethodLogging)
                    OptumLogger.LogEvent(OptumLogger.EVENT_TYPE.LOG_STOP, "Logged machine exit from " + moduleName, null);
            }
            catch (Exception ex)
            {
                if (IsOptumSecurityLogging && IsOptumMethodLogging)
                {
                    OptumLogger.LogException(ex, moduleName);
                }
            }
        }


        /// <summary>
        /// Logs the Member PHI data to Optum log
        /// </summary>
        /// <param name="entityIds"></param>
        /// <param name="protectedFields">protected field names</param>
        /// <param name="moduleName"></param>
        public static async void LogPHIInformation(string[] entityIds, string[] protectedFields, string moduleName)
        {
            try
            {
                if (IsOptumSecurityLogging)
                {
                    //OptumLogger.LogEvent(OptumLogger.EVENT_TYPE.LOG_START, "Logged machine accessed into " + moduleName, null);

                    if (entityIds != null && entityIds.Length > 0 && protectedFields != null && protectedFields.Length > 0)
                    {
                     OptumLogger.LogPIIAccess(entityIds, protectedFields, null);
                    }
                }
            }
            catch (Exception ex)
            {
                OptumLogger.LogException(ex, "OptumLog.LogPHIInformation" + " ~ " + moduleName);
            }
        }

        /// <summary>
        /// Logs the Member PHI data to Optum log
        /// </summary>
        /// <param name="entityId"></param>
        /// <param name="protectedFields">protected field names</param>
        /// <param name="moduleName"></param>
        public static void LogPHIInformation(string entityId, string[] protectedFields, string moduleName)
        {
            try
            {
                if (IsOptumSecurityLogging)
                {
                    string[] entityIds = new string[1];
                    entityIds[0] = entityId;
                    LogPHIInformation(entityIds, protectedFields, moduleName);
                }
            }
            catch (Exception ex)
            {
                OptumLogger.LogException(ex, "OptumLog.LogPHIInformation" + " ~ " + moduleName);
            }
        }

        /// <summary>
        /// Logs the Member PHI data to Optum log
        /// </summary>
        /// <param name="objectList">class objects collection</param>
        /// <param name="entityFieldName">field name contains entity value</param>
        /// <param name="protectedFields">protected field names</param>
        /// <param name="moduleName"></param>
        public static void LogPHIInformation(object[] objectsList, string entityFieldName, string[] protectedFields, string moduleName)
        {
            try
            {
                if (IsOptumSecurityLogging)
                {
                    if (objectsList != null && objectsList.Length > 0 && !string.IsNullOrEmpty(entityFieldName))
                    {
                        System.Collections.ArrayList entityIds = new System.Collections.ArrayList();

                        PropertyInfo entityProperty = null;
                        string entId = "";
                        foreach (object obj in objectsList)
                        {
                            entityProperty = obj.GetType().GetProperty(entityFieldName);

                            if (entityProperty != null && entityProperty.CanRead)
                            {
                                entId = entityProperty.GetValue(obj, null).ToString();
                                if (!entityIds.Contains(entId))
                                    entityIds.Add(entId);
                            }
                        }

                        LogPHIInformation((string[])entityIds.ToArray(typeof(string)), protectedFields, moduleName);
                    }
                }
            }
            catch (Exception ex)
            {
                OptumLogger.LogException(ex, "OptumLog.LogPHIInformation" + " ~ " + moduleName);
            }
        }


        
    }
}
