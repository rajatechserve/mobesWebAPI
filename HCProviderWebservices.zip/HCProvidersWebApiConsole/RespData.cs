﻿using HCProviderServices.DTOModels;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace HCWebApi
{
    /// <summary>
    /// response data wrapper for json/xml returns
    /// </summary>
    [DataContract]
    [XmlInclude(typeof(v1Appointmentdto))]
    public class ResponseData
    {
        /// <summary>
        /// constructor
        /// </summary>
        public ResponseData()
        {

        }
        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="datalist"></param>
        public ResponseData(IEnumerable <object> datalist)
        {

            data = datalist.ToList();
            Count = datalist.Count<object>();
           
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="datalist">Pageing Result Record Count</param>
        /// <param name="RecordCount">Actual Record Count </param>
        /// <param name="PageCount">Actual Page Count</param>
        public ResponseData(IEnumerable<object> datalist,int RecordCount,int PageCount)
        {
            this.RecordCount = RecordCount;
            this.PageCount = PageCount;
            data = datalist.ToList();
            Count = datalist.Count<object>();

        }

        /// <summary>
        /// result data
        /// </summary>
        [JsonProperty("records")]
        public List<object> data { get; set; }

        /// <summary>
        /// keeps number of records in enum
        /// </summary>
        [JsonProperty("count")]
        public int Count { get; set; }


        /// <summary>
        /// Actual Record Count
        /// </summary>
        [JsonProperty("totalRecordCount")]
        public int RecordCount { get; set; }
        /// <summary>
        /// Number of Page count
        /// </summary>
        [JsonProperty("totalPageCount")]
        public int PageCount { get; set; }



    }
}
