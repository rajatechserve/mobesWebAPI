﻿using System;
using System.Threading.Tasks;
using Microsoft.Owin;
using Owin;
using Microsoft.AspNet.SignalR;
using HCWebApi.Providers;
using Microsoft.Owin.FileSystems;
using Microsoft.Owin.StaticFiles;
using Microsoft.Owin.Security.OAuth;
using System.Web.Http;
using Newtonsoft.Json.Serialization;
using System.Web.Http.ExceptionHandling;
using System.Configuration;
using Microsoft.Owin.Security.DataHandler.Encoder;
using System.Web.Http.Cors;
using System.Net.Http;
using System.Net;
using System.Threading;
using Microsoft.Owin.Security.Jwt;
using Microsoft.Owin.Security;
using HCWebApi.Helpers;
using Microsoft.AspNet.SignalR.Hubs;

[assembly: OwinStartup(typeof(HCWebApi.Startup))]


namespace HCWebApi
{
    /// <summary>
    /// OWIN Startup class
    /// </summary>
    public class Startup
    {

        string productDomain;

        /// <summary>
        /// Owin app configuration
        /// </summary>
        /// <param name="app"></param>
        public void Configuration(IAppBuilder app)
        {



            var root = "HelpPage/";
            var fileSystem = new PhysicalFileSystem(root);
            var options = new FileServerOptions();
            options.EnableDirectoryBrowsing = false;
            options.FileSystem = fileSystem;
            app.UseFileServer(options);

            ConfigureAuth(app);


            //AreaRegistration.RegisterAllAreas();
            var webApiConfiguration = ConfigureWebApi();

            // signalr may only detect in-memory hubs i.e load the namespace where signalr is implmented. 
            ///if any issue with notification service , uncomment and restart server'
            // var a = Assembly.LoadFrom("hcproviderservices.dll");

            webApiConfiguration.EnsureInitialized();
            var hubConfiguration = new HubConfiguration();
            hubConfiguration.EnableDetailedErrors = true;            
            app.MapSignalR("/notifier", hubConfiguration);
         
            // Use the extension method provided by the WebApi.Owin library:
            app.UseWebApi(webApiConfiguration);



        }


        /// <summary>
        /// Authentication configuration
        /// </summary>
        /// <param name="app"></param>
        private void ConfigureAuth(IAppBuilder app)
        {

            //var issuer = ConfigurationManager.AppSettings["site"];
            //var secret = TextEncodings.Base64Url.Decode(ConfigurationManager.AppSettings["ClientKey"]);
            //var clientid = ConfigurationManager.AppSettings["clientid"];

            //app.UseJwtBearerAuthentication(new JwtBearerAuthenticationOptions
            //{
            //    AuthenticationMode = AuthenticationMode.Active,
            //    AllowedAudiences = new[] { "*" },
            //    IssuerSecurityTokenProviders = new IIssuerSecurityTokenProvider[]
            //    {
            //        new SymmetricKeyIssuerSecurityTokenProvider(issuer, secret)
            //    }
            //});

            //app.UseOAuthAuthorizationServer(new OAuthAuthorizationServerOptions
            //{
            //    AllowInsecureHttp = true,
            //    TokenEndpointPath = new PathString("/Token"),
            //    AccessTokenExpireTimeSpan = TimeSpan.FromMinutes(20),
            //    Provider = new ApplicationOAuthServerProvider(),
            //    //AccessTokenFormat = new CustomJwtFormat(issuer)
            //});


        }

        /// <summary>
        /// web api pipeline configuration
        /// </summary>
        /// <returns></returns>
        private HttpConfiguration ConfigureWebApi()
        {
            HttpConfiguration config = new HttpConfiguration();

            if (!ConfigProvider.isInitialized)
                ConfigProvider.initialize();

            productDomain = ConfigProvider.productDomain;

            var cors = new EnableCorsAttribute("*", "*", "*");
            config.EnableCors(cors);
            config.MessageHandlers.Add(new PreflightRequestsHandler());

            var jsonFormatter = config.Formatters.JsonFormatter;
            jsonFormatter.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();

            config.MapHttpAttributeRoutes();

            config.Filters.Add(new CheckModelForNullAttribute());
            //config.Filters.Add(new DynamicformatProvider());
            // config.Services.Replace(typeof(System.Web.Http.Tracing.ITraceWriter), new Tracer());

            config.Services.Replace(typeof(IExceptionHandler), new ApiExceptionHandler());
            config.Services.Replace(typeof(IExceptionLogger), new UnhandledExceptionLogger());
            config.DependencyResolver = new UnityResolver(DependencyMapper.Prepare());
            config.Services.Replace(typeof(System.Web.Http.Tracing.ITraceWriter), new HCLog4NetTraceWriter(new LogManagerAdapter()));
            //log4net.Config.XmlConfigurator.Configure(new FileInfo(Server.MapPath("~/App.config")));
            //log4net.Config.XmlConfigurator.Configure(new FileInfo(("~/App.config")));

            

            return config;
        }

        public class PreflightRequestsHandler : DelegatingHandler
        {
            protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
            {
                if (request.Headers.Contains("Origin") && request.Method.Method == "OPTIONS")
                {
                    var response = new HttpResponseMessage { StatusCode = HttpStatusCode.OK };
                    response.Headers.Add("Access-Control-Allow-Origin", "*");
                    response.Headers.Add("Access-Control-Allow-Headers", "Origin, Content-Type, Accept, Authorization");
                    response.Headers.Add("Access-Control-Allow-Methods", "*");
                    var tsc = new TaskCompletionSource<HttpResponseMessage>();
                    tsc.SetResult(response);
                    return tsc.Task;
                }
                return base.SendAsync(request, cancellationToken);
            }
        }



    }
}
