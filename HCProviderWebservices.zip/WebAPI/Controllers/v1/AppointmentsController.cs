﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using HCProviderServices;
using HCProviderServices.DTOModels;
using WebAPI.Providers;
using WebAPI.Filters;
using WebAPI.Helpers;
using System.Threading.Tasks;
using System.Data;
using log4net;
using System.Linq;
using WebAPI.Controllers;
using System.Collections.Generic;

using WebAPI.Models;
using WebAPI.Helpers;
using static WebAPI.Helpers.Errors;
//using System.Speech.Synthesis;
using System.Configuration;
using System.Threading;
//using System.Speech.AudioFormat;

namespace WebAPI.Controllers
{
    /// <summary>
    /// Appointment Controller 
    /// Version V1
    /// supports
    /// GetAppointments
    /// GetAppointmentsById
    /// Appoin
    /// v1/appointments/resourceversion.type(xml/json)
    /// </summary>  
    [RoutePrefix("providers/appointments")]
    [AuthorizeCustom]
    public class appointmentsController : BaseController
    {


        IAppointmentServices _AppointmentSvc;
        ILog _logger;
 

        /// <summary>
        /// constructor IOC.  Unity Injection
        /// </summary>
        /// <param name="apptsvc"></param>
        public appointmentsController(IAppointmentServices apptsvc, ILog logger)

        {

            _AppointmentSvc = apptsvc;
            _logger = logger;

        }


        /// <summary>-
        /// GetAppointmentsbyDate return apppointment list
        /// </summary>
        /// <param name="aptdate">default current date, ?aptdate=mm/dd/yyyy</param>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// 
        /// <returns></returns>
        // GET api/appointments/1.json?aptdate={date}
        [HttpPost]
        [VersionedRoute("{version}", "v1.0")]
        [VersionedRoute("{version}/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCAppointmentsActionFilter]
        [HCETagFilter("aptDate")]

        public async Task<HttpResponseMessage> GetAppointments(RequestParameters requestParam)

        {
            int userid = 0;
            try
            {
                ValidateRequest();
                ValidateProviderId(requestParam.providerid);
                
              
                if (requestParam.aptdate == null)
                    requestParam.aptdate = DateTime.Today;
                DateTime dt = requestParam.aptdate.Value;
                var apts = await _AppointmentSvc.getAppointments(requestParam.providerid, userid, dt);           

                if (apts != null)
                {
                    
                    ResponseData resp = new WebAPI.ResponseData(apts);
                    var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                    response.Headers.Add("aptDate", requestParam.aptdate.ToString());
                    return response;
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }


            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);

        }


        /// <summary>
        /// GetAppointmentsbyDate return apppointment list 
        /// </summary>
        /// <param name="aptdate">default current date, ?aptdate=mm/dd/yyyy</param>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        // GET api/appointments/2.json?aptdate={date}
        [HttpPost]
        [VersionedRoute("{version}", "v2.0")]
        [VersionedRoute("{version}/index.{type}", "v2.0")]
        [ApiExceptionFilter]
        [HCAppointmentsActionFilter]
        [HCETagFilter("aptDate")]
        //public async Task<IHttpActionResult> GetAppointmentsv2(int providerid, DateTime? aptdate = null, int userid = 0)
        //{

        //    //logger.Error("This will appear in red in the console and still be written to file!");
        //    try
        //    {

        //        if (aptdate == null) aptdate = DateTime.Today;
        //        DateTime dt = aptdate.Value;

        //        var apts = await _AppointmentSvc.getAppointmentsV2(providerid, userid, dt);


        //        if (apts != null)
        //            return Ok(apts);
        //    }
        //    catch (Exception exp)
        //    {
        //        _logger.Error("Error :", exp);
        //        //throw new DataException(exp.Message, exp);
        //        throw new ItemNotFoundException();
        //    }

        //    throw new ItemNotFoundException();

        //}
        public async Task<HttpResponseMessage> GetAppointmentsv2(RequestParameters requestParam)

        {
            int userid = 0;
            try
            {
                ValidateRequest();
                ValidateProviderId(requestParam.providerid);


                if (requestParam.aptdate == null)
                    requestParam.aptdate = DateTime.Today;
                DateTime dt = requestParam.aptdate.Value;
                var apts = await _AppointmentSvc.getAppointmentsV2(requestParam.providerid, userid, dt);

                if (apts != null)
                {
                   
                    ResponseData resp = new WebAPI.ResponseData(apts);
                    var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                    response.Headers.Add("aptDate", requestParam.aptdate.ToString());
                    return response;
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }


            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);

        }

        /// <summary>
        /// Get appointment details by appointmentid 
        /// </summary>
        /// <param name="appointmentid"></param>
        /// <param name="providerid"></param>
        /// <returns></returns>

        [HttpPost]
        [VersionedRoute("{appointmentid}/{version}/index.{type}", "v1.0")]
        [VersionedRoute("{appointmentid}/{version}", "v1.0")]
        [ApiExceptionFilter]
        [HCAppointmentsActionFilter]
        [HCETagFilter]
        public async Task<HttpResponseMessage> GetAppointmentDetails(RequestParameters requestParam, int appointmentid)
        {
            int userid = 0;

            try
            {
                ValidateRequest();
                ValidateProviderId(requestParam.providerid);
                
                var apts = await _AppointmentSvc.getAppointmentById(requestParam.providerid, userid, appointmentid);
                if (apts != null)
                {
                     

                    ResponseData resp = new WebAPI.ResponseData(apts);
                    var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                    return response;
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }
            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);

        }

        [HttpPost]
        [VersionedRoute("{appointmentid}/{version}/index.{type}", "v2.0")]
        [VersionedRoute("{appointmentid}/{version}", "v2.0")]
        [ApiExceptionFilter]
        [HCAppointmentsActionFilter]
        [HCETagFilter]
        public async Task<HttpResponseMessage> GetAppointmentDetailsv2(RequestParameters requestParam, int appointmentid)
        {
            int userid = 0;

            try
            {
                ValidateRequest();
                ValidateProviderId(requestParam.providerid);

                var apts = await _AppointmentSvc.getAppointmentByIdV2(requestParam.providerid, userid, appointmentid);
                if (apts != null)
                {
                     

                    ResponseData resp = new WebAPI.ResponseData(apts);
                    var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                    return response;
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }
            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);

        }


        /// <summary>
        ///  call this method to perform action on appointment
        ///  Action{int:appointmentId:, bool:triggerIVR) 
        ///  ivr call will be triggered only if appointment status is scheduled for todays date
        /// </summary>
        /// <param name="appointmentid"></param>
        /// <param name="providerid"></param>
        /// <param name="action"></param>
        /// <returns></returns>
        [HttpPut]
        [VersionedRoute("{version}/{appointmentid}.{type}", "v1.0")]
        [VersionedRoute("{version}/{appointmentid}", "v1.0")]
        [ApiExceptionFilter]
        [CheckModelForNull]
        [ValidateModel]

        async Task<IHttpActionResult> updateAppointment(int appointmentid, [FromBody] AppointmentActionRequest action, int providerid = 0)
        {
            int userid = 0;
            int status = 1;

            try
            {
                if (action.triggerIVR == false)
                    throw new InvalidOperationException("Invalid Request. No Action requested!");

                status = await _AppointmentSvc.UpdateAppointmentAction(providerid, appointmentid, userid, action);

                if (status == 1)
                    return StatusCode(HttpStatusCode.Accepted);

                throw new ItemNotFoundException();
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                //throw new DataException(exp.Message, exp);
                throw new ItemNotFoundException();
            }
        }



        /// <summary>
        /// returns appointment calenderview for the given year & month
        /// </summary>
        /// <param name="type"></param>
        /// <param name="version"></param>
        /// <param name="providerid"></param>
        /// <param name="month">mm</param>
        /// <param name="year">yyyy</param>
        /// <returns></returns>
        [System.Web.Http.HttpPost]
        [VersionedRoute("views/{version}/index.{type}", "v1.0")]
        [VersionedRoute("views/{version}", "v1.0")]
        [ApiExceptionFilter]
        [HCAppointmentsActionFilter]
        [HCETagFilter]
        public async Task<HttpResponseMessage> getappointmentsview(RequestParameters requestParam)
        {
            int userid = 0;
            try
            {
                ValidateRequest();
                ValidateProviderId(requestParam.providerid);
                var apview = await _AppointmentSvc.getAppointmentCount(requestParam.providerid, userid, requestParam.year, requestParam.month);

                if (apview != null)
                {
                    var response = Request.CreateResponse(HttpStatusCode.OK, apview);
                    return response;
                }


            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }

            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
        }

        /// <summary>
        /// placeautocall
        /// </summary>
        /// <param name="requestParam"></param>
        /// <returns></returns>

        [System.Web.Http.HttpPost]
        [VersionedRoute("autocall/{version}/index.{type}", "v1.0")]
        [VersionedRoute("autocall/{version}", "v1.0")]
        [ApiExceptionFilter]
        [HCAppointmentsActionFilter]
        [HCETagFilter]
        public async Task<HttpResponseMessage> placeautocall(RequestParameters requestParam)
        {

            try
            {
                ValidateRequest();
                ValidateProviderId(requestParam.providerid);

                //bool autocallstatus = _AppointmentSvc.GetAutoCallFileStatus(requestParam.providerid);
                ////if (!autocallstatus)
                //{
                //    await Task.Run(() =>
                //    {
                //        AutoCallFile(requestParam.providerid);
                //    });

                //}
                await Task.Run(() =>
                {
                    _AppointmentSvc.InsertAutoCall(requestParam.providerid, requestParam.appointmentid, true);
                });

                var response = Request.CreateResponse(HttpStatusCode.OK, "[{\"Status\": \"Success\"}]");
                return response;

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }

            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
        }

        /// <summary>
        /// AutoCallFile
        /// </summary>
        /// <param name="providerID"></param>
        private void AutoCallFile(int providerID)
        {
            try
            {

                string Prod_File_Path = ConfigurationManager.AppSettings["AutoCallFilePath"].ToString();
                string providername = GetProviderName();
                string fileName = Prod_File_Path + providerID + ".wav";
                if (System.IO.File.Exists(fileName))
                {
                    _logger.Info("Media file :"+ fileName + " already exists");
                    return;
                }
                string TeamCare_Number = ConfigurationManager.AppSettings["TeamCareNumber"].ToString();
                string AutoCall_Script1 = ConfigurationManager.AppSettings["AutoCall_Script1"].ToString();
                string AutoCall_Script2 = ConfigurationManager.AppSettings["AutoCall_Script2"].ToString();

                //SpeechSynthesizer synthesizer = new SpeechSynthesizer();

                //synthesizer.SelectVoiceByHints(VoiceGender.Male);

                //var builder = new PromptBuilder();
                //builder.AppendBreak(TimeSpan.FromMilliseconds(1500));
                //builder.AppendText(AutoCall_Script1);
                //builder.AppendBreak(TimeSpan.FromMilliseconds(300));
                //builder.AppendText(providername);
                //builder.AppendBreak(TimeSpan.FromMilliseconds(300));
                //builder.AppendText(AutoCall_Script2);
                //builder.AppendBreak(TimeSpan.FromMilliseconds(1500));
                //builder.AppendText(AutoCall_Script1);
                //builder.AppendBreak(TimeSpan.FromMilliseconds(300));
                //builder.AppendText(providername);
                //builder.AppendBreak(TimeSpan.FromMilliseconds(300));
                //builder.AppendText(AutoCall_Script2);

                //Adding audio format - CCITT µ-law 8bit 8khz mono
                //SpeechAudioFormatInfo audioFormat = new
                // SpeechAudioFormatInfo(EncodingFormat.ULaw, 8000, 8, 1, 8000, 1, null);

                //slowing down the speech rate for better clarity
                //synthesizer.Rate = -2;

                //synthesizer.SetOutputToWaveFile(fileName, audioFormat);

                //synthesizer.Speak(new Prompt(builder));
                //synthesizer.Dispose();
                //_logger.Info("Media file :" + fileName + " is created");

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }
        }

    }

}
