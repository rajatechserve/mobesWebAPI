﻿using WebAPI.Providers;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using static WebAPI.Helpers.Errors;

namespace WebAPI.Controllers
{

    public class BaseController : ApiController
    {

        private Int32 UserId
        {
            get
            {
                //return Convert.ToInt32(Request.Properties["userid"]);
                return Convert.ToInt32(Request.Headers.GetValues("userid").FirstOrDefault());

            }
        }
        private Int32 ProviderId
        {
            get
            {
                //return Convert.ToInt32(Request.Properties["providerid"]);
                return Convert.ToInt32(Request.Headers.GetValues("providerid").FirstOrDefault());

            }
        }

        private string ProviderName
        {
            get
            {
                return Request.Headers.GetValues("providername").FirstOrDefault().ToString();
            }
        }
        public Int32 GetUserId()
        {
            return this.UserId;
        }

        public Int32 GetProviderId()
        {
            return this.ProviderId;
        }

        public string GetProviderName()
        {
            return this.ProviderName;
        }
        public void ValidateProviderId(Int32 providerId)  //
        {
            if (this.ProviderId != providerId)//compare request provider id and the providerid in header fetched from token are same then its valid otherwise throw exc.
                throw new UnAuthorizedProviderIdException(ErrorCodes.UnAuthorizedProviderId);
        }
        public void ValidateRequest()
        {
            if (Request.Properties.ContainsKey("Validation"))
            {
                object ex = Request.Properties.Where(x => x.Key == "Validation").FirstOrDefault().Value;

                throw (Exception)ex;
            }
        }
    }

}
