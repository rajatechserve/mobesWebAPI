﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.IdentityModel.Tokens;
using System.Net;
using System.Web.Http;
using WebAPI.Providers;
using WebAPI.Models;
using System.Web.Script.Serialization;
using log4net;

using HCProviderServices;
using WebAPI.Helpers;
using static WebAPI.Helpers.Errors;
using System.IdentityModel.Tokens.Jwt;

namespace WebAPI.Controllers
{
    public class LoginController : BaseController
    {
        IUserService _userSvc;
        IConfigService _configSvc;
        ILog _logger;
        

        public LoginController(IUserService usersvc, IConfigService configsvc, ILog logger)
        {

            _userSvc = usersvc;
            _configSvc = configsvc;
            _logger = logger;
            

        }
        [HttpGet]
        [ApiExceptionFilter]
        [Route("Login")]
        public HttpResponseMessage Get()
        {
            try
            {
                IEnumerable<string> headerValues;
                var IsFound = Request.Headers.TryGetValues("jwt", out headerValues);
                if (IsFound && !string.IsNullOrEmpty(headerValues.FirstOrDefault().ToString()))
                {
                    var decodedToken = new JwtSecurityToken(headerValues.FirstOrDefault()).Claims;

                    var context = decodedToken.First(c => c.Type == "context");
                    //var decodedToken = JWT.Decode(headerValues.FirstOrDefault(), Encoding.ASCII.GetBytes(ConfigurationManager.AppSettings["SecretKey"]), JwsAlgorithm.HS256);
                    DecodedToken tokenDecoded = new DecodedToken();
                    tokenDecoded.context = (Context)new JavaScriptSerializer().Deserialize(context.Value, typeof(Context));
                    if (tokenDecoded != null)
                    {
                         
                        //var date = DateTimeOffset.FromUnixTimeSeconds(tokenDecoded.exp); //
                        var tokenExpiryTime = UNIXHelper.FromUnixTimeSeconds(Convert.ToInt64(decodedToken.First(c => c.Type == "exp").Value));

                        var diff = MemoryCacher.GetValue("servertimezonediff");

                        if (diff == null)
                        {
                            diff = _configSvc.GetServerTimeZoneDiff();
                            MemoryCacher.Add("servertimezonediff", diff, DateTimeOffset.Now.AddDays(1));
                        }

                        if (DateTime.Now > (tokenExpiryTime.AddMinutes(Convert.ToInt32(diff))))
                        {
                            throw new TokenExpiredException(ErrorCodes.TokenExpired);
                        }
                         
                        var UserProfile = _userSvc.getUserByOptumId(tokenDecoded.context.user.name);
                        if (UserProfile != null)
                        {
                            Request.Headers.Add("userid", Convert.ToString(UserProfile.userid));
                            Request.Headers.Add("providerid", Convert.ToString(UserProfile.providerid));
                            Request.Headers.Add("providername", UserProfile.ProviderName);
                            MemoryCacher.Add(tokenDecoded.context.user.name, UserProfile, DateTimeOffset.Now.AddHours(2));
                        }
                        if (!string.IsNullOrEmpty(UserProfile.ErrorCode))
                        {
                            if (UserProfile.ErrorCode == ErrorCodes.UserNotFound)
                                throw new UserNotFountException(ErrorCodes.UserNotFound);
                            else if (UserProfile.ErrorCode == ErrorCodes.InactiveUser)
                                throw new InactiveUserException(ErrorCodes.InactiveUser);
                            else if (UserProfile.ErrorCode == ErrorCodes.MultipleUsers)
                                throw new MultipleUsersException(ErrorCodes.MultipleUsers);
                        }

                       
                        return Request.CreateResponse(HttpStatusCode.OK, UserProfile);
                    }
                    else
                    {
                        throw new InvalidTokenException(ErrorCodes.InvalidToken);
                    }
                }
                else
                {
                    throw new TokenMissingException(ErrorCodes.TokenMissing);
                }
            }
            catch (Exception exp)
            {
                if (exp.Message.Split(':').FirstOrDefault().ToString() == "Invalid JSON primitive"
                    || exp.Message.Split(':').ToList().Contains(" Unable to decode the 'header'")
                    || exp.Message == ErrorCodes.InvalidToken)
                {
                    
                    throw new InvalidTokenException(ErrorCodes.InvalidToken);
                }
                else
                    
                throw exp;
            }
        }
    }
}
