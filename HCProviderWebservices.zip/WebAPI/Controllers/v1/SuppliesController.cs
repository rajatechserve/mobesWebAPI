﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Http;
using System.Web.Http;
using System.Net;
using WebAPI.Providers;
using WebAPI.Filters;
using HCProviderServices;
using System.Threading.Tasks;
using System.Data;
using log4net;
using WebAPI.Models;
using static WebAPI.Helpers.Errors;

namespace WebAPI.Controllers
{

    /// <summary>
    /// supplies controller  version -1 (v1)
    /// </summary>
    [RoutePrefix("providers/supplies")]
    [AuthorizeCustom]
    public class suppliesController : BaseController
    {
        ILog _logger;

        ISuppliesServices _supplyServices;
        /// <summary>
        /// Dependency injection
        /// </summary>
        /// <param name="isv"></param>
        public suppliesController(ISuppliesServices isv, ILog logger)
        {
            _supplyServices = isv;
            _logger = logger;
        }


        /// <summary>
        /// Get Provider Supplies for a given providerid, date
        /// return DailySupply 
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="aptdate">?aptdate=mm/dd/yyyy</param>
        /// <returns></returns>
        [HttpPost]
        [VersionedRoute("{version}", "v1.0")]
        [VersionedRoute("{version}/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCSuppliesActionFilter]
        [HCETagFilter]
        public async Task<HttpResponseMessage> GetProviderSupply(RequestParameters requestParam)
        {
            int userid = 1;

            try
            {
                ValidateRequest();
                ValidateProviderId(requestParam.providerid);
                
                DateTime vday = DateTime.Now;

                if (requestParam.aptdate != null)
                {
                    vday = requestParam.aptdate.Value;
                }

                var res = await _supplyServices.GetSupply(requestParam.providerid, userid, vday);

                if (res != null)
                {
                    var response = Request.CreateResponse(HttpStatusCode.OK, res);
                    return response;
                }
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }
            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);

        }

    }
}