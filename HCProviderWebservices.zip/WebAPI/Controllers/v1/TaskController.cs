﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using HCProviderServices;
using HCProviderServices.DTOModels;
using WebAPI.Providers;
using WebAPI.Filters;
using System.Threading.Tasks;
using System.Data;
using log4net;
using HCProviderServices.ServiceProtocols;
using WebAPI.Models;
using System.Web.Http.ModelBinding;
using System.Linq;
using System.Collections.Generic;
using static WebAPI.Helpers.Errors;
using System.Web.Configuration;
//using System.Web.Script.Serialization;
using System.Collections;

namespace WebAPI.Controllers

{
    /// <summary>
    /// Task Controller V1
    /// </summary>
    [RoutePrefix("tasks")]
    [AuthorizeCustom]
    public class TaskController : BaseController
    {

        ITaskServices _taskSvc;
        ILog _logger;

        public TaskController(ITaskServices tasksvc, ILog logger)
        {
            _taskSvc = tasksvc;
            _logger = logger;
        }

        /// <summary>
        /// Add Task
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="aptdate"></param>
        /// <returns></returns>

        [HttpPost]
        [VersionedRoute("{version}", "v1.0")]
        [VersionedRoute("{version}/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCTaskValidationFilter]
        [HCETagFilter]
        public async Task<HttpResponseMessage> AddTask([FromBody]InputTask task)
        {
            if (Request.Properties.ContainsKey("Validation"))
            {
                object ex = Request.Properties.Where(x => x.Key == "Validation").FirstOrDefault().Value;
                throw (Exception)ex;
            }
            else
            {
                try
                {

                    int userId = GetUserId();
                    var taskId = await _taskSvc.AddTask(task.TaskName, task.TaskDescription, userId, task.DueDate);
                    return Request.CreateResponse(HttpStatusCode.Created, taskId);
                }
                catch (Exception exp)
                {
                    _logger.Error("Error :", exp);
                    throw new DataException(exp.Message, exp);

                }
            }
        }

        /// <summary>
        /// Get Tasks
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="taskid"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="status"></param>
        /// <param name="pagesize"></param>
        /// <param name="pagenumber"></param>
        /// <returns>TaskList</returns>

        [HttpGet]
        [VersionedRoute("{version}", "v1.0")]
        [VersionedRoute("{version}/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCTaskValidationFilter]
        [HCETagFilter]
        public async Task<HttpResponseMessage> GetTasks(string status = "active", int taskid = 0, int pagesize = 10, int pagenumber = 1, DateTime? fromDate = null, DateTime? toDate = null)
        {



            try
            {
                ValidateRequest();
                int userid = GetUserId();

                var tasks = await _taskSvc.GetTaskList(userid, taskid, fromDate, toDate, pagesize, pagenumber, status);
                if (tasks != null)
                {
                    v1Taskdto result = tasks.ToList().FirstOrDefault();
                    ResponseData resp = new WebAPI.ResponseData(result.Task, result.RecordCount, result.PageCount);
                    var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                    return response;
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;

            }
            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);

        }

        [HttpGet]
        [VersionedRoute("new/{version}", "v1.0")]
        [VersionedRoute("new/{version}/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCTaskValidationFilter]
        [HCETagFilter]
        public async Task<HttpResponseMessage> GetNewTasks(int pagesize=10, int pagenumber=1)
        {
            try
            {
                ValidateRequest();
                int userid = GetUserId();

                var tasks = await _taskSvc.GetNewTaskList(userid, 0,DateTime.Now, null, pagesize, pagenumber, "active");
                if (tasks != null)
                {
                    v1Taskdto result = tasks.ToList().FirstOrDefault();
                    ResponseData resp = new WebAPI.ResponseData(result.Task, result.RecordCount, result.PageCount);
                    var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                    return response;
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;

            }
            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);

        }


        [HttpGet]
        [VersionedRoute("overdue/{version}", "v1.0")]
        [VersionedRoute("overdue/{version}/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCTaskValidationFilter]
        [HCETagFilter]
        public async Task<HttpResponseMessage> GetOverdueTasks(int pagesize = 10, int pagenumber = 1)
        {



            try
            {
                ValidateRequest();
                int userid = GetUserId();

                var tasks = await _taskSvc.GetTaskList(userid, 0, null, DateTime.Now.AddDays(-1), pagesize, pagenumber, "active");
                if (tasks != null)
                {
                    v1Taskdto result = tasks.ToList().FirstOrDefault();
                    ResponseData resp = new WebAPI.ResponseData(result.Task, result.RecordCount, result.PageCount);
                    var response = Request.CreateResponse(HttpStatusCode.OK, resp);
                    return response;
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;

            }
            throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);

        }

        /// <summary>
        /// Get TasksDetails
        /// </summary>
        /// <param name="taskid"></param>
        /// <returns>TaskList</returns>
        [HttpGet]
        [VersionedRoute("{version}/{taskid}", "v1.0")]
        [VersionedRoute("{version}/{taskid}/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCTaskValidationFilter]
        [HCETagFilter]
        public async Task<HttpResponseMessage> GetTasksDetails(int taskid = 0)
        {

            try
            {
                ValidateRequest();
                int userid = GetUserId();

                var tasks = await _taskSvc.GetTaskList(userid, taskid, null, null, null, null, null);
                if (tasks != null)
                {
                    var response = Request.CreateResponse(HttpStatusCode.OK, tasks);
                    return response;
                }
                else
                {
                    throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
                }
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;

            }


        }
        /// <summary>
        /// Update Task
        /// </summary>
        /// <param name="providerid"></param>
        /// <param name="userid"></param>
        /// <param name="aptdate"></param>
        /// <returns></returns>

        [HttpPut]
        [VersionedRoute("{id}/{version}", "v1.0")]
        [VersionedRoute("{id}/{version}/index.{type}", "v1.0")]
        [ApiExceptionFilter]
        [HCTaskValidationFilter]
        public async Task<HttpResponseMessage> UpdateTask(int id, [FromBody] UpdateTask task)
        {

            try
            {
                ValidateRequest();
                int userId = GetUserId();

                UrlFormat urlroute = new UrlFormat();
                urlroute.UrlName = "link";
                if (this.Url.Request.RequestUri != null)
                    urlroute.UrlRoute = this.Url.Request.RequestUri.LocalPath.ToString();
                int result = await _taskSvc.UpdateTask(id, task.TaskName, task.TaskDescription, task.TaskStatus, userId, task.DueDate);
                var urlroutecollection = new[] { urlroute };
                ResponseData resp = new WebAPI.ResponseData(urlroutecollection);
                if (result == 0)
                    return Request.CreateResponse(HttpStatusCode.Accepted, resp);
                else
                    return Request.CreateResponse(HttpStatusCode.NotAcceptable, resp);
            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;

            }

        }

        /// <summary>
        /// returns task calenderview for the given year & month
        /// </summary>
        /// <param name="type"></param>
        /// <param name="version"></param>
        /// <param name="month">mm</param>
        /// <param name="year">yyyy</param>
        /// <returns> getTaskview</returns>
        [System.Web.Http.HttpGet]
        [VersionedRoute("views/{version}/index.{type}", "v1.0")]
        [VersionedRoute("views/{version}", "v1.0")]
        [ApiExceptionFilter]
        [HCTaskValidationFilter]
        [HCETagFilter]
        public async Task<HttpResponseMessage> getTaskview(int month = 0, int year = 0)
        {
            int userid = 0;



            try
            {
                ValidateRequest();
                userid = GetUserId();
                var apview = await _taskSvc.getTaskCount(year, month, userid);

                if (apview != null)
                {
                    var response = Request.CreateResponse(HttpStatusCode.OK, apview);
                    return response;
                }
                else
                {
                    throw new ItemNotFoundException(ErrorCodes.ItemNotFoundException);
                }

            }
            catch (Exception exp)
            {
                _logger.Error("Error :", exp);
                throw exp;
            }
        }


    }
}