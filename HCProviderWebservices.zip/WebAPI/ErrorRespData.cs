﻿using HCProviderServices.DTOModels;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using WebAPI.Helpers;
using log4net;
using WebAPI.Models;

namespace WebAPI
{
    /// <summary>
    /// response data wrapper for json/xml returns
    /// </summary>
    //[DataContract]
    //[XmlInclude(typeof(v1Appointmentdto))]
    public class ErrorRespData
    {


        private readonly ILog _logger = LogManager.GetLogger(typeof(ErrorRespData));
        /// <summary>
        /// constructor
        /// </summary>
        public ErrorRespData()
        {
        }

        /// <summary>
        /// ErrorRespData
        /// </summary>
        /// <param name="message"></param>
        public ErrorRespData(string code)
        {

            Error = new ErrorMessage();
            Error.Id = Guid.NewGuid().ToString();
            Error.Code = code;
            Error.Message = Errors.GetErrorDefinition(code);
            try
            {
                _logger.Error("Error Id :" + Error.Id + "Error Code :" + Error.Code + ", Error Message: " + Error.Message);
            }
            catch (Exception ex)
            {

            }

        }

        /// <summary>
        /// ErrorMessage
        /// </summary>
        [JsonProperty("Error")]
        public ErrorMessage Error { get; set; }




    }


}
