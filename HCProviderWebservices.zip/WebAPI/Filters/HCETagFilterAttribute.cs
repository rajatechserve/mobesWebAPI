﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Filters;
using System.Web.Routing;
using System.Security.Cryptography;
using WebAPI.Helpers;
using System.ComponentModel;

namespace WebAPI.Filters
{
    /// <summary>
    /// HCE ETag Filters
    /// ETag
    /// </summary>
    public class HCETagFilterAttribute:ActionFilterAttribute
    {

        /// <summary>
        /// HttpResponseHeaderKeyToComputeETag - httpResponseHeaderMessage Key to which value for computing ETag is Added to the controller method
        /// By Default Hash is computed from Http Body content
        /// </summary>
        public string HttpResponseHeaderKeyToComputeETag { get; set; }

        //
        // Summary:
        //     The maximum age, specified in seconds, that the HTTP client is willing to accept
        //     a response.
        //
        // Returns:
        //     Returns System.TimeSpan.The time in seconds.
        public int MaxAgeInMinutes { get; set; }
            
         
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="defaultETag">DefaultETag(False) ETag is computed from http header Value added to the Response</param>   
         /// <param name="httpResponseHeaderKeyToComputeETag">  httpResponseHeaderMessage Key to which value for computing ETag is Added to the controller method
        /// </summary></param>
        public HCETagFilterAttribute  (string httpResponseHeaderKeyToComputeETag = "Default" 
            , int maxAgeInMinutes = 60
            )
        {            
            HttpResponseHeaderKeyToComputeETag = httpResponseHeaderKeyToComputeETag;
            MaxAgeInMinutes = maxAgeInMinutes;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContext"></param>
        public override void OnActionExecuted(HttpActionExecutedContext httpContext)
        {
            string responseETag = string.Empty;
            string requestETag = string.Empty;

            if (httpContext.Response != null)
            {
                if ((httpContext.Response.StatusCode.ToString().Equals("OK")) && (httpContext.Response.Content != null))
                {
                    // ETag should only added for Http Get request
                    //if (httpContext.Request.Method.ToString().Equals("GET"))
                    //{

                        // Get the ETag from request
                        if (httpContext.Request.Headers.Any(u => u.Key == "ETag"))
                        {
                            requestETag = httpContext.Request.Headers.GetValues("ETag").FirstOrDefault();
                            requestETag = requestETag.Replace("\"", "");

                        }

                        //Calculates ETag
                        // For Content Body

                        if (HttpResponseHeaderKeyToComputeETag.Equals("Default"))
                        {
                            Byte[] contentBytes = httpContext.Response.Content.ReadAsByteArrayAsync().Result;

                            responseETag = GenerateHashHelper.ComputeHashMd5(contentBytes);
                        }
                        else
                        {
                            //based on  httpResponseHeaderMessage Key to which value for computing ETag is Added from the controller method
                            if (httpContext.Response.Headers.Any(u => u.Key == HttpResponseHeaderKeyToComputeETag))
                            {
                                string customEtagValue = httpContext.Response.Headers.GetValues(HttpResponseHeaderKeyToComputeETag).FirstOrDefault();
                                responseETag = GenerateHashHelper.ComputeHashMd5(customEtagValue);
                            }
                            else
                            {
                                throw new Exception("httpResponseHeaderKeyToComputeETag - httpresponseheader Key should match with the httpResponseHeaderKeyToComputeETag value");
                            }
                        }

                        //Remove any headers that added for ETag Logic

                        var responseHeaders = httpContext.Response.Headers.AsParallel().ToList();

                        foreach (var item in responseHeaders)
                        {
                            if (!item.Key.Equals("ETag"))
                            {
                                httpContext.Response.Headers.Remove(item.Key);
                            }
                        }

                        // Compare Ressponse and Request ETag

                        if (!string.IsNullOrEmpty(requestETag))
                        {
                            if (requestETag.Equals(responseETag))
                            {
                                httpContext.Response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.NotModified);

                            }
                        }

                        // Set cache Expiry
                        httpContext.Response.Headers.CacheControl = new System.Net.Http.Headers.CacheControlHeaderValue()
                        {
                            Public = true,
                            MaxAge = TimeSpan.FromMinutes(MaxAgeInMinutes)
                        };

                        // Add Etag
                        httpContext.Response.Headers.ETag = new System.Net.Http.Headers.EntityTagHeaderValue("\"" + responseETag + "\"");


                    //}
                    //else
                    //{
                    //    throw new Exception("ETag is only allowed for HTTP GET");
                    //}

                }
            }
            
        }
       
    }
    
}
