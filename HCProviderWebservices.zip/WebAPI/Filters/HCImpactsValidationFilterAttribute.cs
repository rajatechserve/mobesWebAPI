﻿using System;
using System.Web.Http.Filters;
using System.Web.Http.Controllers;
using WebAPI.Providers;
using WebAPI.Models;
using static WebAPI.Helpers.Errors;
using WebAPI.Controllers;

namespace WebAPI.Filters
{
    public class HCImpactsValidationFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {

            string errorCode = string.Empty;
            var descriptor = actionContext.ActionDescriptor as HttpActionDescriptor;

            if (descriptor != null)
            {
                #region validation for GetImpacts

                if (descriptor.ActionName == "GetImpacts")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count == 0)
                        {
                            errorCode = ErrorCodes.RequestParametersNotProvided;
                        }
                        else
                        {
                            RequestParameters param = (Models.RequestParameters)actionContext.ActionArguments["requestParam"];

                            if (param.providerid < 1)
                            {
                                errorCode = ErrorCodes.InvalidMissingProvideridParameter;
                            }
                            
                            if (param.month < 0 || param.month > 12)
                            {
                                errorCode = ErrorCodes.InvalidMissingMonthparameter;
                            }
                            if (param.year < 1)
                            {
                                errorCode = ErrorCodes.InvalidMissingyearparameter;
                            }
                       
                        }

                        if (!string.IsNullOrWhiteSpace(errorCode))
                        {

                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                        }
                    }
                    catch (Exception ex)
                    {
                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingAptdateParameter));
                    }
                }
                #endregion


                #region validation for AddGoal

                if (descriptor.ActionName == "AddGoal")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count == 0)
                        {
                            errorCode = ErrorCodes.RequestParametersNotProvided;
                        }
                        else
                        {
                            RequestParameters param = (Models.RequestParameters)actionContext.ActionArguments["requestParam"];

                            if (param.providerid < 1)
                            {
                                errorCode = ErrorCodes.InvalidMissingProvideridParameter;
                            }
                            
                            if (param.targetedgoal < 1)
                            {
                                errorCode = ErrorCodes.InvalidMissingTargetedGoalparameter;
                            }
                            if (param.year < 1)
                            {
                                errorCode = ErrorCodes.InvalidMissingyearparameter;
                            }
                                               

                        }

                        if (!string.IsNullOrWhiteSpace(errorCode))
                        {

                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                        }
                    }
                    catch (Exception ex)
                    {
                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingAptdateParameter));
                    }
                }
                #endregion
            }
        }
    }
}

  

