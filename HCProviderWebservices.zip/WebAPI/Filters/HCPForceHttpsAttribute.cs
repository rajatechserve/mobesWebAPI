﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Filters;
using System.Net;
using System.Net.Http;

namespace WebAPI.Filters
{
   /// <summary>
   /// force https.
   /// </summary>
        public class ForceHttpsAttribute : AuthorizationFilterAttribute
        {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="actionContext"></param>
            public override void OnAuthorization(System.Web.Http.Controllers.HttpActionContext actionContext)
            {
                var request = actionContext.Request;

                if (request.RequestUri.Scheme != Uri.UriSchemeHttps)
                {
               
                    var html = "<p>Https is required</p>";

                    if (request.Method.Method == "GET")
                    {
                        actionContext.Response = request.CreateResponse(HttpStatusCode.Found);
                        actionContext.Response.Content = new StringContent(html, Encoding.UTF8, "text/html");

                        UriBuilder httpsNewUri = new UriBuilder(request.RequestUri);
                        httpsNewUri.Scheme = Uri.UriSchemeHttps;
                        httpsNewUri.Port = 443;

                        actionContext.Response.Headers.Location = httpsNewUri.Uri;
                    }
                    else
                    {
                        actionContext.Response = request.CreateResponse(HttpStatusCode.NotFound);
                        actionContext.Response.Content = new StringContent(html, Encoding.UTF8, "text/html");
                    }

                }
            }
        }


    
}
