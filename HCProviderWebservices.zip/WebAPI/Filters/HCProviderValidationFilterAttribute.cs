﻿using WebAPI.Providers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using static WebAPI.Helpers.Errors;

namespace WebAPI.Filters
{
    class HCProviderValidationFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            var descriptor = actionContext.ActionDescriptor as HttpActionDescriptor;

            string errorCodes = "";

            if (descriptor != null)
            {
                if (descriptor.ActionName == "GetProviders")
                    try
                    {
                        if (actionContext.ActionArguments.Count != 0)
                        {
                            string loginid = actionContext.ActionArguments["loginid"].ToString();
                            if (String.IsNullOrEmpty(loginid))
                            {
                                errorCodes = ErrorCodes.LoginIDCannotBeEmptOrNull;
                            }

                        }

                        if (!string.IsNullOrWhiteSpace(errorCodes))
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCodes));
                    }
                    catch (Exception exp)
                    {
                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidParameter));
                    }

            }
            base.OnActionExecuting(actionContext);
        }
    }
}
