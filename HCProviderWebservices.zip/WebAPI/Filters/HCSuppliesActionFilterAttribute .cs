﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Filters;

using System.Web.Routing;
using System.Security.Cryptography;
using WebAPI.Helpers;
using System.ComponentModel;
using System.Web.Http.Controllers;
using System.Net;
using System.Net.Http;
using WebAPI.Providers;
using WebAPI.Models;
using static WebAPI.Helpers.Errors;
using WebAPI.Controllers;

namespace WebAPI.Filters
{
    class HCSuppliesActionFilterAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// OnActionExecuting
        /// </summary>
        /// <param name="actionContext"></param>
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            string errorCode = string.Empty;
            var descriptor = actionContext.ActionDescriptor as HttpActionDescriptor;
            if (descriptor != null)
            {               
                  #region validation for GetAppointments List for date
                
                if (descriptor.ActionName == "GetProviderSupply")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count == 0)
                        {
                            //actionContext.Request.Properties.Add("Validation", new InvalidParamerterException("Request Parameters Not Provided!!"));
                            errorCode = ErrorCodes.RequestParametersNotProvided;
                        }
                        else
                        {
                            RequestParameters param = (Models.RequestParameters)actionContext.ActionArguments["requestParam"];

                            if (param.aptdate == null)
                            {
                                // actionContext.Request.Properties.Add("Validation", new InvalidParamerterException("Invalid/Missing aptdate parameter!."));
                                errorCode = ErrorCodes.InvalidMissingAptdateParameter;
                            }

                            if ((param == null)|| (param.providerid < 1))
                            {
                                // actionContext.Request.Properties.Add("Validation", new InvalidParamerterException("Invalid/Missing providerid parameter!."));
                                errorCode = ErrorCodes.InvalidMissingProvideridParameter;
                            }
                            
                            if ((param.aptdate != null) && (param.providerid >= 1))
                            {
                                DateTime aptdate = (DateTime)param.aptdate; ;

                                if ((param.aptdate != null))
                                {
                                    if (!ValidateAppointmentDate(aptdate.Month, aptdate.Year))
                                    {
                                        // actionContext.Request.Properties.Add("Validation", new InvalidParamerterException("month parameter should be two months past (or) one month future !."));
                                        errorCode = ErrorCodes.MonthParameterShouldBeTwoMonthsPastOrOneMonthFuture;
                                    }
                                }
                                else
                                {
                                    // actionContext.Request.Properties.Add("Validation", new InvalidParamerterException("Invalid/Missing aptdate (or) providerid parameter!."));
                                    errorCode = ErrorCodes.InvalidMissingAptdateOrProvideridParameter;
                                }

                            }
                        }

                        if (!string.IsNullOrWhiteSpace(errorCode))
                        {

                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                        }
                    }
                    catch (Exception ex)
                    {
                        // actionContext.Request.Properties.Add("Validation", new InvalidParamerterException("Invalid/Missing aptdate (or) providerid parameter!."));
                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(ErrorCodes.InvalidMissingAptdateOrProvideridParameter));
                    }
                }
                #endregion

              

            }
            base.OnActionExecuting(actionContext);
        }


        #region ValidateAppointmentDate
        /// <summary>
        /// ValidateAppointmentDate
        /// </summary>
        /// <param name="month"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        public bool ValidateAppointmentDate(int month, int year)
        {
            DateTime dtcurrent = new DateTime(year, month, 1);
            DateTime dtstart = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddMonths(-2);
            DateTime dtend = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddMonths(2);
            return (dtcurrent >= dtstart) && (dtcurrent < dtend);
        }
    }
    #endregion
}
