﻿using System.Web.Http.Controllers;
using System.Net;
using System.Net.Http;
using WebAPI.Providers;
using System.Web.Http.Filters;
using WebAPI.Models;
using System;
using static WebAPI.Helpers.Errors;
using HCProviderServices.DTOModels;

namespace WebAPI.Filters
{
    class HCSupportValidationFilterAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// OnActionExecuting
        /// </summary>
        /// <param name="actionContext"></param>
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            var descriptor = actionContext.ActionDescriptor as HttpActionDescriptor;

            string errorCode = "";

            if (descriptor != null)
            {


                #region GetContacts
                if (descriptor.ActionName == "GetContacts")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count != 0)
                        {

                            string status = Convert.ToString(actionContext.ActionArguments["contacttype"]);
                            if (actionContext.ActionArguments["contacttype"] == null)
                            {
                                errorCode = ErrorCodes.SupportInvalidMissingAptdateParameterContactType;

                            }
                            else if (!String.IsNullOrEmpty(status))
                            {
                                if ((status != "all") && (status != "technical") && (status != "clinical") && (status != "others") && (status != "memberservice"))
                                    errorCode = ErrorCodes.SupportInvalidMissingAptdateParameterContactType;
                            }
                        }

                        if (!string.IsNullOrWhiteSpace(errorCode))
                        {
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                        }
                    }
                    catch (Exception exp)
                    {

                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(exp.Message));
                    }
                }
                #endregion

                #region AddContact
                if (descriptor.ActionName == "AddContact")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count != 0)
                        {
                            v1SupportContactdto addcontact = (v1SupportContactdto)actionContext.ActionArguments["contact"];
                            if (String.IsNullOrEmpty(addcontact.ContactName) || String.IsNullOrEmpty(addcontact.ContactPhone) || String.IsNullOrEmpty(addcontact.ContactType))
                            {
                                errorCode = ErrorCodes.ContactNamePhoneTypeNullParameter;
                            }
                           else if ((addcontact.ContactType != "technical") && (addcontact.ContactType != "clinical") && (addcontact.ContactType != "memberservice") && (addcontact.ContactType != "others"))
                            {
                                errorCode = ErrorCodes.InvalidContactTypeParameter;
                            }
                           

                        }

                        if (!string.IsNullOrWhiteSpace(errorCode))
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                    }
                    catch (Exception exp)
                    {
                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(exp.Message));
                    }
                }
                #endregion

                #region UpdateContact
                if (descriptor.ActionName == "UpdateContact")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count != 0)
                        {
                            v1SupportContactdto UpdateContact = (v1SupportContactdto)actionContext.ActionArguments["updateContact"];
                            if (UpdateContact.id == 0)
                            {
                                errorCode = ErrorCodes.InvalidMissingContactIdParameter;
                            }
                            else if ( String.IsNullOrEmpty(UpdateContact.ContactName) || String.IsNullOrEmpty(UpdateContact.ContactPhone) || String.IsNullOrEmpty(UpdateContact.ContactType))
                            {
                                errorCode = ErrorCodes.ContactNamePhoneTypeNullParameter;
                            }
                            else if ((UpdateContact.ContactType != "technical") && (UpdateContact.ContactType != "clinical") && (UpdateContact.ContactType != "memberservice") && (UpdateContact.ContactType != "others"))
                            {
                                errorCode = ErrorCodes.InvalidContactTypeParameter;
                            }


                        }

                        if (!string.IsNullOrWhiteSpace(errorCode))
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                    }
                    catch (Exception exp)
                    {
                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(exp.Message));
                    }
                }
                #endregion

                #region DeleteContact
                if (descriptor.ActionName == "DeleteContact")
                {
                    try
                    {
                        if (actionContext.ActionArguments.Count != 0)
                        {
                            int contactd = (int)actionContext.ActionArguments["id"];
                            if (contactd == 0)
                            {
                                errorCode = ErrorCodes.InvalidMissingContactIdParameter;
                            }
                                                    }

                        if (!string.IsNullOrWhiteSpace(errorCode))
                            actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(errorCode));
                    }
                    catch (Exception exp)
                    {
                        actionContext.Request.Properties.Add("Validation", new InvalidParamerterException(exp.Message));
                    }
                }
                #endregion

            }
            base.OnActionExecuting(actionContext);
        }
    }

        
}

           

