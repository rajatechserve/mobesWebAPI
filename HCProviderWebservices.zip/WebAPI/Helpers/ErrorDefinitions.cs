﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPI.Helpers
{
    public static class Errors
    {
        public struct ErrorCodes
        {

            //"110","NotImplementedException"
            public const string NotImplementedException = "100.1";
            //"111","ItemNotFoundException"
            public const string ItemNotFoundException = "100.2";
            //"112","Unexpected Error. Retry!"
            public const string UnexpectedError = "100.3";
            //"115","Invalid Resource Version!"
            public const string InvalidResourceVersion = "100.4";
            //"116","Invalid Resource Type. Json/XML are valid!"
            public const string InvalidResourceType = "100.5";

            public const string UrlDisabled = "100.6";


            public const string UnAuthorizedProviderId = "110.0";
            public const string UnAuthorized = "110.1";
            public const string InvalidToken = "110.2";
            public const string MultipleUsers = "110.3";
            public const string UserNotFound = "110.4";
            public const string TokenExpired = "110.5";
            public const string TokenMissing = "110.6";
            public const string InactiveUser = "110.7";

            //"130","Request Parameters Not Provided!!"
            public const string RequestParametersNotProvided = "130";

            //----111 - input schema issues- POST/PUT methods

            #region POST/PUT
            #region Alert Put/Post
            //"111.0","Invalid/Missing Request body parameter!."
            public const string InvalidMissingRequestBodyPparameter = "111.0";
            //"111.1","Alert: Invalid Alert Type."
            public const string InvalidAlertType = "111.1";
            //"111.2","Alert: Invalid Recipient Type."
            public const string InvalidRecipientType = "111.2";
            //"111.3", "Alert: Please enter the alert message."
            public const string InvalidMessage = "111.3";
            //"111.4", "Alert: Invalid Targeted User."
            public const string InvalidTargetedUser = "111.4";
            //"111.5", "Alert: Invalid Source."
            public const string InvalidSource = "111.5";
            //"111.6", "Alert: Invalid Expires Date."
            public const string InvalidExpiresOn = "111.6";
            //"111.7", "Alert: Invalid/Missing Alert id parameter!."
            public const string InvalidMissingAlertIdParameter = "111.7";
            //"111.8", "Alert: Invalid/Missing action parameter!."
            public const string InvalidMissingActionParameter = "111.8";
            #endregion

            #endregion
            //----120- Missing/Invalid parameter - GET/POST

            #region GET/POST
            //"120","Invalid/Missing parameter!."
            public const string InvalidMissingParameter = "120";
            //"120.0","Missing paramater!"
            public const string Missingparamater = "120.0";
            //"120.1","Invalid Parameter!"
            public const string InvalidParameter = "120.1";

            #region Appoinment
            //"120.2","Invalid/Missing aptdate parameter!."
            public const string InvalidMissingAptdateParameter = "120.2";
            //"120.3", "Invalid/Missing providerid parameter!."
            public const string InvalidMissingProvideridParameter = "120.3";
            //"120.4", "Month parameter should be two months past (or) one month future !."
            public const string MonthParameterShouldBeTwoMonthsPastOrOneMonthFuture = "120.4";
            //"120.5", "Invalid/Missing aptdate (or) providerid parameter!."
            public const string InvalidMissingAptdateOrProvideridParameter = "120.5";
            //"120.6","Invalid/Missing appointmentid parameter!."
            public const string InvalidMissingAppointmentidParameter = "120.6";
            //"120.7","Invalid/Missing month parameter!."
            public const string InvalidMissingMonthparameter = "120.7";
            //"120.8","Invalid/Missing year parameter!."
            public const string InvalidMissingyearparameter = "120.8";
            //"120.9","Invalid/Missing month (or) year parameter!."
            public const string InvalidMissingMonthOrYearParameter = "120.9";
            //"120.10","Invalid/Missing From Date parameter!."
            public const string InvalidMissingFromDateParameter = "120.10";
            //"120.11","Invalid/Missing To Date parameter!."
            public const string InvalidMissingToDateParameter = "120.11";
            //"120.12","Invalid/Missing Status parameter!."
            public const string InvalidMissingStatusParameter = "120.12";
            //"120.13","Invalid/Missing Alert Type parameter!."
            public const string InvalidMissingAlertTypeParameter = "120.13";
            //"120.14","Invalid/Missing Page Size parameter!."
            public const string InvalidMissingPageSizeParameter = "120.14";
            //"120.15","Invalid/Missing Page Number parameter!."
            public const string InvalidMissingPageNumberParameter = "120.15";
            //"120.16","Invalid From Date parameter!"
            public const string InvalidFromDateParameter = "120.16";
            //"120.17","Invalid From Date parameter!"
            public const string InvalidToDateParameter = "120.17";
            //"120.18","From Date cannot be greater than toDate."
            public const string FromDateCannotBeGreaterThanToDate = "120.18";
            //"120.19","Maximum date range difference can be 5 days only."
            public const string MaximumDateRangeDifferenceCanBe5DaysOnly = "120.19";
            //"120.20","Invalid status parameter!."
            public const string InvalidStatusParameter = "120.20";
            //"120.21","Invalid Alert Type parameter!."
            public const string InvalidAlertTypeParameter = "120.21";
            //"120.22","Login ID Cannot Be Empty or Null."
            public const string LoginIDCannotBeEmptOrNull = "120.22";
            #endregion

            #region Impact Error Codes
            //"120.7","Invalid/Missing month parameter!."
            public const string InvalidMissingTargetedGoalparameter = "120.23";
            #endregion

            #region  TaskErrorCode
            public const string TaskNameTaskDescriptionNullParameter = "120.24";
            public const string TaskDueDateNullParameter = "120.25";
            public const string TaskDueDateNotTodayParameter = "120.26";
            public const string TaskIdNonZeroParameter = "120.27";
            public const string InvalidMissingTaskIdParameter = "120.28";
            public const string MaxDateRangeParameter = "120.29";
            public const string TaskMonthParameterShouldBeTwoMonthsPastOrOneMonthFuture = "120.30";
            #endregion


            #region Alert
            #endregion 


            #region  SupportContactErrorCode
            public const string SupportInvalidMissingAptdateParameterContactType = "120.31";
            #endregion

            #region Contact

            public const string ContactNamePhoneTypeNullParameter = "120.32";
            public const string InvalidContactTypeParameter = "120.33";
            public const string InvalidMissingContactIdParameter = "120.34";
            public const string ContactNotSaved = "120.35";


            #endregion
            #endregion
        }

        private static Dictionary<string, string> ErrorsDictonary = new Dictionary<string, string>()
        {
            {ErrorCodes.NotImplementedException,"Not Implemented Exception." },
            {ErrorCodes.ItemNotFoundException,"Item Not Found Exception." },
            {ErrorCodes.UnexpectedError,"Unexpected Error. Retry!" },
            {ErrorCodes.InvalidResourceVersion,"Invalid Resource Version!" },
            {ErrorCodes.InvalidResourceType,"Invalid Resource Type. Json/XML are valid!" },
             {ErrorCodes.UrlDisabled,"Url Currently Disabled!" },



            {ErrorCodes.UnAuthorized,"Authentication Failure! invalid token or userid/pwd!." },
            {ErrorCodes.UnAuthorizedProviderId,"Authentication Failure! Provider is not matched!." },  
            {ErrorCodes.InvalidToken,"Invalid Token!." },
            {ErrorCodes.MultipleUsers,"Multiple Users Found!." },
            {ErrorCodes.UserNotFound,"User Not Found!." },
            {ErrorCodes.TokenExpired,"Token has expired!." },
            {ErrorCodes.TokenMissing, "Token Missing!."},
            {ErrorCodes.InactiveUser,"User is Inactive!." },


            {ErrorCodes.InvalidMissingParameter,"Invalid/Missing parameter!." },
            {ErrorCodes.Missingparamater,"Missing paramater!" },
            {ErrorCodes.InvalidParameter,"Invalid Parameter!"},
            {ErrorCodes.InvalidMissingAptdateParameter,"Appointments: Invalid/Missing aptdate parameter!."  },
            {ErrorCodes.InvalidMissingProvideridParameter,"Invalid/Missing providerid parameter!."  },
            {ErrorCodes.MonthParameterShouldBeTwoMonthsPastOrOneMonthFuture,"Appointments: Month parameter should be two months past (or) one month future !." },
            {ErrorCodes.InvalidMissingAptdateOrProvideridParameter,"Appointments: Invalid/Missing aptdate (or) providerid parameter!."},
            {ErrorCodes.InvalidMissingAppointmentidParameter,"Appointments: Invalid/Missing appointmentid parameter!." },
            {ErrorCodes.InvalidMissingMonthparameter,"Invalid/Missing month parameter!." },
            {ErrorCodes.InvalidMissingyearparameter,"Invalid/Missing year parameter!." },
            {ErrorCodes.InvalidMissingMonthOrYearParameter,"Appointments: Invalid/Missing month (or) year parameter!."},
            {ErrorCodes.InvalidMissingFromDateParameter,"Alert: Invalid/Missing From Date parameter!." },
            {ErrorCodes.InvalidMissingToDateParameter,"Alert: Invalid/Missing To Date parameter!." },
            {ErrorCodes.InvalidMissingStatusParameter,"Alert: Invalid/Missing Status parameter!." },
            {ErrorCodes.InvalidMissingAlertTypeParameter,"Alert: Invalid/Missing Alert Type parameter!." },
            {ErrorCodes.InvalidMissingPageSizeParameter,"Alert: Invalid/Missing Page Size parameter!." },
            {ErrorCodes.InvalidMissingPageNumberParameter,"Alert: Invalid/Missing Page Number parameter!." },
            {ErrorCodes.InvalidFromDateParameter,"Alert: Invalid From Date parameter!" },
            {ErrorCodes.InvalidToDateParameter,"Alert: Invalid From Date parameter!" },
            {ErrorCodes.FromDateCannotBeGreaterThanToDate,"Alert: From Date cannot be greater than toDate." },
            {ErrorCodes.MaximumDateRangeDifferenceCanBe5DaysOnly,"Alert: Maximum date range difference can be 5 days only." },
            {ErrorCodes.InvalidStatusParameter,"Alert: Invalid status parameter!." },
            {ErrorCodes.InvalidAlertTypeParameter,"Alert: Invalid Alert Type parameter!." },
            {ErrorCodes.LoginIDCannotBeEmptOrNull,"Login ID Cannot Be Empty or Null."},


            {ErrorCodes.InvalidMissingRequestBodyPparameter,"Invalid/Missing Request body parameter!." },
            {ErrorCodes.InvalidAlertType,"Alert: Invalid Alert Type."},
            {ErrorCodes.InvalidRecipientType,"Alert: Invalid Recipient Type."},
            {ErrorCodes.InvalidMessage,"Alert: Please enter the alert message."},
            {ErrorCodes.InvalidTargetedUser,"Alert: Invalid Targeted User."},
            {ErrorCodes.InvalidSource,"Alert: Invalid Source."},
            {ErrorCodes.InvalidExpiresOn,"Alert: Invalid Expires Date."},
            {ErrorCodes.InvalidMissingAlertIdParameter,"Alert: Invalid/Missing Alert id parameter!." },
            {ErrorCodes.InvalidMissingActionParameter,"Alert: Invalid/Missing action parameter!." },
            {ErrorCodes.RequestParametersNotProvided,"Request Parameters Not Provided!!"},
            {ErrorCodes.InvalidMissingTargetedGoalparameter,"Impacts:Invalid/Missing Targetted Goal parameter!." },
            {ErrorCodes.TaskNameTaskDescriptionNullParameter,"Tasks:Task Name or Task Description Cannot Be Empty or Null!." },
            {ErrorCodes.TaskDueDateNullParameter,"Tasks:DueDate  cannot be null!." },
            {ErrorCodes.TaskDueDateNotTodayParameter,"Tasks:DueDate should be todays date or greater!." },
            {ErrorCodes.TaskIdNonZeroParameter,"Tasks:TaskId Cannot be zero !." },
            {ErrorCodes.InvalidMissingTaskIdParameter,"Tasks:Invaild/Missing taskid parameter!." },
            {ErrorCodes.MaxDateRangeParameter,"Tasks:Maximum date range difference can be 5 days only!." },
            {ErrorCodes.TaskMonthParameterShouldBeTwoMonthsPastOrOneMonthFuture,"Tasks: Month parameter should be two months past (or) one month future !." },
            {ErrorCodes.SupportInvalidMissingAptdateParameterContactType,"Support: Invalid/Missing ContactType parameter!." },
            {ErrorCodes.ContactNamePhoneTypeNullParameter,"Contact: Contact Name or Contact Phone or Contact Type Cannot Be Empty or Null!." },
            {ErrorCodes.InvalidContactTypeParameter,"Contact: Invalid Contact Type parameter!." },
            {ErrorCodes.InvalidMissingContactIdParameter,"Contact: Invalid/Missing Contact id parameter!." },
            {ErrorCodes.ContactNotSaved,"Contact:Contact is not saved." },

    };

        public static string GetErrorDefinition(string key)
        {
            return ErrorsDictonary.Where(x => x.Key == key).FirstOrDefault().Value;
        }

        public static string GetErrorCode(string value)
        {
            return ErrorsDictonary.Where(x => x.Value == value).FirstOrDefault().Key;
        }
    }
}
