﻿using System;
using log4net;

namespace WebAPI.Helpers
{
    public interface ILogManagerAdapter
    { 
         ILog GetLog(Type typeAssociatedWithRequestedLog);
    }
}
