﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    [DataContract]
    public class AnnualImpact
    {

        public AnnualImpact()
        {
            annualgoal = 0;
            goalyear = 0;
        }


        [DataMember(IsRequired = true)]
        public int providerid { get; set; }

        [DataMember(IsRequired = false)]
        public int annualgoal { get; set; }

        [DataMember(IsRequired = false)]
        public int goalyear { get; set; }
        
    }
}
