﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class ErrorMessage
    {
        public string Id { get; set; }
        /// <summary>
        /// Code
        /// </summary>
        public string Code { get; set; }


        /// <summary>
        /// Message
        /// </summary>
        public string Message { get; set; }


    }
}
