﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    [DataContract]
    public class InputTask
    {

        [DataMember(IsRequired = true)]        
        public string TaskName { get; set; }

        [DataMember(IsRequired = true)]
        public string TaskDescription { get; set; }

        [DataMember(IsRequired = true)]
        public DateTime DueDate  { get; set; }
    }
}
