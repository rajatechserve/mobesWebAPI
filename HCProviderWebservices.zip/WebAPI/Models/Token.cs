﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class DecodedToken
    {
        public string iss { get; set; }
        public string aud { get; set; }
        public string iat { get; set; }
        public long exp { get; set; }
        public string sub { get; set; }
        public bool enforceApiLevelAuthorization { get; set; }

        public Context context { get; set; }

    }

    public class Context
    {
        public User user { get; set; }
        public Client client { get; set; }
    }

    public class User
    {
        public string name { get; set; }
        public string uuid { get; set; }

        public string firstName { get; set; }
        public string lastName { get; set; }

    }

    public class Client
    {
        public string name { get; set; }
        public string authMethod { get; set; }
    }
}
