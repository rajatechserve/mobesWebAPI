﻿using HCProviderDataModel.DataContracts;
using HCProviderDataModel.DataFactory;
using HCProviderServices;
using WebAPI.Helpers;
using WebAPI.Models;
using log4net;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Web.Configuration;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Script.Serialization;
using static WebAPI.Helpers.Errors;

namespace WebAPI.Providers
{
    public class AuthorizeCustom : AuthorizeAttribute
    {
        protected override bool IsAuthorized(HttpActionContext actionContext)
        {

            if (disabledUrls(actionContext) == false)
            {
                try
                {
                    ILog _logger = LogManager.GetLogger(typeof(AuthorizeCustom));
                    IUsercontract _userContract = new UserDatafactory(WebConfigurationManager.AppSettings["dbconnectionstring"], _logger);
                    IUserService _userService = new UserService(_userContract);

                    IConfigContract _configContract = new ConfigDataFactory(WebConfigurationManager.AppSettings["dbconnectionstring"], _logger);
                    IConfigService _configSvc = new ConfigService(_configContract, _logger);

                    IEnumerable<string> headerValues = null;
                    var IsFound = actionContext.Request.Headers.TryGetValues("jwt", out headerValues); 
                    if (IsFound && !string.IsNullOrEmpty(headerValues.FirstOrDefault().ToString()))
                    {

                        var decodedToken = new JwtSecurityToken(headerValues.FirstOrDefault()).Claims;

                        var context = decodedToken.First(c => c.Type == "context");
                        DecodedToken tokenDecoded = new DecodedToken();
                        tokenDecoded.context = (Context)new JavaScriptSerializer().Deserialize(context.Value, typeof(Context));
                        if (tokenDecoded != null)
                        {

                            //HCProviderDataModel.User user = (HCProviderDataModel.User)MemoryCacher.GetValue(tokenDecoded.context.user.name);

                            //if (user != null && user.userid != 0)
                            //{
                            //    //actionContext.Request.Headers.Add("userid", Convert.ToString(user.userid));  
                            //    //actionContext.Request.Headers.Add("providerid", Convert.ToString(user.providerid));
                            //    if (actionContext.ActionArguments.Count > 0)
                            //    {
                            //        if (actionContext.ActionArguments["requestParam"] != null)
                            //        {
                            //            RequestParameters param = (RequestParameters)actionContext.ActionArguments["requestParam"];
                            //            if (param != null)
                            //            {
                            //                if (param.providerid != Convert.ToInt32(user.providerid))
                            //                {
                            //                    throw new UnAuthorizedProviderIdException(ErrorCodes.UnAuthorizedProviderId);

                            //                }
                            //            }
                            //        }
                            //    }
                            //}

                            var tokenExpiryTime = UNIXHelper.FromUnixTimeSeconds(Convert.ToInt64(decodedToken.First(c => c.Type == "exp").Value));//(new DateTime(1970, 1, 1, 0, 0, 0, 0).AddSeconds(tokenDecoded.exp)).ToUniversalTime();

                            var diff = MemoryCacher.GetValue("servertimezonediff");

                            if (diff == null)
                                diff = _configSvc.GetServerTimeZoneDiff();
                            MemoryCacher.Add("servertimezonediff", diff, DateTimeOffset.Now.AddDays(1));

                            if (DateTime.Now > (tokenExpiryTime.AddMinutes(Convert.ToInt32(diff))))
                            {
                                throw new TokenExpiredException(ErrorCodes.TokenExpired);
                            }

                            var UserPrfile = _userService.getUserByOptumId(tokenDecoded.context.user.name);
                            if (UserPrfile != null)
                            {
                                if (actionContext.ActionDescriptor.ActionName.ToLower() != "login")
                                {
                                    actionContext.Request.Headers.Remove("userid");
                                    actionContext.Request.Headers.Remove("providerid");

                                    actionContext.Request.Headers.Add("userid", Convert.ToString(UserPrfile.userid));
                                    actionContext.Request.Headers.Add("providerid", Convert.ToString(UserPrfile.providerid));
                                    actionContext.Request.Headers.Add("providername", Convert.ToString(UserPrfile.ProviderName));
                                }
                                //if (actionContext.ActionArguments.Count > 0)
                                //{
                                //    if (actionContext.ActionArguments["requestParam"] != null)
                                //    {
                                //        RequestParameters param = (RequestParameters)actionContext.ActionArguments["requestParam"];
                                //        if (param != null)
                                //        {
                                //            if (param.providerid != Convert.ToInt32(UserPrfile.providerid))
                                //            {
                                //                throw new UnAuthorizedProviderIdException(ErrorCodes.UnAuthorizedProviderId);
                                //            }
                                //        }
                                //    }
                                //}

                                MemoryCacher.Add(tokenDecoded.context.user.name, UserPrfile, DateTimeOffset.Now.AddHours(2));


                                return true;
                            }

                            if (!string.IsNullOrEmpty(UserPrfile.ErrorCode))
                            {
                                throw new AuthenticationfailureException(ErrorCodes.UnAuthorized);
                            }

                            return true;
                        }
                        else
                        {
                            throw new InvalidTokenException(ErrorCodes.InvalidToken);
                        }
                    }

                    throw new TokenMissingException(ErrorCodes.TokenMissing);

                }
                catch (Exception ex)
                {
                    if (ex.Message.Split(':').FirstOrDefault().ToString() == "Invalid JSON primitive"
                    || ex.Message.Split(':').ToList().Contains(" Unable to decode the 'header'")
                    || ex.Message == ErrorCodes.InvalidToken)
                        throw new InvalidTokenException(ErrorCodes.InvalidToken);
                    else
                        throw new TokenMissingException(ErrorCodes.TokenMissing);
                }
            }
            else
            {
                throw new NotImplementedApiException(ErrorCodes.NotImplementedException);
            }





            //var uriSegments = actionContext.Request.RequestUri.Segments;
            //bool isAuthroized = base.IsAuthorized(actionContext);
            //var user = TokenDictionary.GetUser(actionContext.Request.Headers.Authorization.Parameter.ToString());

            //if (user != null && isAuthroized)
            //{
            //    actionContext.Request.Properties["userid"] = user.userid.ToString();
            //    actionContext.Request.Properties["providerid"] = user.providerid.ToString();

            //    if (uriSegments[2].Replace("/", "") == "providers")
            //    {


            //        if (uriSegments[3].Replace("/", "") == user.providerid.ToString())
            //        {
            //            return true;
            //        }
            //        else
            //        {
            //            return false;
            //        }
            //    }
            //    else
            //    {
            //        if (isAuthroized)
            //        {
            //            actionContext.Request.Properties["userid"] = user.userid.ToString();
            //            actionContext.Request.Properties["providerid"] = user.providerid.ToString();
            //            return true;
            //        }
            //        else
            //            return false;
            //    }
            //}
            //else
            //    return false;
        }

        private bool disabledUrls(HttpActionContext actionContext)
        {           
                bool res = false;
            try
            {

                if (String.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["disabledUrls"]) == false)
                {
                    List<string> urls = ConfigurationManager.AppSettings["disabledUrls"].Split(',').ToList();

                    if (actionContext.Request.RequestUri.LocalPath.ToString() != null)
                    {
                        foreach (var url in urls)
                        {
                            if (actionContext.Request.RequestUri.LocalPath.ToString().Contains(url))
                            {
                                res = true;
                                break;
                            }                                                                                  
                        }
                    }

                }
                return res;
            }
            catch (Exception ex)
            {
                return res;
            }

                        
        }
    }
}