﻿using System;
using System.Collections.Generic;


namespace WebAPI.Providers
{
    using Microsoft.AspNet.SignalR.Hubs;
    using Microsoft.Practices.Unity;
    using System.Web.Http.Dependencies;
    using Unity;
    using Unity.Exceptions;

    /// <summary>
    /// IOC Dependency Resolver
    /// </summary>
    public class UnityResolver : IDependencyResolver
    {
        /// <summary>
        /// IOC container
        /// </summary>B
        protected IUnityContainer container;

        /// <summary>
        /// constructor gets called with the initialized Type mappings
        /// Type Mappings are defined during the start of the process
        /// </summary>
        /// <param name="container"></param>
        public UnityResolver(IUnityContainer container)
        {
            if (container == null)
            {
                throw new ArgumentNullException("container");
            }
            this.container = container;
        }

        public object GetService(Type serviceType)
        {
            try
            {
                return container.Resolve(serviceType);
            }
            catch (ResolutionFailedException exp)
            {
                return null;

            }
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            try
            {
                return container.ResolveAll(serviceType);
            }
            catch (ResolutionFailedException exp)
            {
                return new List<object>();
            }
        }

        public  T Get<T>()

        {
            T ret = default(T);

            ret = container.Resolve<T>();
        
            if (ret == null)
                throw new NullReferenceException(string.Format("Requested service of type {0}, but null was found.",
                    typeof(T).FullName));

            return ret;
        }

        public IDependencyScope BeginScope()
        {
            var child = container.CreateChildContainer();
            return new UnityResolver(child);
        }

        public void Dispose()
        {
            container.Dispose();
        }
    }

    public class NotificationSignalRServiceHubActivator : IHubActivator
    {
        private readonly IUnityContainer container;

        public NotificationSignalRServiceHubActivator(IUnityContainer container)
        {
            this.container = container;
        }

        public IHub Create(HubDescriptor descriptor)
        {
            if (descriptor == null)
            {
                throw new ArgumentNullException("descriptor");
            }

            if (descriptor.HubType == null)
            {
                return null;
            }

            object hub = this.container.Resolve(descriptor.HubType) ?? Activator.CreateInstance(descriptor.HubType);
            return hub as IHub;
        }


    }
}
