﻿using System;
using System.Web.Configuration;


namespace WebAPI.Providers
{
   public static class ConfigProvider
    {

        /// <summary>
        /// Environment -DEV/TEST/PRD/TRN -based on app roles
        /// </summary>
        public static string Environment = "prd";

        /// <summary>
        /// Database connection string 
        /// </summary>
        public static string DBConnection = "";

        /// <summary>
        /// Site name
        /// </summary>
        public static string SiteUrl = "";

        /// <summary>
        /// product domain
        /// </summary>
        public static string productDomain ="";

        /// <summary>
        /// config initialization indicator - True -initialized/False-Not Initialized
        /// </summary>
        public static bool isInitialized { get; set; }
        

        /// <summary>
        /// Force Https for requests
        /// </summary>
        public static bool forcehttps = false;

        /// <summary>
        /// App name in secure role groups
        /// </summary>
        public static string appprefix= string.Empty;

        /// <summary>
        /// Name of windows service for logging
        /// </summary>
        public static string servicename = string.Empty;



        /// <summary>
        /// initialize configurations
        /// </summary>
        /// 
        public static void initialize()
        {
            DBConnection = WebConfigurationManager.AppSettings["dbconnectionstring"];
            SiteUrl = WebConfigurationManager.AppSettings["site"];
            productDomain = WebConfigurationManager.AppSettings["productdomain"];          
            forcehttps = Convert.ToBoolean(WebConfigurationManager.AppSettings["forcehttps"]);
            Environment = WebConfigurationManager.AppSettings["environment"];
            appprefix = WebConfigurationManager.AppSettings["secureprefix"];
            servicename = WebConfigurationManager.AppSettings["servicename"];
            isInitialized = true;


        }

        
    }
}
