﻿using System;
using System.Net.Http;
using System.Net;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using System.Collections.Generic;
using System.Web.Http;
using System.Net.Http.Formatting;

namespace WebAPI.Providers
{

    /// <summary>
    /// Validate model/parameter binding in valid
    /// </summary>
    public class ValidateModelAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            if (actionContext.ModelState.IsValid == false)
            {
                actionContext.Response = actionContext.Request.CreateErrorResponse(
                    HttpStatusCode.BadRequest, actionContext.ModelState);
            }

        }


    }

    /// <summary>
    /// validate if null parameter binding
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, Inherited = true)]
    public class CheckModelForNullAttribute : ActionFilterAttribute
    {
        private readonly Func<Dictionary<string, object>, bool> _validate;

        public CheckModelForNullAttribute() : this(arguments =>
        arguments.ContainsValue(null))
        {


        }

        public CheckModelForNullAttribute(Func<Dictionary<string, object>, bool> checkCondition)
        {
            _validate = checkCondition;
        }

        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            if (_validate(actionContext.ActionArguments))
            {
                actionContext.Response = actionContext.Request.CreateErrorResponse(
       HttpStatusCode.BadRequest, "The argument cannot be null");
            }
        }
    }


    /// <summary>
    /// applies xml media formatter upon request
    /// default formatter json
    /// 
    /// </summary>
    public class DynamicformatProvider : ActionFilterAttribute
    {

        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            ApplyDynamicMediaFormat(actionContext);
               
        }

        public void ApplyDynamicMediaFormat(HttpActionContext actionContext)
        {

            Dictionary<string, object> parameters = actionContext.ActionArguments;

            string typevalue = string.Empty;
            object paramValue = "";


            var routeData = actionContext.RequestContext.RouteData.Values;
         

            if (routeData   != null && parameters.Count > 0)
            {
                if (routeData .ContainsKey("type") && routeData.TryGetValue("type", out paramValue))
                {
                    typevalue = Convert.ToString(paramValue);

                    HttpConfiguration confg = actionContext.RequestContext.Configuration;
                    
                    if (typevalue.ToLower() == "xml")
                    {
                        confg.Formatters.Clear();
                       confg.Formatters.Add(new XmlMediaTypeFormatter());
                        confg.Formatters.XmlFormatter.UseXmlSerializer = true;
                    }

                    if (typevalue.ToLower() == "json")
                    {
                        confg.Formatters.Clear();
                        confg.Formatters.Add(new JsonMediaTypeFormatter());
                       
                    }

                }

            }
            
        }


    }
}