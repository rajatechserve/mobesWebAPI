﻿using System;

using System.Web.Http.Routing;
using System.Web.Http.Controllers;
using System.Collections.Generic;

namespace WebAPI.Providers
{
    public class RoutePrefixProvider : DefaultDirectRouteProvider
    {
        private readonly string _centralizedPrefix;

        public RoutePrefixProvider(string centralizedPrefix)
        {
            _centralizedPrefix = centralizedPrefix;
        }

        protected override string GetRoutePrefix(HttpControllerDescriptor controllerDescriptor)
        {
            var existingPrefix = base.GetRoutePrefix(controllerDescriptor);
            if (existingPrefix == null) return _centralizedPrefix;

            return string.Format("{0}/{1}", _centralizedPrefix, existingPrefix);
        }
    }

   public   class VersionedRoute : RouteFactoryAttribute
    {
        public string AllowedVersion { get; set; }
         public VersionedRoute(string template, string allowedversion ) : base(template)
        {
            AllowedVersion = allowedversion;
            
        }

        public override IDictionary<string, object> Constraints
        {

            get
            {
                
                var constraints = new HttpRouteValueDictionary();
                constraints.Add("version", AllowedVersion);
                  return constraints;

            }

        }
    }

}
