﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;
using WebAPI.Helpers;
using log4net;

namespace WebAPI.Providers
{
    // Validate the Config Key Value Pairs

    public class HCValidateConfig
    {
        public void ValidateConfig()
        {

            ILog _logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            // DatabaseConnection String 
            string DbConnectionString = WebConfigurationManager.AppSettings["dbconnectionstring"];
            string OptumSecurityLogging = WebConfigurationManager.AppSettings["optumsecuritylogging"];
            string OptumMethodLogging = WebConfigurationManager.AppSettings["optummethodlogging"];
            string OptumLoggingFieldsXml = WebConfigurationManager.AppSettings["OptumLoggingFieldsXml"];
            string ForceHttps = WebConfigurationManager.AppSettings["forcehttps"];
            string ProductDomain = WebConfigurationManager.AppSettings["productdomain"];
            string Site = WebConfigurationManager.AppSettings["site"];
            string servicename = WebConfigurationManager.AppSettings["servicename"];
            string SecretKey = WebConfigurationManager.AppSettings["SecretKey"];


            if (String.IsNullOrEmpty(DbConnectionString))
                _logger.Error("Database Connection String is not provided in Configuration! ");
            if (String.IsNullOrEmpty(OptumSecurityLogging))
                _logger.Error("OptumSecurityLogging is not provided in Configuration! ");
            if (String.IsNullOrEmpty(OptumMethodLogging))
                _logger.Error("OptumMethodLogging is not provided in Configuration! ");
            if (String.IsNullOrEmpty(OptumLoggingFieldsXml))
                _logger.Error("OptumLoggingFieldsXml is not provided in Configuration! ");
            if (String.IsNullOrEmpty(ForceHttps))
                _logger.Error("Force Https is not provided in Configuration! ");
            if (String.IsNullOrEmpty(ProductDomain))
                _logger.Error("Product Domain is not provided in Configuration! ");
            if (String.IsNullOrEmpty(Site))
                _logger.Error("Site is not provided in Configuration! ");            
            if (String.IsNullOrEmpty(servicename))
                _logger.Error("Service Name is not provided in Configuration! ");
            if (String.IsNullOrEmpty(SecretKey))
                _logger.Error("Secret Key is not provided in Configuration! ");
        }


    }
}
